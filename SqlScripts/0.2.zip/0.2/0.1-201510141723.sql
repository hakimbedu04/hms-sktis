/****** Object:  View [dbo].[MaintenanceExecutionInventoryView]    Script Date: 14/10/2015 14:04:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [dbo].[MaintenanceExecutionInventoryView]
AS
--SELECT 'ID21' LocationCode,
--       'GLK-003' AS [Item Code],
--       0 AS StawIT,
--       0 AS InIT,
--       0 AS OutIT,
--       0 AS StackIT,

--       0 AS StawQI,
--       0 AS InQI,
--       0 AS OutQI,
--       0 AS StackQI,

--       0 AS StawReady,
--       0 AS InReady,
--       0 AS OutReady,
--       0 AS StackReady,

--       0 AS StawOU,
--       0 AS InOU,
--       0 AS OutOU,
--       0 AS StackOU,

--       0 AS StawOR,
--       0 AS InOR,
--       0 AS OutOR,
--       0 AS StackOR,

--       0 AS StawBS,
--       0 AS InBS,
--       0 AS OutBS,
--       0 AS StackBS;

SELECT ItemCode AS [Item Code], LocationCode,
       SUM(CASE WHEN midv.itemstatus = 'IN TRANSIT' THEN midv.DBeginningStock ELSE 0 END) AS StawIT,
       SUM(CASE WHEN midv.itemstatus = 'IN TRANSIT' THEN midv.DStockIn ELSE 0 END) AS InIT,
       SUM(CASE WHEN midv.itemstatus = 'IN TRANSIT' THEN midv.DStockOut ELSE 0 END) AS OutIT,
       SUM(CASE WHEN midv.itemstatus = 'IN TRANSIT' THEN midv.DEndingStock ELSE 0 END) AS StackIT,
	  SUM(CASE WHEN midv.itemstatus = 'ON QUALITY INSPECTION' THEN midv.DBeginningStock ELSE 0 END) AS StawQI,
       SUM(CASE WHEN midv.itemstatus = 'ON QUALITY INSPECTION' THEN midv.DStockIn ELSE 0 END) AS InQI,
       SUM(CASE WHEN midv.itemstatus = 'ON QUALITY INSPECTION' THEN midv.DStockOut ELSE 0 END) AS OutQI,
       SUM(CASE WHEN midv.itemstatus = 'ON QUALITY INSPECTION' THEN midv.DEndingStock ELSE 0 END) AS StackQI,
	  SUM(CASE WHEN midv.itemstatus = 'READY TO USE' THEN midv.DBeginningStock ELSE 0 END) AS StawReady,
       SUM(CASE WHEN midv.itemstatus = 'READY TO USE' THEN midv.DStockIn ELSE 0 END) AS InReady,
       SUM(CASE WHEN midv.itemstatus = 'READY TO USE' THEN midv.DStockOut ELSE 0 END) AS OutReady,
       SUM(CASE WHEN midv.itemstatus = 'READY TO USE' THEN midv.DEndingStock ELSE 0 END) AS StackReady,
	  SUM(CASE WHEN midv.itemstatus = 'ON USED' THEN midv.DBeginningStock ELSE 0 END) AS StawOU,
       SUM(CASE WHEN midv.itemstatus = 'ON USED' THEN midv.DStockIn ELSE 0 END) AS InOU,
       SUM(CASE WHEN midv.itemstatus = 'ON USED' THEN midv.DStockOut ELSE 0 END) AS OutOU,
       SUM(CASE WHEN midv.itemstatus = 'ON USED' THEN midv.DEndingStock ELSE 0 END) AS StackOU,
	  SUM(CASE WHEN midv.itemstatus = 'ON REPAIR' THEN midv.DBeginningStock ELSE 0 END) AS StawOR,
       SUM(CASE WHEN midv.itemstatus = 'ON REPAIR' THEN midv.DStockIn ELSE 0 END) AS InOR,
       SUM(CASE WHEN midv.itemstatus = 'ON REPAIR' THEN midv.DStockOut ELSE 0 END) AS OutOR,
       SUM(CASE WHEN midv.itemstatus = 'ON REPAIR' THEN midv.DEndingStock ELSE 0 END) AS StackOR,
	  SUM(CASE WHEN midv.itemstatus = 'BAD STOCK' THEN midv.DBeginningStock ELSE 0 END) AS StawBS,
       SUM(CASE WHEN midv.itemstatus = 'BAD STOCK' THEN midv.DStockIn ELSE 0 END) AS InBS,
       SUM(CASE WHEN midv.itemstatus = 'BAD STOCK' THEN midv.DStockOut ELSE 0 END) AS OutBS,
       SUM(CASE WHEN midv.itemstatus = 'BAD STOCK' THEN midv.DEndingStock ELSE 0 END) AS StackBS
FROM MntcInventoryDeltaView midv
GROUP BY midv.InventoryDate,
         midv.LocationCode,
         midv.UnitCode,
         midv.ItemCode;

GO


