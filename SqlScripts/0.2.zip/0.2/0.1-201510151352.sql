
EXECUTE sp_rename N'dbo.MntcEquipmentItemConvert.SourceStock', N'Tmp_SourceQty_1', 'COLUMN' 
GO
EXECUTE sp_rename N'dbo.MntcEquipmentItemConvert.Tmp_SourceQty_1', N'SourceQty', 'COLUMN' 
GO
ALTER TABLE dbo.MntcEquipmentItemConvert
	DROP COLUMN DestinationStock
GO
ALTER TABLE dbo.MntcEquipmentItemConvert SET (LOCK_ESCALATION = TABLE)
GO
