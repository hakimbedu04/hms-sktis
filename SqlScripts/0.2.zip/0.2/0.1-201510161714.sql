/* Transaction History */
CREATE FUNCTION GetTransactionHistory
(	
	@transactionCode VARCHAR(128)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT 
		utl.CreatedBy name,
		ur.RolesName [role], 
		uf.MessageText [action],
		utl.CreatedDate [date],
		utl.Comments note 
	FROM UtilTransactionLogs utl
	INNER JOIN MstADTemp mat ON mat.UserAD = utl.CreatedBy
	INNER JOIN UtilUsersResponsibility uur ON uur.UserAD = mat.UserAD
	INNER JOIN UtilResponsibility urp on urp.IDResponsibility = uur.IDResponsibility
	INNER JOIN UtilRoles ur ON ur.IDRole = urp.IDRole
	INNER JOIN UtilFlows uf ON uf.IDFlow = utl.IDFlow
	WHERE utl.TransactionCode = @transactionCode
)
GO
