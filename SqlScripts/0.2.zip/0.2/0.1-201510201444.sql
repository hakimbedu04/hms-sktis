ALTER VIEW [dbo].[TargetProductionUnitView]
AS
SELECT        tpu.ProductionStartDate, tpu.KPSYear, tpu.KPSWeek, tpu.BrandCode, tpu.LocationCode, tpu.UnitCode, tpu.Shift, tpu.TPUCode, tpu.WorkerRegister, tpu.WorkerAvailable, tpu.WorkerAlocation, 
                         tpu.PercentAttendance1, tpu.PercentAttendance2, tpu.PercentAttendance3, tpu.PercentAttendance4, tpu.PercentAttendance5, tpu.PercentAttendance6, tpu.PercentAttendance7, tpu.HistoricalCapacityWorker1, 
                         tpu.HistoricalCapacityWorker2, tpu.HistoricalCapacityWorker3, tpu.HistoricalCapacityWorker4, tpu.HistoricalCapacityWorker5, tpu.HistoricalCapacityWorker6, tpu.HistoricalCapacityWorker7, 
                         tpu.HistoricalCapacityGroup1, tpu.HistoricalCapacityGroup2, tpu.HistoricalCapacityGroup3, tpu.HistoricalCapacityGroup4, tpu.HistoricalCapacityGroup5, tpu.HistoricalCapacityGroup6, 
                         tpu.HistoricalCapacityGroup7, tpu.TargetSystem1, tpu.TargetSystem2, tpu.TargetSystem3, tpu.TargetSystem4, tpu.TargetSystem5, tpu.TargetSystem6, tpu.TargetSystem7, tpu.TargetManual1, tpu.TargetManual2, 
                         tpu.TargetManual3, tpu.TargetManual4, tpu.TargetManual5, tpu.TargetManual6, tpu.TargetManual7, tpu.ProcessWorkHours1, tpu.ProcessWorkHours2, tpu.ProcessWorkHours3, tpu.ProcessWorkHours4, 
                         tpu.ProcessWorkHours5, tpu.ProcessWorkHours6, tpu.ProcessWorkHours7, tpu.TotalWorkhours, tpu.TotalTargetSystem, tpu.TotalTargetManual, tpu.CreatedDate, tpu.CreatedBy, tpu.UpdatedDate, tpu.UpdatedBy, 
                         wpp.Value1
FROM            dbo.PlanTargetProductionUnit AS tpu INNER JOIN
                         dbo.PlanWeeklyProductionPlanning AS wpp ON tpu.KPSYear = wpp.KPSYear AND tpu.KPSWeek = wpp.KPSWeek AND tpu.BrandCode = wpp.BrandCode AND tpu.LocationCode = wpp.LocationCode
WHERE        (tpu.UnitCode NOT IN ('MTNC', 'PROD', 'WHSE'))

GO


