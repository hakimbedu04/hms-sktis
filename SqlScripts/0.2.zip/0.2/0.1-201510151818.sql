/****** Object:  StoredProcedure [dbo].[TransactionLog]    Script Date: 10/15/2015 6:15:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[TransactionLog] 
	-- Add the parameters for the stored procedure here
	@Separator			   VARCHAR(20),
    @Page				   VARCHAR(16),
    @Year				   INT,
    @Week				   INT,
	@code_1				   VARCHAR(16),
	@code_2				   VARCHAR(16),
	@code_3				   VARCHAR(16),
	@code_4				   VARCHAR(16),
	@code_5				   VARCHAR(16),
	@code_6				   VARCHAR(16),
	@code_7				   VARCHAR(16),
	@code_8				   VARCHAR(16),
	@code_9				   VARCHAR(16),
	@Transaction_Date	   datetime	,
	@ActionButton		   VARCHAR(16),
	@ActionTime			   datetime,
	@UserName				   VARCHAR(32)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @IDFunct int, @IDButton int, @IDFlow int, @TransactionCode  VARCHAR(128),@MessageText VARCHAR(128)
	-- checking the  
	if(@Page Like 'WPP%')
	Begin
	Set @TransactionCode = Convert(nvarchar(50),@code_1)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_2)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_3)
	Select     @IDFunct =IDFunction from UtilFunctions ufun where ufun.FunctionName Like 'Weekly%'
	End
	if(@Page Like 'TPU%')
	Begin
	Set @TransactionCode = Convert(nvarchar(50),@code_1)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_2)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_3)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_4)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_5)
	Select     @IDFunct =IDFunction from UtilFunctions ufun where ufun.FunctionName Like 'TargetProductionUnit%'
	End
	if(@Page Like 'TPKPLANT%')
	Begin
	Set @TransactionCode = Convert(nvarchar(50),@code_1)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_2)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_3)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_4)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_5)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_6)
	Select  @IDFunct =IDFunction from UtilFunctions ufun where ufun.FunctionName Like 'PlantTargetProductionGroup%'
	End
	if(@Page Like 'TPKTPO%')
	Begin
	Set @TransactionCode = Convert(nvarchar(50),@code_1)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_2)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_3)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_4)+Convert(nvarchar(50),@Separator)+Convert(nvarchar(50),@code_5)
	Select     @IDFunct =IDFunction from UtilFunctions ufun where ufun.FunctionName Like 'TPOTargetProductionGroup%'
	End
	-- insert into transaction log table
	Begin
	Select     @IDButton =IDFunction from UtilFunctions ufun where ufun.ParentIDFunction = @IDFunct and ufun.FunctionName = @ActionButton
	Select     @IDFlow = IDFlow,@MessageText=MessageText from UtilFlows uflow where uflow.FormSource = @IDFunct and uflow.ActionButton = @IDButton
	INSERT INTO UtilTransactionLogs( TransactionCode,TransactionDate,IDFlow,Comments,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy) 
	VALUES(@TransactionCode,@Transaction_Date,@IDFlow,@MessageText,@ActionTime,@UserName,GETDATE(),@UserName) 
	End
	    --Insert statements for procedure here	
END

GO


