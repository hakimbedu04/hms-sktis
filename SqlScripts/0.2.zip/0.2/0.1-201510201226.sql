ALTER TABLE [MntcEquipmentItemConvert] ALTER COLUMN [SourceStatus] varchar(32)
ALTER TABLE [MntcInventoryAdjustment] ALTER COLUMN [ItemStatusFrom] varchar(32)
ALTER TABLE [MntcInventoryAdjustment] ALTER COLUMN [ItemStatusTo] varchar(32)

