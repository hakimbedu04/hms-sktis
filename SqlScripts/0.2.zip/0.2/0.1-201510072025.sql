ALTER TABLE dbo.PlanPlantAllocation
ADD CreatedDate DATETIME NOT NULL,
CreatedBy   VARCHAR(64) NOT NULL,
UpdatedDate DATETIME NOT NULL,
UpdatedBy   VARCHAR(64) NOT NULL;