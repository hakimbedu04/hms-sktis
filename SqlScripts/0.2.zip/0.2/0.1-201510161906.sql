ALTER VIEW [dbo].[MaintenanceEquipmentFulfillmentView]

AS
SELECT        table1.LocationCode, table1.RequestDate, table1.RequestNumber, table1.CreatedBy, table1.FulFillmentDate, table1.ItemCode, table1.ItemDescription, 
                         tblInventoriReadyToUse.EndingStock AS ReadyToUse, tblInventoriOnUse.EndingStock AS OnUse, tblInventoriOnRepair.EndingStock AS OnRepair, 
                         table1.Qty AS RequestedQuantity, table1.ApprovedQty, table1.RequestToQty,
						 (table1.ApprovedQty - table1.RequestToQty) as PurchaseQuantity,
						  table1.PurchaseNumber, table1.UpdatedDate
FROM            (SELECT        dbo.MntcEquipmentFulfillment.LocationCode, dbo.MntcEquipmentFulfillment.RequestDate, dbo.MntcEquipmentFulfillment.RequestNumber, 
                                                    dbo.MntcEquipmentFulfillment.CreatedBy, dbo.MntcEquipmentFulfillment.FulFillmentDate, dbo.MntcEquipmentFulfillment.ItemCode, 
                                                    dbo.MstMntcItem.ItemDescription, dbo.MntcEquipmentRequest.Qty, dbo.MntcEquipmentRequest.ApprovedQty, 
                                                    dbo.MntcEquipmentFulfillment.RequestToQty, dbo.MntcEquipmentFulfillment.PurchaseNumber, 
                                                    dbo.MntcEquipmentFulfillment.UpdatedDate
                          FROM            dbo.MntcEquipmentFulfillment INNER JOIN
                                                    dbo.MstMntcItem ON dbo.MntcEquipmentFulfillment.ItemCode = dbo.MstMntcItem.ItemCode INNER JOIN
                                                    dbo.MntcEquipmentRequest ON dbo.MntcEquipmentFulfillment.RequestDate = dbo.MntcEquipmentRequest.RequestDate AND 
                                                    dbo.MntcEquipmentFulfillment.ItemCode = dbo.MntcEquipmentRequest.ItemCode AND 
                                                    dbo.MntcEquipmentFulfillment.LocationCode = dbo.MntcEquipmentRequest.LocationCode AND 
                                                    dbo.MntcEquipmentFulfillment.RequestNumber = dbo.MntcEquipmentRequest.RequestNumber) AS table1 INNER JOIN
                             (SELECT        TOP (1) InventoryDate, ItemStatus, ItemCode, LocationCode, UnitCode, ItemType, UOM, BeginningStock, StockIn, StockOut, EndingStock
                               FROM            dbo.MntcInventory
                               WHERE        (ItemStatus = 'Ready to Use')
                               ORDER BY InventoryDate DESC) AS tblInventoriReadyToUse ON table1.ItemCode = tblInventoriReadyToUse.ItemCode AND 
                         table1.LocationCode = tblInventoriReadyToUse.LocationCode INNER JOIN
                             (SELECT        TOP (1) InventoryDate, ItemStatus, ItemCode, LocationCode, UnitCode, ItemType, UOM, BeginningStock, StockIn, StockOut, EndingStock
                               FROM            dbo.MntcInventory AS MntcInventory_2
                               WHERE        (ItemStatus = 'On Used')
                               ORDER BY InventoryDate DESC) AS tblInventoriOnUse ON table1.ItemCode = tblInventoriOnUse.ItemCode AND 
                         table1.LocationCode = tblInventoriOnUse.LocationCode INNER JOIN
                             (SELECT        TOP (1) InventoryDate, ItemStatus, ItemCode, LocationCode, UnitCode, ItemType, UOM, BeginningStock, StockIn, StockOut, EndingStock
                               FROM            dbo.MntcInventory AS MntcInventory_1
                               WHERE        (ItemStatus = 'On Repair')
                               ORDER BY InventoryDate DESC) AS tblInventoriOnRepair ON table1.ItemCode = tblInventoriOnRepair.ItemCode AND 
                         table1.LocationCode = tblInventoriOnRepair.LocationCode
GO