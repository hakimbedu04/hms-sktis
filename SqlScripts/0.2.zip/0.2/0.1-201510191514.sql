/* MODIFIED EXEPLANTWORKERABSENTEEISM AS ON STORY #33125 */

SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
GO

ALTER TABLE dbo.MstPlantEmpJobsDataAcv SET (LOCK_ESCALATION = TABLE)
GO
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[FK_EXEPLANTWORKERABSENTEEIS_RELATIONSHIP_69_MSTPLANTEMPJOBSDATAALL]'))
BEGIN
ALTER TABLE dbo.ExePlantWorkerAbsenteeism
	DROP CONSTRAINT FK_EXEPLANTWORKERABSENTEEIS_RELATIONSHIP_69_MSTPLANTEMPJOBSDATAALL
end
GO
ALTER TABLE dbo.MstPlantEmpJobsDataAll SET (LOCK_ESCALATION = TABLE)
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[FK_EXEPLANTWORKERABSENTEEIS_REFERENCE_133_MSTPLANTABSENTTYPE]'))
BEGIN
ALTER TABLE dbo.ExePlantWorkerAbsenteeism
	DROP CONSTRAINT FK_EXEPLANTWORKERABSENTEEIS_REFERENCE_133_MSTPLANTABSENTTYPE
end
GO
ALTER TABLE dbo.MstPlantAbsentType SET (LOCK_ESCALATION = TABLE)
GO

CREATE TABLE dbo.Tmp_ExePlantWorkerAbsenteeism
	(
	StartDateAbsent datetime NOT NULL,
	EmployeeID varchar(64) NOT NULL,
	AbsentType varchar(128) NOT NULL,
	EndDateAbsent datetime NOT NULL,
	SktAbsentCode varchar(11) NULL,
	PayrollAbsentCode varchar(11) NULL,
	ePaf varchar(64) NULL,
	Attachment varchar(64) NULL,
	AttachmentPath varchar(64) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL,
	EmployeeNumber varchar(64) NULL,
	LocationCode varchar(8) NOT NULL DEFAULT '',
	UnitCode varchar(4) NOT NULL DEFAULT '',
	GroupCode varchar(4) NOT NULL DEFAULT '',
	TransactionDate datetime NOT NULL DEFAULT GETDATE()
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExePlantWorkerAbsenteeism SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExePlantWorkerAbsenteeism)
	 EXEC('INSERT INTO dbo.Tmp_ExePlantWorkerAbsenteeism (StartDateAbsent, EmployeeID, AbsentType, EndDateAbsent, SktAbsentCode, PayrollAbsentCode, ePaf, Attachment, AttachmentPath, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, EmployeeNumber)
		SELECT StartDateAbsent, EmployeeID, AbsentType, EndDate, SktAbsentCode, PayrollAbsentCode, ePaf, Attachment, AttachmentPath, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, EmployeeNumber FROM dbo.ExePlantWorkerAbsenteeism WITH (HOLDLOCK TABLOCKX)')
GO
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[FK_EXEPLANTPRODUCTIONENTRY_RELATIONSHIP_117_EXEPLANTWORKERABSENTEEIS]'))
BEGIN
ALTER TABLE dbo.ExePlantProductionEntry
	DROP CONSTRAINT FK_EXEPLANTPRODUCTIONENTRY_RELATIONSHIP_117_EXEPLANTWORKERABSENTEEIS
END
GO
DROP TABLE dbo.ExePlantWorkerAbsenteeism
GO
EXECUTE sp_rename N'dbo.Tmp_ExePlantWorkerAbsenteeism', N'ExePlantWorkerAbsenteeism', 'OBJECT' 
GO
ALTER TABLE dbo.ExePlantWorkerAbsenteeism ADD CONSTRAINT
	PK_ExePlantWorkerAbsenteeism_1 PRIMARY KEY CLUSTERED 
	(
	StartDateAbsent,
	EmployeeID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
-- REMOVE UNIQUE CONSTRAINT SINCE DEFAULT TRANSACTION DATE WILL ALWAYS USING SAME VALUE
--ALTER TABLE dbo.ExePlantWorkerAbsenteeism ADD CONSTRAINT
--	UQ_TransactionDate_ExePlantWorkerAbsenteeism UNIQUE NONCLUSTERED 
--	(
--	TransactionDate
--	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
--GO
CREATE NONCLUSTERED INDEX IDX_ExePlantWorkerAbsenteeism ON dbo.ExePlantWorkerAbsenteeism
	(
	LocationCode,
	UnitCode,
	GroupCode,
	StartDateAbsent
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.ExePlantWorkerAbsenteeism ADD CONSTRAINT
	FK_ExePlantWorkerAbsenteeism_MstPlantEmpJobsDataAcv FOREIGN KEY
	(
	EmployeeID
	) REFERENCES dbo.MstPlantEmpJobsDataAcv
	(
	EmployeeID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantWorkerAbsenteeism ADD CONSTRAINT
	FK_ExePlantWorkerAbsenteeism_MstPlantAbsentType FOREIGN KEY
	(
	AbsentType
	) REFERENCES dbo.MstPlantAbsentType
	(
	AbsentType
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 	
GO

ALTER TABLE dbo.ExePlantProductionEntry SET (LOCK_ESCALATION = TABLE)
GO
