/****** Object:  View [dbo].[MaintenanceItemConversionDestinationView]    Script Date: 16/10/2015 11:18:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[MaintenanceItemConversionDestinationView]
AS
--SELECT        mmc.ItemCodeSource, mmc.ItemCodeDestination, mmi.ItemDescription AS ItemCodeDestinationDescription, mmc.QtyConvert, C.SourceStock, 
--                         C.DestinationStock, C.QtyGood, C.QtyDisposal
--FROM            dbo.MstMntcConvert AS mmc INNER JOIN
--                         dbo.MstMntcItem AS mmi ON mmi.ItemCode = mmc.ItemCodeDestination LEFT OUTER JOIN
--                             (SELECT        ItemCodeSource, ItemCodeDestination, SourceStock, DestinationStock, QtyGood, QtyDisposal
--                               FROM            dbo.MntcEquipmentItemConvert AS meic) AS C ON C.ItemCodeSource = mmc.ItemCodeSource AND 
--                         C.ItemCodeDestination = mmc.ItemCodeDestination
--WHERE        (mmc.ConversionType = 1)

SELECT 
    mmc.ItemCodeSource, 
    mmc.ItemCodeDestination, 
    mmi.ItemDescription AS ItemCodeDestinationDescription, 
    mmc.QtyConvert, C.SourceStock,
    --C.DestinationStock,
    C.QtyGood, 
    C.QtyDisposal
FROM dbo.MstMntcConvert AS mmc INNER JOIN dbo.MstMntcItem AS mmi ON mmi.ItemCode = mmc.ItemCodeDestination
                               LEFT OUTER JOIN( SELECT	 ItemCodeSource, 
											 ItemCodeDestination, 
											 meic.SourceQty AS SourceStock,
											 --DestinationStock,
											 QtyGood, 
											 QtyDisposal
                                                FROM dbo.MntcEquipmentItemConvert AS meic ) AS C ON C.ItemCodeSource = mmc.ItemCodeSource AND
                                                                                                    C.ItemCodeDestination = mmc.ItemCodeDestination
WHERE mmc.ConversionType = 1;

GO


