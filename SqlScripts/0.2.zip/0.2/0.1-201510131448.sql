/****** Object:  View [dbo].[MntcInventoryAll]    Script Date: 10/13/2015 14:18:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Script for SelectTopNRows command from SSMS  ******/
create view [dbo].[MntcInventoryAll] as
SELECT a.InventoryDate,a.ItemStatus,a.ItemCode,a.LocationCode,a.ItemType,
BeginningStock,StockIn,StockOut,EndingStock
FROM [MntcInventory] a
WHERE NOT EXISTS (SELECT 1 FROM [MntcInventoryDeltaView]
WHERE InventoryDate=a.InventoryDate
and LocationCode=a.LocationCode 
and UnitCode=a.UnitCode and ItemStatus=a.ItemStatus and ItemCode=a.ItemCode)
UNION ALL
SELECT a.InventoryDate,a.ItemStatus,a.ItemCode,a.LocationCode,a.ItemType,
BeginningStock+DBeginningStock as BeginningStock,
StockIn+DStockIn as StockIn,
StockOut+DStockOut as StockOut,
EndingStock+DEndingStock as  EndingStock 
  FROM [MntcInventory] a, [MntcInventoryDeltaView] b 
WHERE b.InventoryDate=a.InventoryDate
and b.LocationCode=a.LocationCode 
and b.UnitCode=a.UnitCode 
and b.ItemStatus=a.ItemStatus 
and b.ItemCode=a.ItemCode

GO


