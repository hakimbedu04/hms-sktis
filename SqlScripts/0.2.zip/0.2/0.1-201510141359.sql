/****** Object:  StoredProcedure [dbo].[RunSSISProductionEntryPlant]    Script Date: 10/14/2015 13:58:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[RunSSISProductionEntryPlant]
	@UserName NVarchar(64),
	@KPSYear int,
	@KPSWeek int,
	@LocationCode varchar(8),
	@BrandCode varchar(11),
	@UnitCode varchar(4)
AS
BEGIN
declare @param varchar(max)

set @param = N' /SET "\Package.Variables[User::UserName].Properties[Value]";' + @UserName +
			  ' /SET "\Package.Variables[User::KPSYear].Properties[Value]";' + cast(@KPSYear as varchar(4)) +
			  ' /SET "\Package.Variables[User::KPSWeek].Properties[Value]";' + cast(@KPSWeek as varchar(2)) +
			  ' /SET "\Package.Variables[User::LocationCode].Properties[Value]";' + @LocationCode +
			  ' /SET "\Package.Variables[User::BrandCode].Properties[Value]";' + @BrandCode +
			  ' /SET "\Package.Variables[User::UnitCode].Properties[Value]";' + @UnitCode

EXEC	[dbo].[usp_ExecAdhocJob]
		@Param = @param,
		@dtsxName = N'PlantTPK'
END



