CREATE FUNCTION [dbo].[GetTotalWorkHoursPrev3Weeks](
                @year AS         INT,
                @week AS         INT,
                @prodGroup AS    CHAR(4),
                @processGroup AS VARCHAR(16),
                @locationCode AS VARCHAR(8),
                @statusEmp AS    VARCHAR(16),
                @brandCode AS    VARCHAR(11))
RETURNS @total TABLE( TotalWorkHours1Prev3Weeks INT,
                      TotalWorkHours2Prev3Weeks INT,
                      TotalWorkHours3Prev3Weeks INT,
                      TotalWorkHours4Prev3Weeks INT,
                      TotalWorkHours5Prev3Weeks INT,
                      TotalWorkHours6Prev3Weeks INT,
                      TotalWorkHours7Prev3Weeks INT )
AS
     BEGIN
     DECLARE @startdate DATE;
     DECLARE @endate DATE;
     SELECT @startdate = MIN(StartDate),
            @endate = MAX(enddate)
     FROM GetPastWeek( @year, @week, 3 ) past
          INNER JOIN MstGenWeek week ON week.Year = past.year
                                    AND week.Week = past.week;
     INSERT INTO @total
            SELECT SUM(ProcessWorkHours1) AS TotalWorkHours1Prev3Weeks,
                   SUM(ProcessWorkHours2) AS TotalWorkHours2Prev3Weeks,
                   SUM(ProcessWorkHours3) AS TotalWorkHours3Prev3Weeks,
                   SUM(ProcessWorkHours4) AS TotalWorkHours4Prev3Weeks,
                   SUM(ProcessWorkHours5) AS TotalWorkHours5Prev3Weeks,
                   SUM(ProcessWorkHours6) AS TotalWorkHours6Prev3Weeks,
                   SUM(ProcessWorkHours7) AS TotalWorkHours7Prev3Weeks
            FROM PlanTPOTargetProductionKelompok
            WHERE TPKTPOStartProductionDate >= @startdate
              AND TPKTPOStartProductionDate <= @endate
              AND ProdGroup = @prodGroup
              AND ProcessGroup = @processGroup
              AND LocationCode = @locationCode
              AND StatusEmp = @statusEmp
              AND BrandCode = @brandCode
            GROUP BY ProdGroup,
                     ProcessGroup,
                     LocationCode,
                     StatusEmp,
                     BrandCode;
     RETURN;
     END;
GO


