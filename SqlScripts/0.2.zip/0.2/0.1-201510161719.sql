/* Transaction Flow */
CREATE FUNCTION GetTransactionFlow
(	
	@functionName VARCHAR(64)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT uflow.IDFlow,urole.RolesName,uflow.MessageText FROM UtilFunctions ufunc
	INNER JOIN UtilFlows uflow ON uflow.FormSource = ufunc.IDFunction
	INNER JOIN UtilRoles urole ON urole.IDRole = uflow.DestinationRole
	WHERE ufunc.FunctionName = @functionName	
)
GO
