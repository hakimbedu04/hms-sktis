SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON

GO
ALTER TABLE dbo.MntcInventory
	DROP CONSTRAINT FK_MNTCINVENTORY_REFERENCE_135_MSTMNTCITEMLOCATION
GO
ALTER TABLE dbo.MstMntcItemLocation SET (LOCK_ESCALATION = TABLE)
GO

GO
CREATE TABLE dbo.Tmp_MntcInventory
	(
	InventoryDate datetime NOT NULL,
	ItemStatus varchar(32) NOT NULL,
	ItemCode varchar(20) NOT NULL,
	LocationCode varchar(8) NOT NULL,
	ItemType varchar(16) NULL,
	UOM varchar(8) NULL,
	BeginningStock int NULL,
	StockIn int NULL,
	StockOut int NULL,
	EndingStock int NULL,
	UnitCode varchar(4) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_MntcInventory SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.MntcInventory)
	 EXEC('INSERT INTO dbo.Tmp_MntcInventory (InventoryDate, ItemStatus, ItemCode, LocationCode, ItemType, UOM, BeginningStock, StockIn, StockOut, EndingStock, UnitCode)
		SELECT InventoryDate, ItemStatus, ItemCode, LocationCode, ItemType, UOM, BeginningStock, StockIn, StockOut, EndingStock, UnitCode FROM dbo.MntcInventory WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.MntcInventory
GO
EXECUTE sp_rename N'dbo.Tmp_MntcInventory', N'MntcInventory', 'OBJECT' 
GO
ALTER TABLE dbo.MntcInventory ADD CONSTRAINT
	PK_MNTCINVENTORY PRIMARY KEY NONCLUSTERED 
	(
	InventoryDate,
	ItemStatus,
	ItemCode,
	LocationCode,
	UnitCode
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MntcInventory ADD CONSTRAINT
	FK_MNTCINVENTORY_REFERENCE_135_MSTMNTCITEMLOCATION FOREIGN KEY
	(
	ItemCode,
	LocationCode
	) REFERENCES dbo.MstMntcItemLocation
	(
	ItemCode,
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO