/****** Object:  View [dbo].[MntcInventoryDeltaView]    Script Date: 10/13/2015 14:19:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Script for SelectTopNRows command from SSMS  ******/
Create View [dbo].[MntcInventoryDeltaView] as
SELECT InventoryDate, LocationCode, UnitCode, ItemStatus,ItemCode,
Sum(DeltaStaw) as DBeginningStock ,
sum(DeltaStockIn) as DStockIn,
sum(DeltaStockOut) as DStockOut,
sum(DeltaStak) as DEndingStock
from (
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus, b.ItemCode,
0 DeltaStaw,
0 DeltaStockIn,
sum(SourceStock) as DeltaStockOut, 
-sum(SourceStock) as DeltaStak  
  FROM [MntcEquipmentItemConvert] a,
  [MntcInventory] b
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and b.UnitCode='MTNC'
  and a.SourceStatus=b.ItemStatus
  and a.ItemCodeSource=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus, b.ItemCode,
-sum(SourceStock) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut,
-sum(SourceStock) as DeltaStak  
  FROM [MntcEquipmentItemConvert] a,
  [MntcInventory] b
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and b.UnitCode='MTNC'
  and a.SourceStatus=b.ItemStatus
  and a.ItemCodeSource=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate,b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode, 
0 DeltaStaw,
sum(QtyGood) as DeltaStockIn,
0 DeltaStockOut, 
sum(a.QtyGood) as DeltaStak
FROM [MntcEquipmentItemConvert] a,
  [MntcInventory] b
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and b.UnitCode='MTNC'
  and b.ItemStatus='READY TO USE'
  and a.ItemCodeDestination=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate,b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode, 
+sum(QtyGood) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
+sum(a.QtyGood) as DeltaStak
FROM [MntcEquipmentItemConvert] a,
  [MntcInventory] b
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and b.UnitCode='MTNC'
  and b.ItemStatus='READY TO USE'
  and a.ItemCodeDestination=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
0 DeltaStockIn,
+sum(a.QtyDisposal) as DeltaStockOut, 
-sum(a.QtyDisposal) as DeltaStak
  FROM [MntcEquipmentItemDisposal] a,
  [MntcInventory] b
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and b.UnitCode='MTNC'
  and b.ItemStatus='BAD STOCK'
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
-sum(a.QtyDisposal)as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
-sum(a.QtyDisposal) as DeltaStak
  FROM [MntcEquipmentItemDisposal] a,
  [MntcInventory] b
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and b.UnitCode='MTNC'
  and b.ItemStatus='BAD STOCK'
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStak,
0 DeltaStockIn,
sum(QtyTransfer) as DeltaStockOut, 
-sum(QtyTransfer) as DeltaStaw
  FROM [MntcEquipmentMovement] a,
  [MntcInventory] b    
  where a.TransferDate=b.InventoryDate
  and  a.LocationCodeSource=b.LocationCode
  and ((a.LocationCodeSource like 'REG%' and b.UnitCode='WHSE' and b.ItemStatus='IN TRANSIT')
  or (a.LocationCodeSource like 'ID%' and b.UnitCode='MTNC' and b.ItemStatus='READY TO USE'))
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
-sum(QtyTransfer) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
-sum(QtyTransfer) as DeltaStaw
  FROM [MntcEquipmentMovement] a,
  [MntcInventory] b    
  where a.TransferDate<b.InventoryDate
  and  a.LocationCodeSource=b.LocationCode
  and ((a.LocationCodeSource like 'REG%' and b.UnitCode='WHSE' and b.ItemStatus='IN TRANSIT')
  or (a.LocationCodeSource like 'ID%' and b.UnitCode='MTNC' and b.ItemStatus='READY TO USE'))
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyReceive) as DeltaStockIn,
0 DeltaStockOut, 
sum(QtyReceive) as DeltaStak
  FROM [MntcEquipmentMovement] a,
  [MntcInventory] b    
  where a.ReceiveDate=b.InventoryDate
  and  a.LocationCodeDestination=b.LocationCode
  and  a.UnitCodeDestination=b.UnitCode 
  and ((a.LocationCodeSource like 'REG%' and b.UnitCode='WHSE' and b.ItemStatus='IN TRANSIT')
  or (a.LocationCodeSource like 'ID%' and b.UnitCode='MTNC' and b.ItemStatus='READY TO USE')
  or (a.LocationCodeSource like 'ID%' and b.UnitCode<>'MTNC' and b.ItemStatus='ON USED'))
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyReceive) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyReceive) as DeltaStak
  FROM [MntcEquipmentMovement] a,
  [MntcInventory] b    
  where a.ReceiveDate<b.InventoryDate
  and  a.LocationCodeDestination=b.LocationCode
  and  a.UnitCodeDestination=b.UnitCode 
  and ((a.LocationCodeSource like 'REG%' and b.UnitCode='WHSE' and b.ItemStatus='IN TRANSIT')
  or (a.LocationCodeSource like 'ID%' and b.UnitCode='MTNC' and b.ItemStatus='READY TO USE')
  or (a.LocationCodeSource like 'ID%' and b.UnitCode<>'MTNC' and b.ItemStatus='ON USED'))
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
0 DeltaStockIn,
sum(QtyReceiving) as DeltaStockOut, 
-sum(QtyReceiving) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='IN TRANSIT' 
  and a.ItemCode=b.ItemCode
  and b.BeginningStock>0
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
-sum(QtyReceiving) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
-sum(QtyReceiving) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='IN TRANSIT' 
  and a.ItemCode=b.ItemCode
  and b.BeginningStock>0
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyReceiving) as  DeltaStockIn,
sum(QtyPass+QtyReject+QtyReturn) as DeltaStockOut, 
sum(QtyReceiving-(QtyPass+QtyReject+QtyReturn)) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='ON QUALITY INSPECTION' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyReceiving-(QtyPass+QtyReject+QtyReturn)) DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyReceiving-(QtyPass+QtyReject+QtyReturn)) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='ON QUALITY INSPECTION' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyPass) as  DeltaStockIn,
0 DeltaStockOut, 
sum(QtyPass) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='READY TO USE' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyPass) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyPass) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='READY TO USE' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyReject) as  DeltaStockIn,
0 DeltaStockOut, 
sum(QtyReject) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='BAD STOCK' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyReject) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyReject) as DeltaStak
  FROM [MntcEquipmentQualityInspection] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  b.UnitCode='MTNC'
  and  b.ItemStatus='BAD STOCK' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyRepairRequest) as DeltaStockIn,
sum(QtyCompletion+QtyBadStock) as DeltaStockOut, 
sum(QtyRepairRequest-(QtyCompletion+QtyBadStock)) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='ON REPAIR' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyRepairRequest-(QtyCompletion+QtyBadStock)) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyRepairRequest-(QtyCompletion+QtyBadStock)) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='ON REPAIR' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyCompletion) as DeltaStockIn,
sum(QtyTakenByUnit) as DeltaStockOut, 
sum(QtyCompletion-QtyTakenByUnit) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='READY TO USE' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyCompletion-QtyTakenByUnit) as  DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyCompletion-QtyTakenByUnit) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='READY TO USE' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyTakenByUnit) as DeltaStockIn,
sum(QtyRepairRequest) as DeltaStockOut, 
sum(QtyTakenByUnit-QtyRepairRequest) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='ON USE' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyTakenByUnit-QtyRepairRequest) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyTakenByUnit-QtyRepairRequest) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='ON USE' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(QtyBadStock) as DeltaStockIn,
0 DeltaStockOut, 
sum(QtyBadStock) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='BAD STOCK' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(QtyBadStock) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(QtyBadStock) as DeltaStak
  FROM [MntcEquipmentRepair] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='BAD STOCK' 
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
0 DeltaStockIn,
sum(AdjustmentValue) as DeltaStockOut, 
-sum(AdjustmentValue) as DeltaStak
  FROM [MntcInventoryAdjustment] a,
  [MntcInventory] b        
  where a.AdjustmentDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  a.ItemStatusFrom=b.ItemStatus
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
0 DeltaStockIn,
sum(AdjustmentValue) as DeltaStockOut, 
-sum(AdjustmentValue) as DeltaStak
  FROM [MntcInventoryAdjustment] a,
  [MntcInventory] b        
  where a.AdjustmentDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  a.ItemStatusFrom=b.ItemStatus
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL  
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
-sum(AdjustmentValue) as  DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
-sum(AdjustmentValue) as DeltaStak
  FROM [MntcInventoryAdjustment] a,
  [MntcInventory] b        
  where a.AdjustmentDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  a.ItemStatusFrom=b.ItemStatus
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
sum(AdjustmentValue) as  DeltaStockIn,
0 DeltaStockOut, 
sum(AdjustmentValue) as DeltaStak
  FROM [MntcInventoryAdjustment] a,
  [MntcInventory] b        
  where a.AdjustmentDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  a.ItemStatusTo=b.ItemStatus
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL  
SELECT  b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
sum(AdjustmentValue) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
sum(AdjustmentValue) as DeltaStak
  FROM [MntcInventoryAdjustment] a,
  [MntcInventory] b        
  where a.AdjustmentDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  a.ItemStatusTo=b.ItemStatus
  and a.ItemCode=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
0 DeltaStaw,
0 DeltaStockIn,
sum(QtyUsage) as DeltaStockOut, 
-sum(QtyUsage) as DeltaStak
  FROM [MntcRepairItemUsage] a,
  [MntcInventory] b        
  where a.TransactionDate=b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='READY TO USE'
  and a.ItemCodeDestination=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
UNION ALL
SELECT b.InventoryDate, b.LocationCode,b.UnitCode,
b.ItemStatus,b.ItemCode,
-sum(QtyUsage) as DeltaStaw,
0 DeltaStockIn,
0 DeltaStockOut, 
-sum(QtyUsage) as DeltaStak
  FROM [MntcRepairItemUsage] a,
  [MntcInventory] b        
  where a.TransactionDate<b.InventoryDate
  and  a.LocationCode=b.LocationCode
  and  a.UnitCode=b.UnitCode
  and  b.ItemStatus='READY TO USE'
  and a.ItemCodeDestination=b.ItemCode
group by b.InventoryDate, b.LocationCode,b.UnitCode,b.ItemStatus, b.ItemCode  
) as x  group by InventoryDate, LocationCode, UnitCode, ItemStatus, ItemCode  

GO


