-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE GetWorkerBrandAssignmentPlanningPlantTPK
    @GroupCode			   VARCHAR(20),
    @ProcessSettingsCode	   VARCHAR(50),
    @Year				   INT,
    @Week				   INT,
    @UnitCode			   varchar(20),
    @LocationCode		   varchar(50),
    @BrandCode			   varchar(50),
    @Shift			   varchar(2),
    @TPKPlantStartProdDate  date 
AS
BEGIN

DECLARE @StartDate DATE, 
	   @EndDate   DATE; 

SELECT @StartDate = mgw.StartDate, @EndDate = mgw.EndDate FROM dbo.MstGenWeek mgw WHERE mgw.Week = @Week AND mgw.[Year] = @Year;

SELECT mpejda.EmployeeID EmployeeNumber,
	  CASE
           WHEN EXISTS( SELECT ppa.EmployeeID FROM dbo.PlanPlantAllocation ppa 
				    WHERE	  ppa.EmployeeID = mpejda.EmployeeID AND
						  ppa.KPSYear = @Year AND
						  ppa.KPSWeek = @Week AND
						  ppa.GroupCode = @GroupCode AND
						  ppa.UnitCode = @UnitCode AND
						  ppa.TPKPlantStartProductionDate = @TPKPlantStartProdDate)
				THEN '1'
                    ELSE '0'
           END Status
FROM dbo.MstPlantEmpJobsDataAcv mpejda
    INNER JOIN dbo.ExePlantWorkerAbsenteeism epwa ON epwa.EmployeeID=mpejda.EmployeeID
WHERE mpejda.GroupCode = @GroupCode
  AND mpejda.ProcessSettingsCode = @ProcessSettingsCode
  AND epwa.StartDateAbsent <= @StartDate
  AND epwa.EndDate >= @EndDate;

END;
GO