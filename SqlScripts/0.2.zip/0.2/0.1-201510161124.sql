/* Alter function for extending the parameters (add @date parameter) */
ALTER FUNCTION [dbo].[GetEquipmentRequirementReport] 
(	
	@locationcode AS VARCHAR(20),
	@brandGroupCode AS VARCHAR(20),
	@userEntryPackage AS REAL,
	@date AS DATE
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT 
		mgbpi.BrandGroupCode,
		mgbpi.ItemCode,
		mmi.ItemDescription, 
		SUM(COALESCE(mi.EndingStock,0)) AS realStockQty,
		mgbpi.Qty,
		mtp.Package * mgbpi.Qty AS currentQty,
		@userEntryPackage * mgbpi.Qty AS calculateQty,
		((mtp.Package * mgbpi.Qty)-(@userEntryPackage * mgbpi.Qty)) AS varianceQty
	FROM MstGenBrandPackageItem mgbpi 
	LEFT JOIN MntcInventory mi ON mi.ItemCode = mgbpi.ItemCode
	INNER JOIN MstMntcItem mmi ON mmi.ItemCode = mgbpi.ItemCode
	INNER JOIN MstTPOPackage mtp ON mtp.BrandGroupCode = mgbpi.BrandGroupCode
	WHERE 
		mgbpi.BrandGroupCode=@brandGroupCode AND
		mi.ItemStatus IN ('Ready To Use','On Used') AND
		mi.InventoryDate = CAST(@date as DATE) AND
		mi.LocationCode = @locationcode AND
		mtp.LocationCode = @locationcode
	GROUP BY
		mgbpi.BrandGroupCode,
		mgbpi.ItemCode,
		mmi.ItemDescription, 
		mgbpi.Qty,
		mtp.Package
)
GO


