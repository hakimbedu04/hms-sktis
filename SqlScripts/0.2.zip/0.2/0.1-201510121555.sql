/****** Object:  View [dbo].[MaintenanceEquipmentFulfillmentView]    Script Date: 12/10/2015 15:53:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[MaintenanceEquipmentFulfillmentView]
AS
SELECT mef.FulFillmentDate,
       mef.RequestNumber,
       mef.ItemCode,
       mmi.ItemDescription,
       mef.LocationCode,
       table1.ReadyToUse,
       table1.OnUse,
       table1.OnRepair,
       mer.Qty AS RequestedQuantity,
       mef.PurchaseQty + mef.RequestToQty AS ApprovedQuantity,
       mef.RequestToQty RequestToOthersQuantity,
       mef.PurchaseQty,
       mef.PurchaseNumber,
       mef.CreatedDate,
       mer.CreatedBy,
       mef.UpdatedDate,
       mef.UpdatedBy
FROM MntcEquipmentFulfillment mef
     INNER JOIN dbo.MstMntcItem mmi ON mmi.ItemCode = mef.ItemCode
     LEFT JOIN( 
                 SELECT ItemCode,
                        LocationCode,
                        [Ready to Use] AS ReadyToUse,
                        [On Used] AS OnUse,
                        [On Repair] AS OnRepair
                 FROM(
                          SELECT mi.ItemStatus,
                                 mi.ItemCode,
                                 mi.LocationCode,
                                 mi.EndingStock
                          FROM dbo.MntcInventory mi ) AS A PIVOT( MAX(EndingStock) FOR ItemStatus IN( [Ready to Use],
                                                                                                      [On Used],
                                                                                                      [On Repair] )) AS EquipmentRequestView ) AS table1 ON table1.ItemCode = mef.ItemCode
                                                                                                                                                        AND table1.LocationCode = mef.LocationCode
     LEFT JOIN MntcEquipmentRequest mer ON mer.ItemCode = mef.ItemCode
                                        AND mer.LocationCode = mef.LocationCode
								AND mer.ItemCode = mmi.ItemCode
								AND table1.LocationCode = mer.LocationCode
								
GO


