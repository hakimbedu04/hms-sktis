CREATE FUNCTION [dbo].[GetTotalActualProductionPrev3Weeks](
                @year AS         INT,
                @week AS         INT,
                @prodGroup AS    CHAR(4),
                @processGroup AS VARCHAR(16),
                @locationCode AS VARCHAR(8),
                @statusEmp AS    VARCHAR(16),
                @brandCode AS    VARCHAR(11))
RETURNS @total TABLE( TotalActualProductionPrev3Weeks INT )
AS
     BEGIN
     DECLARE @startdate DATE;
     DECLARE @endate DATE;
     SELECT @startdate = MIN(StartDate),
            @endate = MAX(enddate)
     FROM GetPastWeek( @year, @week, 3 ) past
          INNER JOIN MstGenWeek week ON week.Year = past.year
                                    AND week.Week = past.week;
     INSERT INTO @total
            SELECT SUM(ActualProduction) AS TotalActualProductionPrev3Weeks
            FROM ExeTPOProduction
            WHERE TPKTPOStartProductionDate >= @startdate
              AND TPKTPOStartProductionDate <= @endate
              AND ProdGroup = @prodGroup
              AND ProcessGroup = @processGroup
              AND LocationCode = @locationCode
              AND StatusEmp = @statusEmp
              AND BrandCode = @brandCode
            GROUP BY ProdGroup,
                     ProcessGroup,
                     LocationCode,
                     StatusEmp,
                     BrandCode;
     RETURN;
     END;

GO


