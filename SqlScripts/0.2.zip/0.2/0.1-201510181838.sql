Create View dbo.[MaintenanceEquipmentFulfillmentItemDetailView]

AS

SELECT        TOP (100) PERCENT dbo.MntcInventory.ItemCode, dbo.MstMntcItem.ItemDescription, dbo.MntcInventory.ItemStatus, dbo.MntcInventory.EndingStock, 
                         dbo.MntcInventory.LocationCode, dbo.MntcInventory.InventoryDate
FROM            dbo.MstMntcItem INNER JOIN
                         dbo.MntcInventory ON dbo.MstMntcItem.ItemCode = dbo.MntcInventory.ItemCode
ORDER BY dbo.MntcInventory.InventoryDate DESC

GO