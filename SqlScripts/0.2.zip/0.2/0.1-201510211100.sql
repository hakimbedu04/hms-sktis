/* Appending Shift Column and set as Primary Key Also */
ALTER TABLE dbo.ExePlantWorkerAbsenteeism ADD
	Shift int DEFAULT 1 NOT NULL
GO
ALTER TABLE dbo.ExePlantWorkerAbsenteeism
	DROP CONSTRAINT PK_ExePlantWorkerAbsenteeism_1
GO
ALTER TABLE dbo.ExePlantWorkerAbsenteeism ADD CONSTRAINT
	PK_ExePlantWorkerAbsenteeism_1 PRIMARY KEY CLUSTERED 
	(
	StartDateAbsent,
	EmployeeID,
	Shift
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExePlantWorkerAbsenteeism SET (LOCK_ESCALATION = TABLE)
GO
