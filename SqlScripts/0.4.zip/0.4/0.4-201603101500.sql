USE [SKT_DEV]
GO

/****** Object:  View [dbo].[ExeProductionEntryMinimumValue]    Script Date: 10-Mar-16 2:22:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Description: update view, minstick perhour => (minimal stick / uom eblek) and stdStickPerhour => (stdStickPerhour / UomEblek)
-- Ticket: http://tp.voxteneo.co.id/entity/3613
-- Author: Ardi
-- version : 1.1

-- Description: get minimum value for validation actual value production entry
-- Ticket: http://tp.voxteneo.co.id/entity/3613
-- Author: Ardi

ALTER VIEW [dbo].[ExeProductionEntryMinimumValue]
AS 
SELECT					 l.LocationCode, p.IDProcess, p.BrandGroupCode, u.UnitCode, brnd.BrandCode, p.ProcessGroup, pg.GroupCode, (p.StdStickPerHour / p.UOMEblek) as StdStickPerHour, (p.MinStickPerHour / p.UOMEblek) as MinimalStickPerHour, p.UOMEblek,loc.Shift

FROM				     dbo.MstGenProcessSettingsLocation AS l INNER JOIN
                         dbo.MstGenProcessSettingsMapping AS m ON m.ProcessSettingsLocationID = l.ID INNER JOIN
                         dbo.MstGenProcessSettings AS p ON p.ID = m.ProcessSettingsID INNER JOIN
                         dbo.MstGenLocation AS loc ON loc.LocationCode = l.LocationCode INNER JOIN
                         dbo.MstGenProcess AS pro ON pro.ProcessGroup = p.ProcessGroup INNER JOIN
                         dbo.MstGenBrandGroup AS b ON b.BrandGroupCode = p.BrandGroupCode INNER JOIN
						 dbo.MstGenBrand as brnd ON brnd.BrandGroupCode = p.BrandGroupCode INNER JOIN
						 dbo.MstPlantUnit as u ON u.LocationCode = l.LocationCode INNER JOIN
						 dbo.MstPlantProductionGroup as pg ON pg.LocationCode = l.LocationCode and pg.UnitCode = u.UnitCode and pg.ProcessGroup = p.ProcessGroup

GO


