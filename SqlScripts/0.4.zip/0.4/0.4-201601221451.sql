/****** Object:  StoredProcedure [dbo].[GetReportSummaryDailyProductionTargets]    Script Date: 1/22/2016 10:37:01 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		azka
-- Updated date: 2016/01/18
-- Description:	alter procedure GetReportSummaryDailyProductionTargets
-- =============================================

-- =============================================
-- Author:		azka
-- Updated date: 2016/01/22
-- Description:	alter procedure GetReportSummaryDailyProductionTargets
-- =============================================

ALTER PROCEDURE [dbo].[GetReportSummaryDailyProductionTargets] 
	@Year int,
	@Week int,
	@Decimal int,
	@LocationCode VARCHAR(20)
AS
BEGIN
    DECLARE @DateFrom DATETIME, @DateTo DATETIME
    DECLARE @Location VARCHAR(10)
	DECLARE @LocationChild VARCHAR(10)

	SELECT @DateFrom = dbo.MstGenWeek.StartDate, @DateTo = dbo.MstGenWeek.EndDate FROM dbo.MstGenWeek WHERE dbo.MstGenWeek.[Year] = @Year AND dbo.MstGenWeek.Week = @Week

		SELECT BrandCode, LocationCode,
			TargetManual1,
			TargetManual2,
			TargetManual3,
			TargetManual4,
			TargetManual5,
			TargetManual6,
			TargetManual7
		FROM PlanTPOTargetProductionKelompokBox AS box WHERE box.KPSYear = @Year AND box.KPSWeek = @Week 
			AND LocationCode IN 
			(
				SELECT locationcode FROM GetLastChildLocation(@LocationCode)
			)
		UNION
		SELECT BrandCode, LocationCode,
			SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
			SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
			SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
			SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
			SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
			SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
			SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
		FROM dbo.PlanTargetProductionUnit ptpu WHERE ptpu.ProductionStartDate >= @DateFrom 
			AND ptpu.ProductionStartDate <= @DateTo 
			AND LocationCode IN 
			(
				SELECT locationcode FROM GetLastChildLocation(@LocationCode)
			)
		GROUP BY BrandCode, LocationCode	
END

