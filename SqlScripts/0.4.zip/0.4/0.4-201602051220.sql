/****** Object:  Table [dbo].[PlanPlantWIPDetail]    Script Date: 2/5/2016 12:16:30 PM ******/
DROP TABLE [dbo].[PlanPlantWIPDetail]
GO

/****** Object:  Table [dbo].[PlanPlantWIPDetail]    Script Date: 2/5/2016 12:16:30 PM ******/
/*Created By Indra Permana*/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[PlanPlantWIPDetail](
	[KPSYear] [int] NOT NULL,
	[KPSWeek] [int] NOT NULL,
	[ProcessGroup] [varchar](16) NOT NULL,
	[UnitCode] [varchar](4) NULL,
	[LocationCode] [varchar](8) NOT NULL,
	[BrandCode] [varchar](11) NOT NULL,
	[WIPCurrentValue] [int] NULL,
	[WIPPreviousValue] [int] NULL,
	[WIPStock1] [int] NULL,
	[WIPStock2] [int] NULL,
	[WIPStock3] [int] NULL,
	[WIPStock4] [int] NULL,
	[WIPStock5] [int] NULL,
	[WIPStock6] [int] NULL,
	[WIPStock7] [int] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](64) NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
	[UpdatedBy] [varchar](64) NOT NULL,
 CONSTRAINT [PK_PlanPlantWIPDetail] PRIMARY KEY CLUSTERED 
(
	[KPSYear] ASC,
	[KPSWeek] ASC,
	[ProcessGroup] ASC,
	[LocationCode] ASC,
	[BrandCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


