-- =============================================
-- Description: Create View ExeReportProdStockProcessView
-- Ticket: http://tp.voxteneo.co.id/entity/3044
-- Author: Azka
-- =============================================

/****** Object:  View [dbo].[ExeReportProdStockProcessView]    Script Date: 2/29/2016 9:45:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [ExeReportProdStockProcessView]
AS
WITH BeginStock AS
(
	SELECT BrandGroupCode, BrandCode, LocationCode, UnitCode, ProductionDate, KPSYear, KPSWeek, [11] AS BeginStockInternalMove, [13] AS BeginStockExternalMove, Production, Planning, VarianceStick, VariancePercent
	FROM 
	(
		SELECT 
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.UnitCode,
			ep.LocationCode, 
			ep.UOMOrder,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek, 
			ep.BeginningStock,
			bygroup.Production,
			SUM(ISNULL(bygroup.TPKValue, 0)) AS Planning,
			bygroup.Production - SUM(ISNULL(bygroup.TPKValue, 0)) AS VarianceStick,
			COALESCE((bygroup.Production - SUM(ISNULL(bygroup.TPKValue, 0))) / NULLIF(SUM(ISNULL(bygroup.TPKValue, 0)), 0), 0) * 100 AS VariancePercent
		FROM 
			ExeReportByProcess ep INNER JOIN
			ExeReportByGroups bygroup on bygroup.LocationCode = ep.LocationCode AND ep.ProcessGroup = bygroup.ProcessGroup AND bygroup.BrandCode = ep.BrandCode AND ep.UnitCode = bygroup.UnitCode AND bygroup.ProductionDate = ep.ProductionDate INNER JOIN
			MstGenBrand brand on brand.BrandCode = ep.BrandCode
		WHERE 
			UOMOrder in (11,13) AND bygroup.ProcessGroup = 'STAMPING'
		GROUP BY
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.LocationCode, 
			ep.UOMOrder, 
			ep.BeginningStock,
			bygroup.Production,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek,
			ep.UnitCode
	) byProcess
	PIVOT
	(
		SUM(BeginningStock)
		FOR UOMOrder IN ([11], [13])
	) AS piv
),
Movement AS 
(
	SELECT [11] AS PAP, [13] AS PAG
	FROM 
	(
		SELECT 
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.LocationCode,
			ep.UnitCode,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek,
			ep.KeluarBersih, 
			ep.UOMOrder, 
			bygroup.Production,
			SUM(ISNULL(bygroup.TPKValue, 0)) AS Planning,
			bygroup.Production - SUM(ISNULL(bygroup.TPKValue, 0)) AS VarianceStick,
			COALESCE((bygroup.Production - SUM(ISNULL(bygroup.TPKValue, 0))) / NULLIF(SUM(ISNULL(bygroup.TPKValue, 0)), 0), 0) * 100 AS VariancePercent
		FROM 
			ExeReportByProcess ep INNER JOIN
			ExeReportByGroups bygroup on bygroup.LocationCode = ep.LocationCode AND ep.ProcessGroup = bygroup.ProcessGroup AND bygroup.BrandCode = ep.BrandCode AND ep.UnitCode = bygroup.UnitCode AND bygroup.ProductionDate = ep.ProductionDate INNER JOIN
			MstGenBrand brand on brand.BrandCode = ep.BrandCode
		WHERE 
			UOMOrder in (11,13) AND bygroup.ProcessGroup = 'STAMPING'
		GROUP BY
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.LocationCode, 
			ep.UOMOrder,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek,
			ep.LocationCode, 
			ep.UOMOrder, 
			bygroup.Production,
			ep.KeluarBersih,
			ep.UnitCode
	) byProcess
	PIVOT
	(
		SUM(KeluarBersih)
		FOR UOMOrder IN ([11], [13])
	) AS piv
),
EndingStock AS 
(
	SELECT [11] AS EndingStockInternalMove, [13] AS EndingStockExternalMove
	FROM 
	(
		SELECT 
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.LocationCode,
			ep.UnitCode,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek,
			ep.EndingStock,
			ep.UOMOrder, 
			bygroup.Production,
			SUM(ISNULL(bygroup.TPKValue, 0)) AS Planning,
			bygroup.Production - SUM(ISNULL(bygroup.TPKValue, 0)) AS VarianceStick,
			COALESCE((bygroup.Production - SUM(ISNULL(bygroup.TPKValue, 0))) / NULLIF(SUM(ISNULL(bygroup.TPKValue, 0)), 0), 0) * 100 AS VariancePercent
		FROM 
			ExeReportByProcess ep INNER JOIN
			ExeReportByGroups bygroup on bygroup.LocationCode = ep.LocationCode AND ep.ProcessGroup = bygroup.ProcessGroup AND bygroup.BrandCode = ep.BrandCode AND ep.UnitCode = bygroup.UnitCode AND bygroup.ProductionDate = ep.ProductionDate INNER JOIN
			MstGenBrand brand on brand.BrandCode = ep.BrandCode
		WHERE 
			UOMOrder in (11,13) AND bygroup.ProcessGroup = 'STAMPING'
		GROUP BY
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.LocationCode,
			ep.UnitCode,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek,
			ep.BrandCode, 
			ep.UOMOrder, 
			bygroup.Production,
			ep.EndingStock
	) byProcess
	PIVOT
	(
		SUM(EndingStock)
		FOR UOMOrder IN ([11], [13])
	) AS piv
)
SELECT *
FROM BeginStock B
CROSS JOIN Movement M
CROSS JOIN EndingStock E

GO


