-- =============================================
-- Description: Run SSIS for insert ExeReportByGroups monthly
-- Ticket: http://tp.voxteneo.co.id/entity/3038
-- Author: AZKA
-- =============================================

CREATE PROCEDURE [dbo].[RunSSISProductionReportByGroupMonthly]
AS
EXEC [dbo].[usp_ExecAdhocJob]
  @Param = '',
  @dtsxName = N'ProductionReportByGroupMonthly'