/*
   Tuesday, March 8, 20163:41:46 PM
   User: sa
   Server: Robby Prima Suherlan
   Database: SKT_DEV
   Application: 
*/

ALTER TABLE dbo.ExeReportByGroups ADD
	ActualWorker int NULL
GO
ALTER TABLE dbo.ExeReportByGroups SET (LOCK_ESCALATION = TABLE)
GO