USE [SKT_DEV]
GO

/****** Object:  UserDefinedFunction [dbo].[GetKeluarBersihExeReportByProcess]    Script Date: 01/02/2016 14:40:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[GetKeluarBersihExeReportByProcess] (
	@ProcessGroup varchar(16),
	@LocationCode varchar(8),
	@UnitCode varchar(4),
	@BrandCode varchar(11),
	@KPSYear int,
	@KPSWeek int,
	@ProductionDate datetime,
	@ProcessOrder int
) RETURNS FLOAT
AS
	BEGIN
		DECLARE @KeluarBersih FLOAT

		IF (@ProcessGroup = 'CUTTING' OR @ProcessGroup = 'FOILROLL')
		BEGIN
			SELECT @KeluarBersih = Production FROM dbo.ExeReportByProcess 
				where 
						LocationCode = @LocationCode AND
						UnitCode = @UnitCode AND
						BrandCode = @BrandCode AND
						KPSYear = @KPSYear AND
						KPSWeek = @KPSWeek AND
						ProductionDate = @ProductionDate AND
						ProcessGroup = 'STICKWRAPPING'
		END
		ELSE
		BEGIN
			SELECT @KeluarBersih = Production FROM dbo.ExeReportByProcess 
				where 
						LocationCode = @LocationCode AND
						UnitCode = @UnitCode AND
						BrandCode = @BrandCode AND
						KPSYear = @KPSYear AND
						KPSWeek = @KPSWeek AND
						ProductionDate = @ProductionDate AND
						ProcessOrder = (@ProcessOrder +1)
		END

		RETURN @KeluarBersih;
	END;
GO


