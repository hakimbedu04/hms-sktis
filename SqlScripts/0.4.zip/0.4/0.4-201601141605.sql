INSERT INTO [UtilFunctions]
           ([ParentIDFunction]
           ,[FunctionName]
           ,[FunctionType]
           ,[FunctionDescription]
           ,[CreatedDate]
           ,[CreatedBy]
           ,[UpdatedDate]
           ,[UpdatedBy])
     VALUES
           (359
           ,'Approve'
           ,'button'
           ,NULL
           ,'2016-01-14 12:00:00.000'
           ,'PMI\bkristom'
           ,'2016-01-14 12:00:00.000'
           ,'PMI\bkristom'),
           (359
           ,'Revise'
           ,'button'
           ,NULL
           ,'2016-01-14 12:00:00.000'
           ,'PMI\bkristom'
           ,'2016-01-14 12:00:00.000'
           ,'PMI\bkristom')
GO


