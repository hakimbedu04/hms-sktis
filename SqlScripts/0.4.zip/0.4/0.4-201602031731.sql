-- =============================================
-- Description: DROP column BrandCode on TPOFeeHdr & TPOFeeHdrPlan
-- Ticket: http://tp.voxteneo.co.id/entity/3189
-- Author: Dwi Yudha
-- =============================================

ALTER TABLE dbo.TPOFeeHdr
	DROP CONSTRAINT FK_TPOFEEHDR_RELATIONSHIP_87_MSTGENBRAND
GO
ALTER TABLE dbo.TPOFeeHdrPlan
	DROP CONSTRAINT FK_TPOFEEHDRPLAN_RELATIONSHIP_144_MSTGENBRAND
GO
ALTER TABLE dbo.MstGenBrand SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.TPOFeeHdr
	DROP COLUMN BrandCode
GO
ALTER TABLE dbo.TPOFeeHdr SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.TPOFeeHdrPlan
	DROP COLUMN BrandCode
GO
ALTER TABLE dbo.TPOFeeHdrPlan SET (LOCK_ESCALATION = TABLE)
GO