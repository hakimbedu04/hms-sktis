ALTER TABLE dbo.ExePlantProductionEntry ADD
	IsFromAbsenteeism bit NULL