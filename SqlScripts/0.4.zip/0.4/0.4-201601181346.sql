/****** Object:  StoredProcedure [dbo].[GetReportSummaryDailyProductionTargets]    Script Date: 1/18/2016 9:37:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		azka
-- Updated date: 2016/01/18
-- Description:	alter procedure GetReportSummaryDailyProductionTargets
-- =============================================
ALTER PROCEDURE [dbo].[GetReportSummaryDailyProductionTargets] 
	@Year int,
	@Week int,
	@Decimal int,
	@LocationCode VARCHAR(20)
AS
BEGIN
    DECLARE @DateFrom DATETIME, @DateTo DATETIME
    DECLARE @Location VARCHAR(10)
	DECLARE @LocationChild VARCHAR(10)

	SELECT @DateFrom = dbo.MstGenWeek.StartDate, @DateTo = dbo.MstGenWeek.EndDate FROM dbo.MstGenWeek WHERE dbo.MstGenWeek.[Year] = @Year AND dbo.MstGenWeek.Week = @Week

	SELECT @Location = locationcode FROM MstGenLocation loc WHERE ParentLocationCode = @LocationCode

	IF @LocationCode = 'SKT'
	BEGIN
		SELECT BrandCode, LocationCode,
			SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
			SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
			SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
			SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
			SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
			SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
			SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
		FROM PlanTPOTargetProductionKelompok AS ptpk WHERE (ProcessGroup = 'STAMPING' OR ProcessGroup = 'WRAPPING') 
			AND ptpk.TPKTPOStartProductionDate >= @DateFrom AND ptpk.TPKTPOStartProductionDate <= @DateTo 
			AND LocationCode IN 
			(
				SELECT locationcode from MstGenLocation where ParentLocationCode in (select locationcode from MstGenLocation where ParentLocationCode = 'SKT')
				UNION
				SELECT locationcode from MstGenLocation where ParentLocationCode in (select locationcode from MstGenLocation where ParentLocationCode = 'TPO')
			)
		GROUP BY BrandCode, LocationCode
		UNION
		SELECT BrandCode, LocationCode,
			SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
			SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
			SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
			SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
			SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
			SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
			SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
		FROM dbo.PlanTargetProductionUnit ptpu WHERE ptpu.ProductionStartDate >= @DateFrom 
			AND ptpu.ProductionStartDate <= @DateTo 
			AND LocationCode IN 
			(
				SELECT locationcode from MstGenLocation where ParentLocationCode in (select locationcode from MstGenLocation where ParentLocationCode = 'SKT')
				UNION
				SELECT locationcode from MstGenLocation where ParentLocationCode in (select locationcode from MstGenLocation where ParentLocationCode = 'TPO')
			)
		GROUP BY BrandCode, LocationCode	
	END;
	ELSE
	BEGIN
		IF @Location IS NOT NULL
		BEGIN
				SELECT @LocationChild  = LocationCode FROM MstGenLocation loc WHERE ParentLocationCode IN (select locationcode from MstGenLocation where ParentLocationCode = @LocationCode)

				IF @LocationChild IS NOT NULL
					BEGIN
						SELECT BrandCode, LocationCode,
							SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
							SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
							SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
							SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
							SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
							SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
							SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
						FROM PlanTPOTargetProductionKelompok AS ptpk WHERE (ProcessGroup = 'STAMPING' OR ProcessGroup = 'WRAPPING') 
							AND ptpk.TPKTPOStartProductionDate >= @DateFrom AND ptpk.TPKTPOStartProductionDate <= @DateTo 
							AND LocationCode IN (SELECT LocationCode FROM MstGenLocation loc WHERE ParentLocationCode IN (select locationcode from MstGenLocation where ParentLocationCode = @LocationCode))
						GROUP BY BrandCode, LocationCode
						UNION
						SELECT BrandCode, LocationCode,
							SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
							SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
							SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
							SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
							SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
							SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
							SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
						FROM dbo.PlanTargetProductionUnit ptpu WHERE ptpu.ProductionStartDate >= @DateFrom 
						AND ptpu.ProductionStartDate <= @DateTo 
						AND LocationCode IN  (SELECT LocationCode FROM MstGenLocation loc WHERE ParentLocationCode IN (select locationcode from MstGenLocation where ParentLocationCode = @LocationCode))
						GROUP BY BrandCode, LocationCode
					END;
				ELSE
				BEGIN
					SELECT BrandCode, LocationCode,
						SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
						SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
						SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
						SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
						SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
						SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
						SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
					FROM PlanTPOTargetProductionKelompok AS ptpk WHERE (ProcessGroup = 'STAMPING' OR ProcessGroup = 'WRAPPING') 
						AND ptpk.TPKTPOStartProductionDate >= @DateFrom AND ptpk.TPKTPOStartProductionDate <= @DateTo 
						AND LocationCode IN (select locationcode from MstGenLocation where ParentLocationCode = @LocationCode)
					GROUP BY BrandCode, LocationCode
					UNION
					SELECT BrandCode, LocationCode,
						SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
						SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
						SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
						SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
						SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
						SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
						SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
					FROM dbo.PlanTargetProductionUnit ptpu WHERE ptpu.ProductionStartDate >= @DateFrom 
					AND ptpu.ProductionStartDate <= @DateTo 
					AND LocationCode IN (select locationcode from MstGenLocation where ParentLocationCode = @LocationCode)
					GROUP BY BrandCode, LocationCode
				END;
		END;
		ELSE
		BEGIN
		SELECT BrandCode, LocationCode,
					SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
					SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
					SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
					SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
					SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
					SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
					SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
				FROM PlanTPOTargetProductionKelompok AS ptpk WHERE (ProcessGroup = 'STAMPING' OR ProcessGroup = 'WRAPPING') 
					AND ptpk.TPKTPOStartProductionDate >= @DateFrom AND ptpk.TPKTPOStartProductionDate <= @DateTo 
					AND LocationCode = @LocationCode
				GROUP BY BrandCode, LocationCode
				UNION
				SELECT BrandCode, LocationCode,
					SUM(Coalesce(Targetmanual1, 0)) AS TargetManual1,
					SUM(Coalesce(Targetmanual2, 0)) AS TargetManual2,
					SUM(Coalesce(Targetmanual3, 0)) AS TargetManual3,
					SUM(Coalesce(Targetmanual4, 0)) AS TargetManual4,
					SUM(Coalesce(Targetmanual5, 0)) AS TargetManual5,
					SUM(Coalesce(Targetmanual6, 0)) AS TargetManual6,
					SUM(Coalesce(Targetmanual7, 0)) AS TargetManual7
				FROM dbo.PlanTargetProductionUnit ptpu WHERE ptpu.ProductionStartDate >= @DateFrom 
				AND ptpu.ProductionStartDate <= @DateTo 
				AND LocationCode = @LocationCode
				GROUP BY BrandCode, LocationCode
		END;
	END;
	
		

--    SELECT BrandCode,
--	LocationCode,
--	SUM(Coalesce(TargetSystem1, 0)) AS TargetManual1,
--	SUM(Coalesce(TargetSystem2, 0)) AS TargetManual2,
--	SUM(Coalesce(TargetSystem3, 0)) AS TargetManual3,
--	SUM(Coalesce(TargetSystem4, 0)) AS TargetManual4,
--	SUM(Coalesce(TargetSystem5, 0)) AS TargetManual5,
--	SUM(Coalesce(TargetSystem6, 0)) AS TargetManual6,
--	SUM(Coalesce(TargetSystem7, 0)) AS TargetManual7
--FROM dbo.PlanPlantTargetProductionKelompok AS pptpk
--WHERE pptpk.TPKPlantStartProductionDate >= @DateFrom AND pptpk.TPKPlantStartProductionDate <= @DateTo
--GROUP BY BrandCode,
--	LocationCode

END
