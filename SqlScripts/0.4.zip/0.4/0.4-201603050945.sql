USE [SKT_DEV]
GO

/****** Object:  Table [dbo].[MstPlantAbsentType]    Script Date: 3/4/2016 9:36:30 AM ******/
/*
	Created By:		Indra Permana
	Created Date:	2016-03-04
	Desc:			Drop column PrdTargetFg, add Column Calculation
	Refer to ticket http://tp.voxteneo.co.id/entity/3608
*/

ALTER TABLE [dbo].[MstPlantAbsentType]
DROP COLUMN [PrdTargetFg]

ALTER TABLE [dbo].[MstPlantAbsentType]
ADD Calculation varchar(128)
GO


