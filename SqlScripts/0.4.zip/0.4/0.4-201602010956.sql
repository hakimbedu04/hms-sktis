SELECT calc.LocationCode, loc.ABBR, loc.ParentLocationCode, brdgrp.BrandGroupCode, brdgrp.SKTBrandCode, calc.ProcessGroup,
		 SUM(calc.Production) AS Production, calc.ProductionDate, 
		 SUM(calc.TPKValue) AS TPKValue, 
		 SUM(locgroup.WorkerCount) AS WorkerCount, pckg.Package, procsetview.StdStickPerHour

FROM (SELECT * FROM (SELECT exegrp.GroupCode, exegrp.ProcessGroup, genprocess.ProcessOrder, exegrp.LocationCode, 
	 exegrp.Production, exegrp.ProductionDate, exegrp.BrandGroupCode, exegrp.TPKValue
FROM  ExeReportByGroups exegrp INNER JOIN MstGenProcess genprocess ON exegrp.ProcessGroup = genprocess.ProcessGroup) AS Chk
WHERE Chk.ProcessOrder = (SELECT max(genprocess.processorder) FROM ExeReportByGroups exegrp 
		INNER JOIN MstGenProcess genprocess ON exegrp.ProcessGroup = genprocess.ProcessGroup)) calc 
		INNER JOIN MstGenBrandGroup brdgrp ON calc.BrandGroupCode = brdgrp.BrandGroupCode 
		INNER JOIN MstGenLocation loc ON calc.LocationCode = loc.LocationCode 
		INNER JOIN MstTPOProductionGroup locgroup ON calc.LocationCode = locgroup.LocationCode 
		AND calc.ProcessGroup = locgroup.ProcessGroup AND calc.GroupCode = locgroup.ProdGroup 
		INNER JOIN ProcessSettingsAndLocationView procsetview ON calc.LocationCode = procsetview.LocationCode 
		AND calc.BrandGroupCode = procsetview.BrandGroupCode AND 
				   procsetview.ProcessGroup = 'ROLLING' 
		INNER JOIN MstTPOPackage pckg ON calc.LocationCode = pckg.LocationCode AND brdgrp.BrandGroupCode = pckg.BrandGroupCode

WHERE calc.ProductionDate BETWEEN pckg.EffectiveDate AND pckg.ExpiredDate
GROUP BY calc.LocationCode, loc.ABBR, loc.ParentLocationCode, brdgrp.BrandGroupCode, brdgrp.SKTBrandCode, 
		 calc.ProcessGroup, calc.ProductionDate, pckg.Package, procsetview.StdStickPerHour
UNION ALL

SELECT calcs.LocationCode, loc.ABBR, loc.ParentLocationCode, brdgrp.BrandGroupCode, brdgrp.SKTBrandCode, calcs.ProcessGroup, 
	   SUM(calcs.Production) AS Production, calcs.ProductionDate,
	   SUM(calcs.TPKValue) AS TPKValue, 
	   SUM(locgroup.WorkerCount) AS WorkerCount, 0 AS package, procsetview.StdStickPerHour

FROM (SELECT * FROM (SELECT exegrp.GroupCode, exegrp.ProcessGroup, genprocess.ProcessOrder, 
	 exegrp.LocationCode, exegrp.Production, exegrp.ProductionDate, exegrp.BrandGroupCode, exegrp.TPKValue
FROM ExeReportByGroups exegrp 
		INNER JOIN MstGenProcess genprocess ON exegrp.ProcessGroup = genprocess.ProcessGroup) AS Chk
		WHERE Chk.ProcessOrder = (SELECT max(genprocess.processorder) FROM ExeReportByGroups exegrp 
		INNER JOIN MstGenProcess genprocess ON exegrp.ProcessGroup = genprocess.ProcessGroup)) calcs 
		INNER JOIN MstGenBrandGroup brdgrp ON calcs.BrandGroupCode = brdgrp.BrandGroupCode 
		INNER JOIN MstGenLocation loc ON calcs.LocationCode = loc.LocationCode 
		INNER JOIN MstPlantProductionGroup locgroup ON calcs.LocationCode = locgroup.LocationCode 
		AND calcs.ProcessGroup = locgroup.ProcessGroup AND calcs.GroupCode = locgroup.GroupCode 
		INNER JOIN ProcessSettingsAndLocationView procsetview ON calcs.LocationCode = procsetview.LocationCode 
		AND calcs.BrandGroupCode = procsetview.BrandGroupCode AND procsetview.ProcessGroup = 'ROLLING'
GROUP BY calcs.LocationCode, loc.ABBR, loc.ParentLocationCode, brdgrp.BrandGroupCode, brdgrp.SKTBrandCode, 
		 calcs.ProcessGroup, calcs.ProductionDate, procsetview.StdStickPerHour