-- =============================================
-- Description: Run SSIS for insert ExeReportByGroups weekly
-- Ticket: http://tp.voxteneo.co.id/entity/3038
-- Author: AZKA
-- =============================================

CREATE PROCEDURE [dbo].[RunSSISProductionReportByGroupWeekly]
AS
EXEC [dbo].[usp_ExecAdhocJob]
  @Param = '',
  @dtsxName = N'ProductionReportByGroupWeekly'