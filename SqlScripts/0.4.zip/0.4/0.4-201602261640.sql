USE [SKT_DEV]
GO

/****** Object:  View [dbo].[ExeReportDailyProductionAchievementView]    Script Date: 26-Feb-16 4:36:54 PM ******/
--by : Ardi

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [dbo].[ExeReportDailyProductionAchievementView]
AS
select calc.LocationCode,loc.ABBR,calc.BrandCode, loc.ParentLocationCode,brdgrp.BrandGroupCode,brdgrp.SKTBrandCode,calc.ProcessGroup,
	SUM(calc.Production) as Production,calc.ProductionDate,
	SUM (calc.TPKValue) as TPKValue,
	SUM(locgroup.WorkerCount) as WorkerCount,
	pckg.Package,
	procsetview.StdStickPerHour
from(select * from(select exegrp.GroupCode, 
		exegrp.BrandCode, 
		exegrp.ProcessGroup,
		genprocess.ProcessOrder,
		exegrp.LocationCode,
		exegrp.Production,
		exegrp.ProductionDate,
		exegrp.BrandGroupCode,
		exegrp.TPKValue from ExeReportByGroups exegrp 
		Inner Join MstGenProcess genprocess on exegrp.ProcessGroup = genprocess.ProcessGroup ) as Chk
		 
where Chk.ProcessOrder = ( select max(genprocess.processorder) from ExeReportByGroups exegrp 
		
		Inner Join MstGenProcess genprocess on exegrp.ProcessGroup = genprocess.ProcessGroup)) calc
		Inner Join MstGenBrandGroup brdgrp on calc.BrandGroupCode = brdgrp.BrandGroupCode 
		Inner Join MstGenLocation loc on calc.LocationCode = loc.LocationCode
		Inner Join MstTPOProductionGroup locgroup on calc.LocationCode = locgroup.LocationCode and calc.ProcessGroup = locgroup.ProcessGroup  and calc.GroupCode = locgroup.ProdGroup
		Inner Join ProcessSettingsAndLocationView procsetview on calc.LocationCode = procsetview.LocationCode and calc.BrandGroupCode = procsetview.BrandGroupCode and procsetview.ProcessGroup = 'ROLLING'
		Inner Join MstTPOPackage pckg on calc.LocationCode = pckg.LocationCode 
		where calc.ProductionDate 
		between pckg.EffectiveDate and pckg.ExpiredDate
Group By calc.LocationCode,
		 loc.ABBR,
		 calc.BrandCode,
		 loc.ParentLocationCode,
		 brdgrp.BrandGroupCode,
		 brdgrp.SKTBrandCode,
		 calc.ProcessGroup,
		 calc.ProductionDate,
		 pckg.Package,
		 procsetview.StdStickPerHour
Union ALL
	select calcs.LocationCode,loc.ABBR, mstbrnd.BrandCode, loc.ParentLocationCode,brdgrp.BrandGroupCode,brdgrp.SKTBrandCode,calcs.ProcessGroup,
		SUM(calcs.Production) as Production,calcs.ProductionDate,
		SUM (calcs.TPKValue) as TPKValue,
		SUM(locgroup.WorkerCount) as WorkerCount, 0 AS package,procsetview.StdStickPerHour

from(select * from(select exegrp.GroupCode, 
						  exegrp.ProcessGroup,
						  genprocess.ProcessOrder,
						  exegrp.LocationCode,
						  exegrp.Production,
						  exegrp.ProductionDate,
						  exegrp.BrandGroupCode,
						  exegrp.TPKValue 
from ExeReportByGroups exegrp 
	Inner Join MstGenProcess genprocess on exegrp.ProcessGroup = genprocess.ProcessGroup ) as Chk 
		where 
Chk.ProcessOrder = ( select max(genprocess.processorder) from ExeReportByGroups exegrp 
	Inner Join MstGenProcess genprocess on exegrp.ProcessGroup = genprocess.ProcessGroup)) calcs
	Inner Join MstGenBrandGroup brdgrp on calcs.BrandGroupCode = brdgrp.BrandGroupCode 
	Inner Join MstGenLocation loc on calcs.LocationCode = loc.LocationCode
	Inner Join MstPlantProductionGroup locgroup on calcs.LocationCode = locgroup.LocationCode and calcs.ProcessGroup = locgroup.ProcessGroup and calcs.GroupCode = locgroup.GroupCode
	Inner Join ProcessSettingsAndLocationView procsetview on calcs.LocationCode = procsetview.LocationCode and calcs.BrandGroupCode = procsetview.BrandGroupCode and procsetview.ProcessGroup = 'ROLLING'
	inner join MstGenBrand mstbrnd on mstbrnd.BrandGroupCode = calcs.BrandGroupCode
Group By calcs.LocationCode,
		 loc.ABBR,
		 mstbrnd.BrandCode,
		 loc.ParentLocationCode,
		 brdgrp.BrandGroupCode,
		 brdgrp.SKTBrandCode,
		 calcs.ProcessGroup,
		 calcs.ProductionDate,
		 procsetview.StdStickPerHour
GO


