-- =============================================
-- Author: Opun Buds
-- Updated date: 2016/02/01
-- Description:	Alter MstGenProcessSettings add Max Worker Column
-- =============================================
ALTER TABLE dbo.MstGenProcessSettings ADD
	MaxWorker int NULL
