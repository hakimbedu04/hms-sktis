-- Description: Edit columnn to nullable when insert from TPO
-- Author Azka

ALTER TABLE ExePlantWorkerAssignment ALTER COLUMN DestinationGroupCode varchar(4) NULL;
ALTER TABLE ExePlantWorkerAssignment ALTER COLUMN DestinationUnitCode varchar(4) NULL;
ALTER TABLE ExePlantWorkerAssignment ALTER COLUMN DestinationBrandCode varchar(11) NULL;
ALTER TABLE ExePlantWorkerAssignment ALTER COLUMN DestinationProcessGroup varchar(16) NULL;
ALTER TABLE ExePlantWorkerAssignment ALTER COLUMN DestinationLocationCode varchar(8) NULL;