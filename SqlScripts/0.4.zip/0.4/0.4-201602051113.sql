/****** Object:  StoredProcedure [dbo].[InsertMail]    Script Date: 2/5/2016 10:26:45 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description: Insert into Tbl_Mail
-- Ticket: http://tp.voxteneo.co.id/entity/2921
-- Author: AZKA
-- Updated: 1.0 - 05/02/2016
-- =============================================

CREATE PROCEDURE [dbo].[InsertMail] 
-- Add the parameters for the stored procedure here
	   @ServerName			VARCHAR(50),	
       @DBName				VARCHAR(50),
	   @SchemaName			VARCHAR(50),
	   @TableName			VARCHAR(50),
       @FromName			VARCHAR(250),
       @FromEmailAddress	VARCHAR(250),
       @ToName				VARCHAR(250),
       @ToEmailAddress		VARCHAR(250),
       @Subject				VARCHAR(250),
       @BodyMail			VARCHAR(max)
AS
    BEGIN
		DECLARE @SQLInsert nvarchar(max)

		SET @SQLInsert = 'INSERT INTO [' + @ServerName + '].[' + @DBName + '].[' + @SchemaName + '].[' + @TableName + ']
						(
							[txt_system_originated]
							,[txt_from_name]
							,[txt_from_address]
							,[txt_recepient]
							,[txt_email]
							,[txt_subject]
							,[txt_body]
						)
						VALUES
						(
							''SKTIS-DEV'', ''' 
							+ @FromName + ''', ''' 
							+ @FromEmailAddress + ''', ''' 
							+ @ToName + ''', ''' 
							+ @ToEmailAddress + ''', ''' 
							+ @Subject + ''', ''' 
							+ @BodyMail + 
						''')'
	EXEC (@SQLInsert)
    END;


