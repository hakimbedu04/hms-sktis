-- Author: Jejen Suhendar

-- Author: Whisnu Sucitanuary
-- Changes: Add Page Condition for ProductionCardApprovalDetail


-- Versi 1.2
-- Author: Harizal
-- Changes: Add Condition @Page LIKE 'ProductionCard', Source Get from DestinationForm  = 143
ALTER PROCEDURE [dbo].[TransactionLog] 
-- Add the parameters for the stored procedure here
      @Separator        VARCHAR(20),
      @Page             VARCHAR(30),
      @Year             INT,
      @Week             INT,
      @code_1           VARCHAR(16),
      @code_2           VARCHAR(16),
      @code_3           VARCHAR(16),
      @code_4           VARCHAR(16),
      @code_5           VARCHAR(16),
      @code_6           VARCHAR(16),
      @code_7           VARCHAR(16),
      @code_8           VARCHAR(16),
      @code_9           VARCHAR(16),
      @Transaction_Date DATETIME,
      @ActionButton     VARCHAR(16),
      @ActionTime       DATETIME,
      @UserName         VARCHAR(32),
	 @TransactionCode  VARCHAR(128) = NULL
AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        DECLARE @IDFunct         INT,
                @IDButton        INT,
                @IDFlow          INT,
				@RolesCodes		VARCHAR(128),
                --@TransactionCode VARCHAR(128),
                @MessageText     VARCHAR(128);
        -- checking the  page
        -- PLANNING
        IF( @Page LIKE 'WPP%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN				
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'Weekly%';
            END;
        IF( @Page LIKE 'TPU%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN				
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END

			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TargetProductionUnit%';
            END;
        IF( @Page LIKE 'TPKPLANT%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END

			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'PlantTargetProductionGroup%';
            END;
        IF( @Page LIKE 'TPKTPO%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOTargetProductionGroup%';
            END;
        -- MAINTENANCE
        IF( @Page LIKE 'MTNCREQ%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentRequest';
            END;
        IF( @Page LIKE 'MTNCFULL%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentFullfillment';
            END;
        IF( @Page LIKE 'MTNCFULL%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentFullfillment';
            END;
        IF( @Page LIKE 'MTNCTRANS%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentTransfer';
            END;
        IF( @Page LIKE 'MTNCRECV%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentReceive';
            END;
        IF( @Page LIKE 'MTNCREPPLNT%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentRepairPlant';
            END;
        IF( @Page LIKE 'MTNCREPTPO%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentRepairTPO';
            END;
        IF( @Page LIKE 'MTNCQI%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'QualityInspection';
            END;
        -- Plant Execution
        IF( @Page LIKE 'ABSENTEISMP%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'PieceRate';
            END;
        IF( @Page LIKE 'ABSENTEISMD%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'Daily';
            END;
        IF( @Page LIKE 'LOADBALANCINGM%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'MultiSkill';
            END;
        IF( @Page LIKE 'LOADBALANCINGS%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'SingleSkill';
            END;
        IF( @Page LIKE 'PlantProductionEntry%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'PlantProductionEntry%';
            END;
        IF( @Page LIKE 'ProductionEntryVerification' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionEntryVerification';
            END;
        IF( @Page LIKE 'TPOProductionEntry' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END

			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOProductionEntry';
            END;
        IF( @Page LIKE 'TPOProductionEntryVerification%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOProductionEntryVerification%';
            END;
        -- for wages
        IF( @Page LIKE 'ProductionCard' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
	                   SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionCard';
            END;
        IF( @Page LIKE 'ProductionCardRev' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionCardRev';
            END;
	   IF( @Page LIKE 'EblekRelease' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EblekRelease';
            END;
		IF( @Page LIKE 'ProductionCardApprovalDetail' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_7) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_8) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_9);
				END
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionCardApprovalDetail';
            END;
		IF( @Page LIKE 'EblekReleaseApproval' )
			BEGIN
				SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EblekReleaseApproval';
				SELECT TOP 1 @RolesCodes = SourceRolesCodes FROM UtilFlowFunctionView uffv WHERE uffv.UserAD = @UserName;
				IF(@ActionButton LIKE 'Approve')
					BEGIN
							IF(@RolesCodes LIKE 'SPGS')
						begin
							SELECT @IDFlow = IDFlow, @MessageText = MessageText FROM UtilFlowFunctionView uffv 
							WHERE uffv.SourceFunctionForm = 'EblekReleaseApproval' AND uffv.UserAD = @UserName AND uffv.FunctionName = @ActionButton AND uffv.SourceRolesCodes = @RolesCodes AND uffv.DestinationRolesCodes = 'PAY';
							end;
						IF(@RolesCodes LIKE 'PAY')
						begin
							SELECT @IDFlow = IDFlow, @MessageText = MessageText FROM UtilFlowFunctionView uffv 
							WHERE uffv.SourceFunctionForm = 'EblekReleaseApproval' AND uffv.UserAD = @UserName AND uffv.FunctionName = @ActionButton AND uffv.SourceRolesCodes = @RolesCodes AND uffv.DestinationRolesCodes = 'PAAPRD';
							UPDATE ExeProductionEntryRelease SET IsLocked = 0 where ProductionEntryCode = @TransactionCode;
						end;
					END;
					ELSE
					BEGIN
					SELECT @IDFlow = IDFlow, @MessageText = MessageText FROM UtilFlowFunctionView uffv 
							WHERE uffv.SourceFunctionForm = 'EblekReleaseApproval' AND uffv.UserAD = @UserName AND uffv.FunctionName = @ActionButton AND uffv.SourceRolesCodes = @RolesCodes;
					
					END;
				begin
				INSERT INTO UtilTransactionLogs ( TransactionCode, TransactionDate, IDFlow, Comments, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy )
				VALUES( @TransactionCode, @Transaction_Date, @IDFlow, @MessageText, @ActionTime, @UserName, GETDATE(), @UserName );
				end;
				RETURN;
			END;

		  IF( @Page LIKE 'TPOFeeActual' )
			 BEGIN
				IF(@TransactionCode IS NULL OR @TransactionCode = '')
				    BEGIN
					   SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_7) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_8) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_9);
				    END
				SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOFeeActual';
			 END;
		  IF( @Page LIKE 'ApprovalPage' )
			 BEGIN
				IF(@TransactionCode IS NULL OR @TransactionCode = '')
				    BEGIN
					   SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_7) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_8) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_9);
				    END
				SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ApprovalPage';
			 END;
		   IF( @Page LIKE 'TPOFeeAP' )
			 BEGIN
				IF(@TransactionCode IS NULL OR @TransactionCode = '')
				    BEGIN
					   SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_7) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_8) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_9);
				    END
				SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOFeeAP';
			 END;
        -- insert into transaction log table
        BEGIN
            SELECT @IDButton = IDFunction FROM UtilFunctions ufun WHERE ufun.ParentIDFunction = @IDFunct AND ufun.FunctionName = @ActionButton;
            SELECT @IDFlow = IDFlow, @MessageText = MessageText FROM UtilFlows uflow WHERE uflow.FormSource = @IDFunct AND uflow.ActionButton = @IDButton;

		  if(@Page LIKE 'ProductionCard')
		  BEGIN
			 SELECT @IDButton = IDFunction FROM UtilFunctions ufun WHERE ufun.ParentIDFunction = @IDFunct AND ufun.FunctionName = @ActionButton;
			 SELECT @IDFlow = IDFlow, @MessageText = MessageText FROM UtilFlows uflow WHERE uflow.FormSource = @IDFunct AND uflow.ActionButton = @IDButton AND uflow.DestinationForm  = 143;
		  END

            INSERT INTO UtilTransactionLogs ( TransactionCode, TransactionDate, IDFlow, Comments, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy )
            VALUES( @TransactionCode, @Transaction_Date, @IDFlow, @MessageText, @ActionTime, @UserName, GETDATE(), @UserName );
        END;
    END;





