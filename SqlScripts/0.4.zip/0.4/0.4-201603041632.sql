-- Description: get minimum value for validation actual value production entry
-- Ticket: http://tp.voxteneo.co.id/entity/3613
-- Author: Ardi

CREATE VIEW ExeProductionEntryMinimumValue
AS 
SELECT        l.LocationCode, p.IDProcess, p.BrandGroupCode, u.UnitCode, brnd.BrandCode, p.ProcessGroup, pg.GroupCode, p.StdStickPerHour, p.MinStickPerHour, p.UOMEblek, loc.LocationName, loc.ParentLocationCode, loc.CostCenter, loc.ABBR, 
                         loc.Shift, loc.UMK, loc.KPPBC, loc.Address, loc.City, loc.Region, loc.Phone, loc.StatusActive AS StatusActiveLocation, pro.ProcessIdentifier, pro.ProcessOrder, pro.StatusActive AS StatusActiveProcess, pro.WIP, 
                         b.BrandFamily, b.PackType, b.ClassType, b.StickPerPack, b.PackPerSlof, b.SlofPerBal, b.BalPerBox, b.SKTBrandCode, b.Description, b.CapacityPackage, b.CigarreteWeight, b.EmpPackage, b.StickPerBox, 
                         b.StickPerSlof, b.StickPerBal, b.StatusActive AS StatusActiveBrand
						 
FROM            dbo.MstGenProcessSettingsLocation AS l INNER JOIN
                         dbo.MstGenProcessSettingsMapping AS m ON m.ProcessSettingsLocationID = l.ID INNER JOIN
                         dbo.MstGenProcessSettings AS p ON p.ID = m.ProcessSettingsID INNER JOIN
                         dbo.MstGenLocation AS loc ON loc.LocationCode = l.LocationCode INNER JOIN
                         dbo.MstGenProcess AS pro ON pro.ProcessGroup = p.ProcessGroup INNER JOIN
                         dbo.MstGenBrandGroup AS b ON b.BrandGroupCode = p.BrandGroupCode INNER JOIN
						 dbo.MstGenBrand as brnd ON brnd.BrandGroupCode = p.BrandGroupCode INNER JOIN
						 dbo.MstPlantUnit as u ON u.LocationCode = l.LocationCode INNER JOIN
						 dbo.MstPlantProductionGroup as pg ON pg.LocationCode = l.LocationCode and pg.UnitCode = u.UnitCode and pg.ProcessGroup = p.ProcessGroup
GO
