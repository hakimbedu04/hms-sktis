/****** Object:  StoredProcedure [dbo].[InsertMail]    Script Date: 2/11/2016 10:05:40 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Insert into Tbl_Mail
-- Ticket: http://tp.voxteneo.co.id/entity/2921
-- Author: AZKA
-- Updated: 1.0 - 05/02/2016
-- =============================================

ALTER PROCEDURE [dbo].[InsertMail] 
-- Add the parameters for the stored procedure here
       @FromName			VARCHAR(250),
       @FromEmailAddress	VARCHAR(250),
       @ToName				VARCHAR(250),
       @ToEmailAddress		VARCHAR(250),
       @Subject				VARCHAR(250),
       @BodyMail			VARCHAR(max)
AS
    BEGIN
		DECLARE @SQLInsert nvarchar(max)

		SET @BodyMail = REPLACE(@BodyMail, 'webrooturl', 'http://pmiidsubdev33/SKTIS')
		--SET @BodyMail = REPLACE(@BodyMail, 'webrooturl', 'http://skt-is.voxteneo.co.id')

		SET @SQLInsert = 'INSERT INTO [hmssqloltp01prd.id.pmi\PRD03].[db_Intranet_Mail].[dbo].[tbl_mail]
						(
							[txt_system_originated]
							,[txt_from_name]
							,[txt_from_address]
							,[txt_recepient]
							,[txt_email]
							,[txt_subject]
							,[txt_body]
						)
						VALUES
						(
							''SKTIS-DEV'', ''' 
							+ @FromName + ''', ''' 
							+ @FromEmailAddress + ''', ''' 
							+ @ToName + ''', ''' 
							+ @ToEmailAddress + ''', ''' 
							+ @Subject + ''', ''' 
							+ @BodyMail + 
						''')'
	EXEC (@SQLInsert)
    END;



