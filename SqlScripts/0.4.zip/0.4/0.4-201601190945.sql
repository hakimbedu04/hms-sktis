CREATE PROCEDURE [dbo].[RunSSISIndividualCapacity]
AS
EXEC	[dbo].[usp_ExecAdhocJob]
		@Param = '',
		@dtsxName = N'IndividualCapacity'

GO