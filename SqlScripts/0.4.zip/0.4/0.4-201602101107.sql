USE [SKT_DEV]
GO

/****** Object:  StoredProcedure [dbo].[ExtendedExeReportByProcess]    Script Date: 01/02/2016 14:39:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Opun Buds
-- Create date: 18-01-2016
-- Description:	For Packing process group
-- =============================================
CREATE PROCEDURE [dbo].[ExtendedExeReportByProcess]
	-- Add the parameters for the stored procedure here
	@CreatedBy varchar(50),
	@UpdatedBy varchar(50)
AS
BEGIN
	-- INSERT A NEW ROW PACKING
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(6) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'PACKING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 2
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(8) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 2
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(9) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 3
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(10) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 4
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(11) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 5
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(12) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 6
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(13) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup

	-- INSERT A NEW ROW STAMPING 7
	INSERT INTO dbo.ExeReportByProcess
	(
		LocationCode,
		UnitCode,
		BrandCode,
		KPSYear,
		KPSWeek,
		ProductionDate,
		ProcessGroup,
		ProcessOrder,
		Shift,
		Description,
		UOM,
		UOMOrder,
		Production,
		KeluarBersih,
		RejectSample,
		BeginningStock,
		EndingStock,
		CreatedDate,
		CreatedBy,
		UpdatedDate,
		UpdatedBy
	) SELECT
		max(LocationCode) as LocationCode,
		max(UnitCode) as UnitCode,
		max(BrandCode) as BrandCode,
		max(KPSYear) as KPSYear,
		max(KPSWeek) as KPSWeek,
		max(ProductionDate) as ProductionDate,
		max(ProcessGroup) as ProcessGroup,
		max(ProcessOrder) as ProcessOrder,
		max(Shift) as Shift,
		max(Description) as Description,
		max(UOM) as Uom,
		(14) AS UOMOrder,
		max(Production) as Production,
		max(KeluarBersih) as KeluarBersih,
		max(RejectSample) as RejectSample,
		max(BeginningStock) as BeginingStock,
		max(EndingStock) as EndingStock,
		max(CreatedDate) as CreatedDate,
		max(CreatedBy) as CreatedBy,
		max(UpdatedDate) as UpdatedDate,
		max(UpdatedBy) as UpdatedBy
	FROM dbo.ExeReportByProcess WHERE ProcessGroup = 'STAMPING' 
	GROUP BY LocationCode,UnitCode,BrandCode,ProductionDate,ProcessGroup


END

GO


