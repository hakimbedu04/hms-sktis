-- =============================================
-- Description: Fix tpo fee plan calculation
-- Ticket: http://tp.voxteneo.co.id/entity/1745
-- Author: Dwi Yudha
-- Version: 1.1
-- =============================================

-- Description: Generating Production Entry Verification Report
-- Author: Oka

ALTER PROCEDURE [dbo].[SP_SubmitTpoTpk]
      @LocationCode VARCHAR(8),
      @BrandCode    VARCHAR(11),
      @KPSYear      INT,
      @KPSWeek      INT
AS
    BEGIN
        SET NOCOUNT ON;
        -- GLOBAL VARIABLE
        DECLARE @TPOFeeCode VARCHAR(64);
        DECLARE @StickPerBox INT;

        -- GLOBAL DATA
        -- Master General Brand Group	
        DECLARE @BrandGroupCode VARCHAR(20);
        SELECT @BrandGroupCode = bg.BrandGroupCode,
               @StickPerBox = bg.StickPerBox
        FROM MstGenBrandGroup bg
             INNER JOIN MstGenBrand b ON b.BrandGroupCode = bg.BrandGroupCode
        WHERE b.BrandCode = @BrandCode;
        SET @TPOFeeCode = 'FEE/' + @LocationCode + '/' + @BrandGroupCode + '/' + CAST(@KPSYear AS VARCHAR) + '/' + CAST(@KPSWeek AS VARCHAR);

        -- Check TPO Fee Header
        DECLARE @TPOFeeHdrExist INT;
        SELECT @TPOFeeHdrExist = COUNT(*)
        FROM TPOFeeHdrPlan
        WHERE KPSYear = @KPSYear
          AND KPSWeek = @KPSWeek
          AND BrandCode = @BrandCode
          AND LocationCode = @LocationCode;
	  
		DECLARE @StartDate DATETIME;
		DECLARE @EndDate DATETIME;
		SELECT @StartDate = StartDate,
			   @EndDate = EndDate
		FROM MstGenWeek
		WHERE Year = @KPSYear
		  AND Week = @KPSWeek;
		  
		-- Master TPO Package
		DECLARE @TPOPackageValue REAL;
		SELECT @TPOPackageValue = Package
		FROM MstTPOPackage
		WHERE LocationCode = @LocationCode
		  AND BrandGroupCode = @BrandGroupCode
		  AND EffectiveDate <= @StartDate
		  AND ExpiredDate >= @EndDate;
		  
        IF @TPOFeeHdrExist <= 0
            BEGIN	
			
                -- Insert TPO Fee Header
                INSERT INTO TPOFeeHdrPlan
                       ( KPSYear,
                         KPSWeek,
                         BrandGroupCode,
                         BrandCode,
                         LocationCode,
                         CreatedDate,
                         CreatedBy,
                         UpdatedDate,
                         UpdatedBy,
                         TPOFeeCode,
                         Status,
                         StickPerBox,
                         TPOPackageValue
                       )
                       SELECT @KPSYear,
                              @KPSWeek,
                              @BrandGroupCode,
                              @BrandCode,
                              @LocationCode,
                              GETDATE(),
                              'PMI/User',
                              GETDATE(),
                              'PMI/User',
                              @TPOFeeCode,
                              'DRAFT',                       
                              @StickPerBox,
                              @TPOPackageValue;
            END;

        -- Check TPO Fee Production Dialy
        DECLARE @TPOFeeProductionDailyExist INT;
        SELECT @TPOFeeProductionDailyExist = COUNT(*)
        FROM TPOFeeProductionDailyPlan
        WHERE TPOFeeCode = @TPOFeeCode
          AND FeeDate >= @StartDate
          AND FeeDate <= @EndDate
          AND KPSYear = @KPSYear
          AND KPSWeek = @KPSWeek;
		
        DECLARE @HDRTotalProdBox FLOAT = 0;
        DECLARE @HDRTotalProdStick FLOAT = 0;
        DECLARE @HDRTotalProdJKN FLOAT = 0;
        DECLARE @HDRTotalProdJl1 FLOAT = 0;
        DECLARE @HDRTotalProdJl2 FLOAT = 0;
        DECLARE @HDRTotalProdJl3 FLOAT = 0;
        DECLARE @HDRTotalProdJl4 FLOAT = 0;
		
        IF @TPOFeeProductionDailyExist <= 0
            BEGIN
                WHILE @StartDate <= @EndDate
                    BEGIN
						
                        DECLARE @Outputbox FLOAT;
                        SELECT @Outputbox = CASE
                                                WHEN DATENAME(dw, @StartDate) = 'Monday'
                                                THEN TargetManual1
                                                WHEN DATENAME(dw, @StartDate) = 'Tuesday'
                                                THEN TargetManual2
                                                WHEN DATENAME(dw, @StartDate) = 'Wednesday'
                                                THEN TargetManual3
                                                WHEN DATENAME(dw, @StartDate) = 'Thursday'
                                                THEN TargetManual4
                                                WHEN DATENAME(dw, @StartDate) = 'Friday'
                                                THEN TargetManual5
                                                WHEN DATENAME(dw, @StartDate) = 'Saturday'
                                                THEN TargetManual6
                                                WHEN DATENAME(dw, @StartDate) = 'Sunday'
                                                THEN TargetManual7
                                            END
                        FROM PlanTPOTargetProductionKelompokBox
                        WHERE LocationCode = @LocationCode
                          AND KPSYear = @KPSYear
                          AND KPSWeek = @KPSWeek
                          AND BrandCode = @BrandCode;

						IF (@Outputbox IS NULL)
							BEGIN
								SET @Outputbox = 0;
							END;
							
                        -- PlanTPOTargetProductionKelompok
                        DECLARE @OutputSticks REAL;
						SET @OutputSticks = @Outputbox * @StickPerBox;
                          
                        DECLARE @JKNJam FLOAT;
                        DECLARE @Jl1Jam FLOAT;
                        DECLARE @Jl2Jam FLOAT;
                        DECLARE @Jl3Jam FLOAT;
                        DECLARE @Jl4Jam FLOAT;
                        DECLARE @JKNJamStd FLOAT;
                        DECLARE @Jl1JamStd FLOAT;
                        DECLARE @Jl2JamStd FLOAT;
                        DECLARE @Jl3JamStd FLOAT;
                        DECLARE @Jl4JamStd FLOAT;

                        -- Check whether ProductionDate is Holiday (it so skip to JL2Jam)
                        DECLARE @IsHoliday INT;
                        SELECT @IsHoliday = COUNT(*)
                        FROM MstGenHoliday
                        WHERE HolidayDate = @StartDate
                          AND LocationCode = @LocationCode
                          AND StatusActive = '1';

                        -- Standar Hours
                        SELECT @JKNJamStd = JknHour,
                               @Jl1JamStd = Jl1Hour,
                               @Jl2JamStd = Jl2Hour,
                               @Jl3JamStd = Jl3Hour,
                               @Jl4JamStd = Jl4Hour
                        FROM MstGenStandardHours
                        WHERE UPPER(DayType) = UPPER(CASE
                                                         WHEN @IsHoliday > 0
                                                         THEN 'HOLIDAY'
                                                         ELSE 'NON-HOLIDAY'
                                                     END)
                          AND Day = DATEPART(dw, @StartDate);
						  
						DECLARE @JKN FLOAT,
							@JL1 FLOAT,
							@JL2 FLOAT,
							@JL3 FLOAT,
							@JL4 FLOAT,
							@MaxWorker        INT,
							@StdStickPerHours INT,
							@EmpPackage       INT;
						
						-- SET @MaxWorker
						SELECT @MaxWorker = mgpsl.MaxWorker FROM dbo.MstGenProcessSettingsLocation mgpsl WHERE mgpsl.LocationCode = @LocationCode;
			
						-- SET @StdStickPerHours
						SELECT TOP 1 @StdStickPerHours = StdStickPerHour FROM ProcessSettingsAndLocationView
						WHERE dbo.ProcessSettingsAndLocationView.LocationCode = @LocationCode
						  AND dbo.ProcessSettingsAndLocationView.BrandGroupCode = @BrandGroupCode
						  AND dbo.ProcessSettingsAndLocationView.ProcessGroup = 'ROLLING';

						-- SET @EmpPackage
						SELECT @EmpPackage = dbo.MstGenBrandGroup.EmpPackage
						FROM MstGenBrandGroup
						WHERE dbo.MstGenBrandGroup.BrandGroupCode = @BrandGroupCode;
						
						--SELECT @StdStickPerHours = mgps.StdStickPerHour FROM dbo.MstGenProcessSettings mgps WHERE mgps.BrandGroupCode = @BrandGroupCode AND mgps.ProcessGroup='ROLLING'
						-- TODO JKN
						-- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
						-- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JKNJam * 
						-- (Get data EmpPackage from MstGenBrandGroup where Filter) * @StickPerBox
						SET @JKN = ROUND((( @TPOPackageValue * @StdStickPerHours * @JKNJamStd * @EmpPackage ) / @StickPerBox ), 2);

						-- TODO JL1
						-- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
						-- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL1Jam * 
						-- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
						SET @JL1 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl1JamStd * @EmpPackage ) / @StickPerBox ), 2);

						-- TODO JL2
						-- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
						-- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL2Jam * 
						-- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
						SET @JL2 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl2JamStd * @EmpPackage ) / @StickPerBox ), 2);

						-- TODO JL3
						-- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
						-- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL3Jam * 
						-- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
						SET @JL3 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl3JamStd * @EmpPackage ) / @StickPerBox ), 2);

						-- TODO JL4
						-- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
						-- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL4Jam * 
						-- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
						SET @JL4 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl4JamStd * @EmpPackage ) / @StickPerBox ), 2);

						DECLARE @Sisa FLOAT;
						SET @Sisa = ROUND((@Outputbox - @JKN),2);	  
							
						IF @IsHoliday <= 0 
							-- IF NOT HOLIDAY
							BEGIN
								IF( @Sisa < @JL1 )
									BEGIN
										SET @JL1 = @Sisa;
										SET @JL2 = 0;
										SET @JL3 = 0;
										SET @JL4 = 0;
									END;
								ELSE
									BEGIN
										SET @Sisa = ROUND((@Sisa - @JL1), 2);
										
										SET @JL2 = @Sisa;
										SET @JL3 = 0;
										SET @JL4 = 0;
									END;
							END;
						ELSE
							-- IF HOLIDAY
							BEGIN
								SET @JL1 = 0;
								SET @JL2 = @JKN;
								
								IF( @Sisa < @JL3 )
									BEGIN
										SET @JL3 = @Sisa;
										SET @JL4 = 0;
									END;
								ELSE
									BEGIN
										SET @Sisa = ROUND((@Sisa - @JL3), 2);
										
										SET @JL4 = @Sisa;
									END;
								
								SET @JKN = 0;
							END;
							
						SET @JKNJam = @JKN;
						SET @Jl1Jam = @JL1;
						SET @Jl2Jam = @JL2;
						SET @Jl3Jam = @JL3;
						SET @Jl4Jam = @JL4;
						
                        INSERT INTO TPOFeeProductionDailyPlan
                               SELECT @TPOFeeCode,
                                      @StartDate,
                                      @KPSYear,
                                      @KPSWeek,
                                      @OutputSticks,
                                      @Outputbox,
                                      @JKNJam,
                                      @Jl1Jam,
                                      @Jl2Jam,
                                      @Jl3Jam,
                                      @Jl4Jam,
                                      GETDATE(),
                                      'PMI/User',
                                      GETDATE(),
                                      'PMI/User';
									  
						SET @HDRTotalProdBox = @HDRTotalProdBox + @Outputbox;
						SET @HDRTotalProdStick = @HDRTotalProdStick + @OutputSticks;
						SET @HDRTotalProdJKN = @HDRTotalProdJKN + @JKNJam;
						SET @HDRTotalProdJl1 = @HDRTotalProdJl1 + @Jl1Jam;
						SET @HDRTotalProdJl2 = @HDRTotalProdJl2 + @Jl2Jam;
						SET @HDRTotalProdJl3 = @HDRTotalProdJl3 + @Jl3Jam;
						SET @HDRTotalProdJl4 = @HDRTotalProdJl4 + @Jl3Jam;
                        SET @StartDate = DATEADD(DAY, 1, @StartDate);
                    END;
            END;
		
		DECLARE @SisaDecimal FLOAT;
		SET @SisaDecimal = @HDRTotalProdJl4 - FLOOR(@HDRTotalProdJl4);
		IF @SisaDecimal > 0
		BEGIN
		   SET @HDRTotalProdJl4 = FLOOR(@HDRTotalProdJl4);
		   SET @HDRTotalProdJl3 = @HDRTotalProdJl3 + @SisaDecimal;
		END

		SET @SisaDecimal = @HDRTotalProdJl3 - FLOOR(@HDRTotalProdJl3);
		IF @SisaDecimal > 0
		BEGIN
		   SET @HDRTotalProdJl3 = FLOOR(@HDRTotalProdJl3);
		   SET @HDRTotalProdJl2 = @HDRTotalProdJl2 + @SisaDecimal;
		END

		SET @SisaDecimal = @HDRTotalProdJl2 - FLOOR(@HDRTotalProdJl2);
		IF @SisaDecimal > 0
		BEGIN
		   SET @HDRTotalProdJl2 = FLOOR(@HDRTotalProdJl2);
		   SET @HDRTotalProdJl1 = @HDRTotalProdJl1 + @SisaDecimal;
		END

		SET @SisaDecimal = @HDRTotalProdJl1 - FLOOR(@HDRTotalProdJl1);
		IF @SisaDecimal > 0
		BEGIN
		   SET @HDRTotalProdJl1 = FLOOR(@HDRTotalProdJl1);
		   SET @HDRTotalProdJKN = @HDRTotalProdJKN + @SisaDecimal;
		END

		SET @HDRTotalProdJKN = ROUND(@HDRTotalProdJKN, 0)

        -- Check TPO Fee Calculation
        DECLARE @TPOFeeCalculationExist INT;
        SELECT @TPOFeeCalculationExist = COUNT(*)
        FROM TPOFeeCalculationPlan
        WHERE TPOFeeCode = @TPOFeeCode;
		
		UPDATE TPOFeeHdrPlan
		  SET TotalProdBox = @HDRTotalProdBox,
				TotalProdStick = @HDRTotalProdStick,
				TotalProdJKN = @HDRTotalProdJKN,
				TotalProdJl1 = @HDRTotalProdJl1,
				TotalProdJl2 = @HDRTotalProdJl2,
				TotalProdJl3 = @HDRTotalProdJl3,
				TotalProdJl4 = @HDRTotalProdJl4
		WHERE TPOFeeCode = @TPOFeeCode
          AND LocationCode = @LocationCode
          AND BrandGroupCode = @BrandGroupCode
          AND KPSYear = @KPSYear
          AND KPSWeek = @KPSWeek
          AND BrandCode = @BrandCode;
		
        DECLARE @TPORateJKN FLOAT;
        DECLARE @TPORateJl1 FLOAT;
        DECLARE @TPORateJl2 FLOAT;
        DECLARE @TPORateJl3 FLOAT;
        DECLARE @TPORateJl4 FLOAT;
        DECLARE @ManagementFee FLOAT;
        DECLARE @ProductivityIncentives FLOAT;

	   SELECT @StartDate = StartDate,
                       @EndDate = EndDate
                FROM MstGenWeek
                WHERE Year = @KPSYear
                  AND Week = @KPSWeek;

        SELECT @TPORateJKN = JKN,
               @TPORateJl1 = Jl1,
               @TPORateJl2 = Jl2,
               @TPORateJl3 = Jl3,
               @TPORateJl4 = Jl4,
               @ManagementFee = ManagementFee,
               @ProductivityIncentives = ProductivityIncentives
        FROM MstTPOFeeRate
        WHERE LocationCode = @LocationCode
          AND BrandGroupCode = @BrandGroupCode
          AND EffectiveDate <= @StartDate
		AND ExpiredDate >= @EndDate;

		IF (@ProductivityIncentives IS NULL)
		BEGIN
			SET @ProductivityIncentives = 0;
		END;
		IF (@ManagementFee IS NULL)
		BEGIN
			SET @ManagementFee = 0;
		END;
		IF (@TPORateJKN IS NULL)
		BEGIN
			SET @TPORateJKN = 0;
		END;
		IF (@TPORateJl1 IS NULL)
		BEGIN
			SET @TPORateJl1 = 0;
		END;
		IF (@TPORateJl2 IS NULL)
		BEGIN
			SET @TPORateJl2 = 0;
		END;
		IF (@TPORateJl3 IS NULL)
		BEGIN
			SET @TPORateJl3 = 0;
		END;
		IF (@TPORateJl4 IS NULL)
		BEGIN
			SET @TPORateJl4 = 0;
		END;
        --DECLARE @OutputBiaya1 float = (@DailyTotalJKNJam * @TPORateJKN)
        --DECLARE @OutputBiaya2 float = (@DailyTotalJL1Jam * @TPORateJl1)
        --DECLARE @OutputBiaya3 float = (@DailyTotalJL2Jam * @TPORateJl2)
        --DECLARE @OutputBiaya4 float = (@DailyTotalJL3Jam * @TPORateJl3)
        --DECLARE @OutputBiaya5 float = (@DailyTotalJL4Jam * @TPORateJl4)

        DECLARE @OutputBiaya1 FLOAT = ( @TPORateJKN );
        DECLARE @OutputBiaya2 FLOAT = ( @TPORateJl1 );
        DECLARE @OutputBiaya3 FLOAT = ( @TPORateJl2 );
        DECLARE @OutputBiaya4 FLOAT = ( @TPORateJl3 );
        DECLARE @OutputBiaya5 FLOAT = ( @TPORateJl4 );
        IF @TPOFeeCalculationExist <= 0
            BEGIN
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'JKN', @KPSYear, @KPSWeek, 1, @HDRTotalProdJKN, @OutputBiaya1, @HDRTotalProdJKN * @OutputBiaya1 );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'JL1', @KPSYear, @KPSWeek, 2, @HDRTotalProdJl1, @OutputBiaya2, @HDRTotalProdJl1 * @OutputBiaya2 );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'JL2', @KPSYear, @KPSWeek, 3, @HDRTotalProdJl2, @OutputBiaya3, @HDRTotalProdJl2 * @OutputBiaya3 );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'JL3', @KPSYear, @KPSWeek, 4, @HDRTotalProdJl3, @OutputBiaya4, @HDRTotalProdJl3 * @OutputBiaya4 );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'JL4', @KPSYear, @KPSWeek, 5, @HDRTotalProdJl4, @OutputBiaya5, @HDRTotalProdJl4 * @OutputBiaya5 );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Biaya Produksi', @KPSYear, @KPSWeek, 6, @HDRTotalProdBox, NULL, @HDRTotalProdBox * @OutputBiaya1 );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Jasa Manajemen', @KPSYear, @KPSWeek, 7, @HDRTotalProdBox, @ManagementFee, @HDRTotalProdBox * @ManagementFee );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Total Biaya Produksi & Jasa Manajemen', @KPSYear, @KPSWeek, 8, NULL, NULL, (( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )));
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Pajak Jasa Manajemen Sebesar 2%', @KPSYear, @KPSWeek, 9, NULL, NULL, ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 ));
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Total Biaya Yang Harus Dibayarkan Ke MPS', @KPSYear, @KPSWeek, 10, NULL, NULL, ((( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )) - ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 )));
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Pembayaran', @KPSYear, @KPSWeek, 11, NULL, NULL, ((( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )) - ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 )));
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Sisa yang harus dibayar', @KPSYear, @KPSWeek, 12, NULL, NULL, 0 --???
                      );
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'PPN Biaya Produksi 10%', @KPSYear, @KPSWeek, 13, NULL, NULL, ((( @HDRTotalProdBox * @ManagementFee ) * 10 ) / 100 ));
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'PPN Jasa Manajemen 10%', @KPSYear, @KPSWeek, 14, NULL, NULL, ((( @HDRTotalProdBox * @OutputBiaya1 ) * 10 ) / 100 ));
                INSERT INTO TPOFeeCalculationPlan
                VALUES( @TPOFeeCode, 'Total Bayar', @KPSYear, @KPSWeek, 15, NULL, NULL, (((( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )) - ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 )) + ((( @HDRTotalProdBox * @ManagementFee ) * 10 ) / 100 ) + ((( @HDRTotalProdBox * @OutputBiaya1 ) * 10 ) / 100 )));
            END;
        ELSE
            BEGIN
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdJKN,
                      OutputBiaya = @OutputBiaya1,
                      Calculate = @HDRTotalProdJKN * @OutputBiaya1
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 1
                  AND ProductionFeeType = 'JKN';
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdJl1,
                      OutputBiaya = @OutputBiaya2,
                      Calculate = @HDRTotalProdJl1 * @OutputBiaya2
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 2
                  AND ProductionFeeType = 'JL1';
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdJl2,
                      OutputBiaya = @OutputBiaya3,
                      Calculate = @HDRTotalProdJl2 * @OutputBiaya3
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 3
                  AND ProductionFeeType = 'JL2';
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdJl3,
                      OutputBiaya = @OutputBiaya4,
                      Calculate = @HDRTotalProdJl3 * @OutputBiaya4
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 4
                  AND ProductionFeeType = 'JL3';
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdJl4,
                      OutputBiaya = @OutputBiaya5,
                      Calculate = @HDRTotalProdJl4 * @OutputBiaya5
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 5
                  AND ProductionFeeType = 'JL4';
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdBox,
                      Calculate = @HDRTotalProdBox * @OutputBiaya1
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 6
                  AND ProductionFeeType = 'Biaya Produksi';
                UPDATE TPOFeeCalculationPlan
                  SET OutputProduction = @HDRTotalProdBox,
                      OutputBiaya = @ManagementFee,
                      Calculate = @HDRTotalProdBox * @ManagementFee
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 7
                  AND ProductionFeeType = 'Jasa Manajemen';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = (( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives ))
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 8
                  AND ProductionFeeType = 'Total Biaya Produksi & Jasa Manajemen';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 )
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 9
                  AND ProductionFeeType = 'Pajak Jasa Manajemen Sebesar 2%';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = ((( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )) - ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 ))
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 10
                  AND ProductionFeeType = 'Total Biaya Yang Harus Dibayarkan Ke MPS';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = ((( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )) - ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 ))
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 11
                  AND ProductionFeeType = 'Pembayaran';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = 0 --???
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 12
                  AND ProductionFeeType = 'Sisa yang harus dibayar';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = ((( @HDRTotalProdBox * @ManagementFee ) * 10 ) / 100 )
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 13
                  AND ProductionFeeType = 'PPN Biaya Produksi 10%';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = ((( @HDRTotalProdBox * @OutputBiaya1 ) * 10 ) / 100 )
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 14
                  AND ProductionFeeType = 'PPN Jasa Manajemen 10%';
                UPDATE TPOFeeCalculationPlan
                  SET Calculate = (((( @HDRTotalProdBox * @OutputBiaya1 ) + ( @HDRTotalProdBox * @ManagementFee ) - ( @HDRTotalProdBox * @ProductivityIncentives )) - ((( @HDRTotalProdBox * @ManagementFee ) * 2 ) / 100 )) + ((( @HDRTotalProdBox * @ManagementFee ) * 10 ) / 100 ) + ((( @HDRTotalProdBox * @OutputBiaya1 ) * 10 ) / 100 ))
                WHERE TPOFeeCode = @TPOFeeCode
                  AND KPSYear = @KPSYear
                  AND KPSWeek = @KPSWeek
                  AND OrderFeeType = 15
                  AND ProductionFeeType = 'Total Bayar';
            END;
    END;


