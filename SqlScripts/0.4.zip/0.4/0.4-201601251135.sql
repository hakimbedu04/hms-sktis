/****** Object:  StoredProcedure [dbo].[GetReportSummaryDailyProductionTargets]    Script Date: 1/25/2016 10:13:43 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		azka
-- Updated date: 2016/01/18
-- Description:	alter procedure GetReportSummaryDailyProductionTargets
-- =============================================

-- =============================================
-- Author:		azka
-- Updated date: 2016/01/22
-- Description:	alter procedure GetReportSummaryDailyProductionTargets
-- =============================================

-- =============================================
-- Author:		azka
-- Updated date: 2016/01/25
-- Description:	alter procedure GetReportSummaryDailyProductionTargets
-- =============================================

ALTER PROCEDURE [dbo].[GetReportSummaryDailyProductionTargets] 
	@Year int,
	@Week int,
	@Decimal int,
	@LocationCode VARCHAR(20)
AS
BEGIN
    DECLARE @DateFrom DATETIME, @DateTo DATETIME
    DECLARE @Location VARCHAR(10)
	DECLARE @LocationChild VARCHAR(10)

	SELECT @DateFrom = dbo.MstGenWeek.StartDate, @DateTo = dbo.MstGenWeek.EndDate FROM dbo.MstGenWeek WHERE dbo.MstGenWeek.[Year] = @Year AND dbo.MstGenWeek.Week = @Week

		SELECT BrandCode, LocationCode,
			ROUND(TargetManual1, @Decimal) AS TargetManual1,
			ROUND(TargetManual2, @Decimal) AS TargetManual2,
			ROUND(TargetManual3, @Decimal) AS TargetManual3,
			ROUND(TargetManual4, @Decimal) AS TargetManual4,
			ROUND(TargetManual5, @Decimal) AS TargetManual5,
			ROUND(TargetManual6, @Decimal) AS TargetManual6,
			ROUND(TargetManual7, @Decimal) AS TargetManual7
		FROM PlanTPOTargetProductionKelompokBox AS box WHERE box.KPSYear = @Year AND box.KPSWeek = @Week 
			AND LocationCode IN 
			(
				SELECT locationcode FROM GetLastChildLocation(@LocationCode)
			)
		UNION
		SELECT BrandCode, LocationCode,
			ROUND(SUM(Coalesce(Targetmanual1, 0)), @Decimal) AS TargetManual1,
			ROUND(SUM(Coalesce(Targetmanual2, 0)), @Decimal) AS TargetManual2,
			ROUND(SUM(Coalesce(Targetmanual3, 0)), @Decimal) AS TargetManual3,
			ROUND(SUM(Coalesce(Targetmanual4, 0)), @Decimal) AS TargetManual4,
			ROUND(SUM(Coalesce(Targetmanual5, 0)), @Decimal) AS TargetManual5,
			ROUND(SUM(Coalesce(Targetmanual6, 0)), @Decimal) AS TargetManual6,
			ROUND(SUM(Coalesce(Targetmanual7, 0)), @Decimal) AS TargetManual7
		FROM dbo.PlanTargetProductionUnit ptpu WHERE ptpu.ProductionStartDate >= @DateFrom 
			AND ptpu.ProductionStartDate <= @DateTo 
			AND LocationCode IN 
			(
				SELECT locationcode FROM GetLastChildLocation(@LocationCode)
			)
		GROUP BY BrandCode, LocationCode	
END

