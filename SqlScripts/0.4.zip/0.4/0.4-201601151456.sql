-- =============================================
-- Description: Fix TPOProductionEntryVerificationGenerateReport
-- Ticket: http://tp.voxteneo.co.id/entity/1877
-- Author: Dwi Yudha
-- Version: 1.3
-- =============================================

-- Description: Generating Production Entry Verification Report
-- Ticket: http://tp.voxteneo.com/entity/57888
-- Author: Whisnu Sucitanuary
-- Version: 1.1
-- Changes: Fix calculation for OutputBiaya

-- Author: Harizal
-- Version: 1.2
-- Changes: Fix SP TPOProductionEntryVerificationGenerateReport

ALTER PROCEDURE [dbo].[TPOProductionEntryVerificationGenerateReport]
	@LocationCode varchar(8),
	@BrandCode varchar(11),
	@KPSYear int,
	@KPSWeek int,
	@ProductionDate date	
AS
BEGIN

SET NOCOUNT ON;
    -- GLOBAL VARIABLE
    DECLARE @TPOFeeCode VARCHAR(64), @StickPerBox INT;

    -- GLOBAL DATA
    -- Master General Brand Group	
    DECLARE @BrandGroupCode VARCHAR(20);

    SELECT @BrandGroupCode = bg.BrandGroupCode, @StickPerBox = bg.StickPerBox
    FROM MstGenBrandGroup bg
         INNER JOIN MstGenBrand b ON b.BrandGroupCode = bg.BrandGroupCode
    WHERE b.BrandCode = @BrandCode;

    SET @TPOFeeCode = 'FEE/' + @LocationCode + '/' + @BrandGroupCode + '/' + CAST(@KPSYear AS VARCHAR) + '/' + CAST(@KPSWeek AS VARCHAR);

    --START INSERT DATA TpoFeeHdr ################################################
    DECLARE @TPOFeeHdrExist INT;

    SELECT @TPOFeeHdrExist = COUNT(*) FROM TPOFeeHdr
    WHERE KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND BrandCode = @BrandCode AND LocationCode = @LocationCode;

	DECLARE @TPOPackageValue REAL;
	-- Set @TPOPackageValue with Package from MstTPOPackage
	-- IF datas > 1 => higest
	SELECT TOP 1 @TPOPackageValue = Package
	FROM MstTPOPackage
	WHERE dbo.MstTPOPackage.LocationCode = @LocationCode
	  AND dbo.MstTPOPackage.BrandGroupCode = @BrandGroupCode
	  AND @ProductionDate >= EffectiveDate
	  AND @ProductionDate <= ExpiredDate
	ORDER BY dbo.MstTPOPackage.Package DESC;
	
    IF @TPOFeeHdrExist <= 0
        BEGIN
            -- Master TPO Info
            DECLARE @PengirimanL1 VARCHAR(64), @PengirimanL2 VARCHAR(64), @PengirimanL3 VARCHAR(64), @PengirimanL4 VARCHAR(64);

            SELECT @PengirimanL1 = VendorName, @PengirimanL2 = BankAccountNumber, @PengirimanL3 = BankType, @PengirimanL4 = BankBranch
            FROM MstTPOInfo WHERE LocationCode = @LocationCode;	

            -- Master TPO Package
            DECLARE @StartDate       DATETIME,
                    @EndDate         DATETIME;

            -- Get StartData and EndDate from MstGenWeek based Year and Week
            SELECT @StartDate = mgw.StartDate, @EndDate = EndDate
            FROM dbo.MstGenWeek mgw
            WHERE mgw.[Year] = @KPSYear
              AND mgw.Week = @KPSWeek;

            

            INSERT INTO TPOFeeHdr
                   ( KPSYear,
                     KPSWeek,
                     BrandGroupCode,
                     BrandCode,
                     LocationCode,
                     CurrentApproval,
                     CreatedDate,
                     CreatedBy,
                     UpdatedDate,
                     UpdatedBy,
                     TPOFeeCode,
                     Status,
                     PengirimanL1,
                     PengirimanL2,
                     PengirimanL3,
                     PengirimanL4,
                     StickPerBox,
                     TPOPackageValue
                   )
            SELECT @KPSYear,
                   @KPSWeek,
                   @BrandGroupCode,
                   @BrandCode,
                   @LocationCode,
                   'PMI/User',
                   GETDATE(),
                   'PMI/User',
                   GETDATE(),
                   'PMI/User',
                   @TPOFeeCode,
                   'OPEN',
                   @PengirimanL1,
                   @PengirimanL2,
                   @PengirimanL3,
                   @PengirimanL4,
                   @StickPerBox,
                   @TPOPackageValue;
        END
    --END INSERT DATA TpoFeeHdr ################################################

    --START INSERT DATA TPOFeeProductionDaily ################################################
    DECLARE @TPOFeeProductionDailyExist INT;

    SELECT @TPOFeeProductionDailyExist = COUNT(*)
    FROM TPOFeeProductionDaily
    WHERE TPOFeeCode = @TPOFeeCode
      AND FeeDate = @ProductionDate
      AND KPSYear = @KPSYear
      AND KPSWeek = @KPSWeek;

    IF @TPOFeeProductionDailyExist <= 0
        BEGIN
            
		  DECLARE @Outputbox FLOAT;

		  -- TODO @Outputbox
            -- Get data dari TotalActualValue TPOProductionEntryVerifivation, yang Proces Ordernya paling besar
            -- Jika ada dua brandCode di TPOProductionEntryVerification, maka nilainya harus dijumlahkan
            SELECT TOP 1 @Outputbox = asd.TotalActualValue
            FROM( SELECT SUM(etev.TotalActualValue) TotalActualValue, etev.ProcessOrder
                  FROM dbo.ExeTPOProductionEntryVerification etev
                  WHERE etev.LocationCode = @LocationCode
                    AND etev.BrandCode IN ( SELECT dbo.MstGenBrand.BrandCode FROM dbo.MstGenBrand WHERE dbo.MstGenBrand.BrandGroupCode = @BrandGroupCode )
                    AND etev.KPSYear = @KPSYear
                    AND etev.KPSWeek = @KPSWeek
                    AND etev.ProductionDate = @ProductionDate
                  GROUP BY etev.ProcessOrder ) AS asd
            ORDER BY asd.ProcessOrder DESC;            

            DECLARE @OutputSticks REAL;
            -- TODO @OutputSticks
            -- @OutputSticks * @StickPerBox       
            SET @OutputSticks = @Outputbox * @StickPerBox;
            
		  DECLARE @JKNJam FLOAT;
            DECLARE @Jl1Jam FLOAT;
            DECLARE @Jl2Jam FLOAT;
            DECLARE @Jl3Jam FLOAT;
            DECLARE @Jl4Jam FLOAT;
            DECLARE @JKNJamStd FLOAT;
            DECLARE @Jl1JamStd FLOAT;
            DECLARE @Jl2JamStd FLOAT;
            DECLARE @Jl3JamStd FLOAT;
            DECLARE @Jl4JamStd FLOAT;

            --New JKN, JL1, JL2, JL3, JL4 Condition
            -- TODO JKN, JL1, JL2, JL3, JL4 => DONE
            -- Get data dari MstGenHoloday,
            -- Klo misalkan hari tersebut hari libur (diliat dari MstGenHoliday), ambil yang Holiday, sebaliknya Non-Holiday dari mstGenStandarHours
            -- Check data mstGenStandarHours 1-7 (1 Senin, 2 Selasa, ...)
			DECLARE @IsHoliday INT;
			
			SELECT @IsHoliday = COUNT(*) FROM dbo.MstGenHoliday mgh WHERE mgh.LocationCode = @LocationCode AND mgh.StatusActive = '1' AND mgh.HolidayDate = @ProductionDate
            IF @IsHoliday <= 0
                BEGIN
                    SELECT @JKNJamStd = mgsh.JknHour,
                           @Jl1Jam = mgsh.Jl1Hour,
                           @Jl2Jam = mgsh.Jl2Hour,
                           @Jl3Jam = mgsh.Jl3Hour,
                           @Jl4Jam = mgsh.Jl4Hour
                    FROM dbo.MstGenStandardHours mgsh
                    WHERE mgsh.Day = ( CASE DATEPART(DW, @ProductionDate) - 1 WHEN 0 THEN 7 ELSE DATEPART(DW, @ProductionDate) - 1 END )
                      AND mgsh.DayType = 'Non-Holiday';
                END;
            ELSE
                BEGIN
                    SELECT @JKNJamStd = mgsh.JknHour,
                           @Jl1Jam = mgsh.Jl1Hour,
                           @Jl2Jam = mgsh.Jl2Hour,
                           @Jl3Jam = mgsh.Jl3Hour,
                           @Jl4Jam = mgsh.Jl4Hour
                    FROM dbo.MstGenStandardHours mgsh
                    WHERE mgsh.Day = ( CASE DATEPART(DW, @ProductionDate) - 1 WHEN 0 THEN 7 ELSE DATEPART(DW, @ProductionDate) - 1 END )
                      AND mgsh.DayType = 'Holiday';
                END;
            --  --Total of All ProcessGroup JKNJam, JKNJam = TimeOut - TimeIn - BreakTime, 
            --  /*
            --  Total of All ProcessGroup JKNJam, 
            --  JKNJam = TimeOut - TimeIn - BreakTime, 
            --  if JKN is > JKN from MstGenStandardHours, then value JKN =  JKN MstGenStandardHours 
            --  */
            --  SELECT @JKNJam = DATEDIFF(HOUR, ( DATEADD(MINUTE, (( DATEPART(HOUR, eawh.TimeIn) * 60 ) + DATEPART(MINUTE, eawh.TimeIn) * 60 ) + DATEPART(SECOND, eawh.TimeIn), eawh.BreakTime)), eawh.TimeOut)
            --  FROM dbo.ExeActualWorkHours eawh
            --  WHERE eawh.LocationCode = @LocationCode AND eawh.BrandCode = @BrandCode AND eawh.UnitCode = 'PROD' AND eawh.ProductionDate = @ProductionDate AND eawh.ProcessGroup = 'ROLLING'
            --  IF @JKNJam > @JKNJamStd
            --  BEGIN
            --SET @JKNJam = @JKNJamStd
            --  END
            --  /*
            --  Total of All ProcessGroup Jl1Jam, 
            --  JL1Jam = JKNJam - JKN MstGenStandardHours, 
            --  if (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, then value JL1Jam =  JL1, variance value is for JL2Jam
            --  */
            --  SET @Jl1Jam = @JKNJam - @JKNJamStd
            --  IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
            --  BEGIN
            --  SET @Jl1Jam = @Jl1JamStd;
            --  END
            --  /*
            --  Total of All ProcessGroup Jl2Jam. 
            --  If (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, 
            --  then value JL2Jam = JKNJam - JKN MstGenStandardHours, 
            --  if (Jl2Jam - Jl2 MstGenStandardHours) is > JL2 from MstGenStandardHours, 
            --  then value JL2Jam = JL2, variance value is for JL3Jam
            --  */
            --  IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
            --  BEGIN
            --  SET @Jl2Jam = @JKNJam - @JKNJamStd
            --  END
            --  IF (@Jl2Jam - @Jl2JamStd) > @Jl2JamStd
            --  BEGIN
            --  SET @Jl2Jam = @Jl2JamStd
            --  END
            --  /*
            --  Total of All ProcessGroup Jl3Jam. 
            --  If (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, 
            --  then value JL3Jam = JKNJam - JKN MstGenStandardHours, 
            --  if (Jl3Jam - Jl3 MstGenStandardHours) is > JL3 from MstGenStandardHours, 
            --  then value JL3Jam = JL3, variance value is for JL4Jam
            --  */
            --  IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
            --  BEGIN
            --  SET @Jl3Jam = @JKNJam - @JKNJamStd
            --  END
            --  IF (@Jl3Jam - @Jl3JamStd) > @Jl3JamStd
            --  BEGIN
            --  SET @Jl2Jam = @Jl3JamStd
            --  END
            --  /*
            --  Total of All ProcessGroup Jl4Jam. 
            --  If (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, 
            --  then value JL4Jam = JKNJam - JKN MstGenStandardHours, 
            --  if (Jl4Jam - Jl4 MstGenStandardHours) is > JL4 from MstGenStandardHours, 
            --  then value JL4Jam = JL4
            --  */
            --  IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
            --  BEGIN
            --  SET @Jl4Jam = @JKNJam - @JKNJamStd
            --  END
            --  IF (@Jl4Jam - @Jl4JamStd) > @Jl4JamStd
            --  BEGIN
            --  SET @Jl4Jam = @Jl4JamStd
            --  END
            --  --End JLN, JL1, JL2, JL3, JL4 Condition

            DECLARE @JKN FLOAT,
                    @JL1 FLOAT,
                    @JL2 FLOAT,
                    @JL3 FLOAT,
                    @JL4 FLOAT,
				@MaxWorker        INT,
                    @StdStickPerHours INT,
                    @EmpPackage       INT;

		  -- SET @MaxWorker
            SELECT @MaxWorker = mgpsl.MaxWorker FROM dbo.MstGenProcessSettingsLocation mgpsl WHERE mgpsl.LocationCode = @LocationCode;

		  -- SET @StdStickPerHours
            SELECT TOP 1 @StdStickPerHours = StdStickPerHour FROM ProcessSettingsAndLocationView
            WHERE dbo.ProcessSettingsAndLocationView.LocationCode = @LocationCode
              AND dbo.ProcessSettingsAndLocationView.BrandGroupCode = @BrandGroupCode
              AND dbo.ProcessSettingsAndLocationView.ProcessGroup = 'ROLLING';

		  -- SET @EmpPackage
            SELECT @EmpPackage = dbo.MstGenBrandGroup.EmpPackage
            FROM MstGenBrandGroup
            WHERE dbo.MstGenBrandGroup.BrandGroupCode = @BrandGroupCode;

            --SELECT @StdStickPerHours = mgps.StdStickPerHour FROM dbo.MstGenProcessSettings mgps WHERE mgps.BrandGroupCode = @BrandGroupCode AND mgps.ProcessGroup='ROLLING'
            -- TODO JKN
            -- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
            -- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JKNJam * 
            -- (Get data EmpPackage from MstGenBrandGroup where Filter) * @StickPerBox
            SET @JKN = ROUND((( @TPOPackageValue * @StdStickPerHours * @JKNJamStd * @EmpPackage ) / @StickPerBox ), 2);

            -- TODO JL1
            -- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
            -- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL1Jam * 
            -- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
            SET @JL1 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl1Jam * @EmpPackage ) / @StickPerBox ), 2);

            -- TODO JL2
            -- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
            -- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL2Jam * 
            -- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
            SET @JL2 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl2Jam * @EmpPackage ) / @StickPerBox ), 2);

            -- TODO JL3
            -- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
            -- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL3Jam * 
            -- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
            SET @JL3 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl3Jam * @EmpPackage ) / @StickPerBox ), 2);

            -- TODO JL4
            -- package(1)*stdstick/hour(3)*WH(5)*jmlhorang (4)/stick/box ( 6 )
            -- @TPOPackageValue * (Get data StdStickPerHour dari view ProcessSettingsAndLocationView berdasarkan Filter dan ROLLING) * JL4Jam * 
            -- (Get data EmpPackage from MstGenBrandGroup where Filter) / @StickPerBox
            SET @JL4 = ROUND((( @TPOPackageValue * @StdStickPerHours * @Jl4Jam * @EmpPackage ) / @StickPerBox ), 2);

            -- Keterangan :
            -- @Outputbox atau OutputBox harus sama dengan @JKN + JL1 + JL2 + + JL3 + + JL4       
            -- Jika @Outputbox > @JKN
            --	 Maka : Nilai JKN = @JKN
            --		   Untuk Nilai JL1 = @Outputbox - @JKN
            --		   Dan jika Hasil @Outputbox - @JKN > @JL1
            --		   Maka Nilai JL1 = @JL1, dst...
            --SELECT @JKN, @JL1, @JL2, @JL3, @JL4

            DECLARE @Sisa FLOAT;
            SET @Sisa = ROUND((@Outputbox - @JKN),2);	  
				
			IF @IsHoliday <= 0 
				-- IF NOT HOLIDAY
				BEGIN
					IF( @Sisa < @JL1 )
						BEGIN
							SET @JL1 = @Sisa;
							SET @JL2 = 0;
							SET @JL3 = 0;
							SET @JL4 = 0;
						END;
					ELSE
						BEGIN
							SET @Sisa = ROUND((@Sisa - @JL1), 2);
							
							SET @JL2 = @Sisa;
							SET @JL3 = 0;
							SET @JL4 = 0;
						END;
				END;
			ELSE
				-- IF HOLIDAY
				BEGIN
					SET @JL1 = 0;
					SET @JL2 = @JKN;
					
					IF( @Sisa < @JL3 )
						BEGIN
							SET @JL3 = @Sisa;
							SET @JL4 = 0;
						END;
					ELSE
						BEGIN
							SET @Sisa = ROUND((@Sisa - @JL3), 2);
							
							SET @JL4 = @Sisa;
						END;
					
					SET @JKN = 0;
				END;

            INSERT INTO TPOFeeProductionDaily
            SELECT @TPOFeeCode,
                   @ProductionDate,
                   @KPSYear,
                   @KPSWeek,
                   @OutputSticks,
                   @Outputbox,
                   @JKN,
                   @JL1,
                   @JL2,
                   @JL3,
                   @JL4,
                   GETDATE(),
                   'PMI/User',
                   GETDATE(),
                   'PMI/User',
                   @JKNJamStd,
                   @Jl1Jam,
                   @Jl2Jam,
                   @Jl3Jam,
                   @Jl4Jam;
        END;
END;
    --END INSERT DATA TPOFeeProductionDaily ################################################



/*OLD CODE 20160105
SET NOCOUNT ON;
-- GLOBAL VARIABLE
DECLARE @TPOFeeCode VARCHAR(64);
DECLARE @StickPerBox INT;

-- GLOBAL DATA
-- Master General Brand Group	

DECLARE @BrandGroupCode VARCHAR(20);
SELECT @BrandGroupCode = bg.BrandGroupCode, @StickPerBox = bg.StickPerBox
FROM MstGenBrandGroup bg
     INNER JOIN MstGenBrand b ON b.BrandGroupCode = bg.BrandGroupCode
WHERE b.BrandCode = @BrandCode;

SET @TPOFeeCode = 'FEE/' + @LocationCode + '/' + @BrandGroupCode + '/' + CAST(@KPSYear AS VARCHAR) + '/' + CAST(@KPSWeek AS VARCHAR);

--START INSERT DATA TpoFeeHdr ################################################
DECLARE @TPOFeeHdrExist INT;
SELECT @TPOFeeHdrExist = COUNT(*) FROM TPOFeeHdr WHERE KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND BrandCode = @BrandCode AND LocationCode = @LocationCode;

IF @TPOFeeHdrExist <= 0
    BEGIN
    -- Master TPO Info
        DECLARE @PengirimanL1 VARCHAR(64);
        DECLARE @PengirimanL2 VARCHAR(64);
        DECLARE @PengirimanL3 VARCHAR(64);
        DECLARE @PengirimanL4 VARCHAR(64);

        SELECT @PengirimanL1 = VendorName, @PengirimanL2 = BankAccountNumber, @PengirimanL3 = BankType, @PengirimanL4 = BankBranch FROM MstTPOInfo
			WHERE LocationCode = @LocationCode;	

        -- Master TPO Package
        DECLARE @TPOPackageValue REAL,
			 @StartDate DATETIME,
                @EndDate   DATETIME;

        -- Get StartData and EndDate from MstGenWeek based Year and Week
        SELECT @StartDate = mgw.StartDate, @EndDate = EndDate FROM dbo.MstGenWeek mgw WHERE mgw.[Year] = @KPSYear AND mgw.Week = @KPSWeek;

        -- Set @TPOPackageValue with Package from MstTPOPackage
        -- IF datas > 1 => higest
        SELECT TOP 1 @TPOPackageValue = Package FROM MstTPOPackage WHERE dbo.MstTPOPackage.LocationCode = @LocationCode
				  AND dbo.MstTPOPackage.BrandGroupCode = @BrandGroupCode
				  AND @ProductionDate >= EffectiveDate
				  AND @ProductionDate <= ExpiredDate
        ORDER BY dbo.MstTPOPackage.Package DESC;

        --Insert TPO Fee Header
        INSERT INTO TPOFeeHdr
               ( KPSYear,
                 KPSWeek,
                 BrandGroupCode,
                 BrandCode,
                 LocationCode,
                 CurrentApproval,
                 CreatedDate,
                 CreatedBy,
                 UpdatedDate,
                 UpdatedBy,
                 TPOFeeCode,
                 Status,
                 PengirimanL1,
                 PengirimanL2,
                 PengirimanL3,
                 PengirimanL4,
                 StickPerBox,
                 TPOPackageValue
               )
               SELECT @KPSYear,
                      @KPSWeek,
                      @BrandGroupCode,
                      @BrandCode,
                      @LocationCode,
                      'PMI/User',
                      GETDATE(),
                      'PMI/User',
                      GETDATE(),
                      'PMI/User',
                      @TPOFeeCode,
                      'OPEN',
                      @PengirimanL1,
                      @PengirimanL2,
                      @PengirimanL3,
                      @PengirimanL4,
                      @StickPerBox,
                      @TPOPackageValue;
    END
--END INSERT DATA TpoFeeHdr ################################################

--START INSERT DATA TPOFeeProductionDaily ################################################
DECLARE @TPOFeeProductionDailyExist INT;
SELECT @TPOFeeProductionDailyExist = COUNT(*) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @TPOFeeCode AND FeeDate = @ProductionDate AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek;

IF @TPOFeeProductionDailyExist <= 0
    BEGIN		
       DECLARE @OutputSticks REAL;
       
        SELECT @OutputSticks = SUM(etev.TotalTPKValue) FROM dbo.ExeTPOProductionEntryVerification etev
        WHERE etev.BrandCode = @BrandCode AND etev.LocationCode = @LocationCode 
			 AND etev.KPSYear = @KPSYear AND etev.KPSWeek = @KPSWeek AND etev.ProductionDate = @ProductionDate;

        DECLARE @JKNJam FLOAT;
        DECLARE @Jl1Jam FLOAT;
        DECLARE @Jl2Jam FLOAT;
        DECLARE @Jl3Jam FLOAT;
        DECLARE @Jl4Jam FLOAT;
        DECLARE @JKNJamStd FLOAT;
        DECLARE @Jl1JamStd FLOAT;
        DECLARE @Jl2JamStd FLOAT;
        DECLARE @Jl3JamStd FLOAT;
        DECLARE @Jl4JamStd FLOAT;

	   --New JLN, JL1, JL2, JL3, JL4 Condition
	   SELECT 
		  @JKNJamStd = mgsh.JknHour,
		  @Jl1Jam = mgsh.Jl1Hour,
		  @Jl2Jam = mgsh.Jl1Hour,
		  @Jl3Jam = mgsh.Jl1Hour,
		  @Jl4Jam = mgsh.Jl4Hour FROM dbo.MstGenStandardHours mgsh
	   WHERE mgsh.Day = ( CASE DATEPART(DW, @ProductionDate) - 1 WHEN 0 THEN 7 ELSE DATEPART(DW, @ProductionDate) END )
		AND mgsh.DayType = 'Non-Holiday';


	   --Total of All ProcessGroup JKNJam, JKNJam = TimeOut - TimeIn - BreakTime, 
	   /*
		  Total of All ProcessGroup JKNJam, 
		  JKNJam = TimeOut - TimeIn - BreakTime, 
		  if JKN is > JKN from MstGenStandardHours, then value JKN =  JKN MstGenStandardHours 
	   */
	   SELECT @JKNJam = DATEDIFF(HOUR, ( DATEADD(MINUTE, (( DATEPART(HOUR, eawh.TimeIn) * 60 ) + DATEPART(MINUTE, eawh.TimeIn) * 60 ) + DATEPART(SECOND, eawh.TimeIn), eawh.BreakTime)), eawh.TimeOut)
	   FROM dbo.ExeActualWorkHours eawh
	   WHERE eawh.LocationCode = @LocationCode AND eawh.BrandCode = @BrandCode AND eawh.UnitCode = 'PROD' AND eawh.ProductionDate = @ProductionDate AND eawh.ProcessGroup = 'ROLLING'
	   
	   IF @JKNJam > @JKNJamStd
	   BEGIN
		SET @JKNJam = @JKNJamStd
	   END

	   /*
		  Total of All ProcessGroup Jl1Jam, 
		  JL1Jam = JKNJam - JKN MstGenStandardHours, 
		  if (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, then value JL1Jam =  JL1, variance value is for JL2Jam
	   */
	   SET @Jl1Jam = @JKNJam - @JKNJamStd
	   IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
	   BEGIN
		  SET @Jl1Jam = @Jl1JamStd;
	   END

	   /*
		  Total of All ProcessGroup Jl2Jam. 
		  If (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, 
		  then value JL2Jam = JKNJam - JKN MstGenStandardHours, 
		  if (Jl2Jam - Jl2 MstGenStandardHours) is > JL2 from MstGenStandardHours, 
		  then value JL2Jam = JL2, variance value is for JL3Jam
	   */
	   IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
	   BEGIN
		  SET @Jl2Jam = @JKNJam - @JKNJamStd
	   END
	   IF (@Jl2Jam - @Jl2JamStd) > @Jl2JamStd
	   BEGIN
		  SET @Jl2Jam = @Jl2JamStd
	   END

	   /*
		  Total of All ProcessGroup Jl3Jam. 
		  If (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, 
		  then value JL3Jam = JKNJam - JKN MstGenStandardHours, 
		  if (Jl3Jam - Jl3 MstGenStandardHours) is > JL3 from MstGenStandardHours, 
		  then value JL3Jam = JL3, variance value is for JL4Jam
	   */
	   IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
	   BEGIN
		  SET @Jl3Jam = @JKNJam - @JKNJamStd
	   END
	   IF (@Jl3Jam - @Jl3JamStd) > @Jl3JamStd
	   BEGIN
		  SET @Jl2Jam = @Jl3JamStd
	   END

	   /*
		  Total of All ProcessGroup Jl4Jam. 
		  If (JKNJam - JKN MstGenStandardHours) is > JL1 from MstGenStandardHours, 
		  then value JL4Jam = JKNJam - JKN MstGenStandardHours, 
		  if (Jl4Jam - Jl4 MstGenStandardHours) is > JL4 from MstGenStandardHours, 
		  then value JL4Jam = JL4
	   */
	   IF (@JKNJam - @JKNJamStd) > @Jl1JamStd
	   BEGIN
		  SET @Jl4Jam = @JKNJam - @JKNJamStd
	   END
	   IF (@Jl4Jam - @Jl4JamStd) > @Jl4JamStd
	   BEGIN
		  SET @Jl4Jam = @Jl4JamStd
	   END

	   --End JLN, JL1, JL2, JL3, JL4 Condition

        DECLARE @Outputbox FLOAT = @OutputSticks / @StickPerBox;
	   DECLARE @MaxWorker int,
			 @StdStickPerHours int

	   SELECT @MaxWorker = mgpsl.MaxWorker FROM dbo.MstGenProcessSettingsLocation mgpsl WHERE mgpsl.LocationCode = @LocationCode
	   SELECT @StdStickPerHours = mgps.StdStickPerHour FROM dbo.MstGenProcessSettings mgps WHERE mgps.BrandGroupCode = @BrandGroupCode AND mgps.ProcessGroup='ROLLING'

        INSERT INTO TPOFeeProductionDaily
               SELECT @TPOFeeCode,
                      @ProductionDate,
                      @KPSYear,
                      @KPSWeek,
                      @OutputSticks,
                      @Outputbox,
                      @Outputbox * @JKNJam * @TPOPackageValue * @MaxWorker * @StdStickPerHours,
                      @Outputbox * @Jl1Jam * @TPOPackageValue * @MaxWorker * @StdStickPerHours,
                      @Outputbox * @Jl2Jam * @TPOPackageValue * @MaxWorker * @StdStickPerHours,
                      @Outputbox * @Jl3Jam * @TPOPackageValue * @MaxWorker * @StdStickPerHours,
                      @Outputbox * @Jl4Jam * @TPOPackageValue * @MaxWorker * @StdStickPerHours,
                      GETDATE(),
                      'PMI/User',
                      GETDATE(),
                      'PMI/User',
                      @JKNJam,
                      @Jl1Jam,
                      @Jl2Jam,
                      @Jl3Jam,
                      @Jl4Jam;
    END
END
--END INSERT DATA TPOFeeProductionDaily ################################################
*/
