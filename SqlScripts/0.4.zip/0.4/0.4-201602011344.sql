-- =============================================
-- Author: Opun Buds
-- Updated date: 2016/02/01
-- Description:	Alter MstGenProcessSettingsLocation remove Max Worker Column
-- =============================================
ALTER TABLE dbo.MstGenProcessSettingsLocation
	DROP COLUMN MaxWorker
