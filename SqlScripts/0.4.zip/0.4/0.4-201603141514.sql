/*
	Created by: Indra Permana
	Description: Change Scale of decimal
	Refer to ticket: http://tp.voxteneo.co.id/entity/3705
*/

USE [SKT_DEV]
GO

ALTER TABLE [dbo].[ProductionCard] ALTER COLUMN [Production] [decimal](7,2);

ALTER TABLE [dbo].[ProductionCard] ALTER COLUMN [UpahLain] [decimal](7,2);