/*Created by: Indra Permana*/

ALTER TABLE [ExeReportByProcess] DROP CONSTRAINT [PK_ExeReportByProcess];

ALTER TABLE [ExeReportByProcess]
ADD CONSTRAINT [PK_ExeReportByProcess] PRIMARY KEY ([LocationCode] ASC,
	[UnitCode] ASC,
	[BrandCode] ASC,
	[ProductionDate] ASC,
	[ProcessOrder] ASC,
	[UOMOrder] ASC
	)
