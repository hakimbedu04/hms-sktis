--Robby Prima Suherlan http://tp.voxteneo.co.id/entity/1880
--Jejen Suhendar

ALTER VIEW [dbo].[ExePlantProductionEntryVerificationView]
AS
SELECT eppev.productionentrycode,
       eppev.locationcode,
       eppev.unitcode,
       eppev.shift,
       eppev.processgroup,
       eppev.processorder,
       eppev.groupcode,
       eppev.brandcode,
       eppev.kpsyear,
       eppev.kpsweek,
       eppev.productiondate,
       eppev.workhour,
       eppev.tpkvalue,
       eppev.totaltargetvalue,
       eppev.totalactualvalue,
       eppev.totalcapacityvalue,
       eppev.remark,
       eppev.createddate,
       eppev.createdby,
       eppev.updateddate,
       eppev.updatedby,
       eppev.flag_manual,
       table1.a,
       table1.i,
       table1.c,
       table1.ch,
       table1.ct,
       table1.sls_slp,
       table1.etc,
       table1.plant,
       table1.actual,
       CASE WHEN UTL.IDFlow IS NULL THEN 0 ELSE 1 END AS VerifySystem,
       eppev.verifymanual
FROM
  (SELECT Sum(CASE WHEN eppe.absentcodeeblek = 'A' THEN 1 ELSE 0 END) AS A,
          Sum(CASE WHEN eppe.absentcodeeblek = 'I' THEN 1 ELSE 0 END) AS I,
          Sum(CASE WHEN eppe.absentcodeeblek = 'C' THEN 1 ELSE 0 END) AS C,
          Sum(CASE WHEN eppe.absentcodeeblek = 'CH' THEN 1 ELSE 0 END) AS CH,
          Sum(CASE WHEN eppe.absentcodeeblek = 'CT' THEN 1 ELSE 0 END) AS CT,
          Sum(CASE WHEN eppe.absentcodeeblek IN ('SLS', 'SLP') THEN 1 ELSE 0 END) AS SLS_SLP,
          Sum(CASE WHEN eppe.absentcodeeblek NOT IN ('SLS', 'SLP', 'CT', 'CH', 'C', 'I', 'A') THEN 1 ELSE 0 END) AS ETC,
          productionentrycode,
          Sum(prodtarget) AS Plant,
          Sum(prodactual) AS Actual
   FROM
     (SELECT DISTINCT p.productionentrycode,
                      p.employeeid,
                      p.employeenumber,
                      p.statusemp,
                      p.statusidentifier,
                      p.startdateabsent,
                      p.absenttype,
                      p.prodcapacity,
                      p.prodtarget,
                      p.prodactual,
                      p.absentremark,
                      p.absentcodeeblek,
                      p.absentcodepayroll,
                      p.createddate,
                      p.createdby,
                      p.updateddate,
                      p.updatedby
      FROM dbo.exeplantproductionentry AS p
      INNER JOIN dbo.utiltransactionlogs AS trans ON p.productionentrycode = trans.transactioncode) AS eppe
   GROUP BY productionentrycode) AS table1
INNER JOIN dbo.exeplantproductionentryverification AS eppev ON table1.productionentrycode = eppev.productionentrycode
LEFT JOIN dbo.UtilTransactionLogs as UTL ON table1.ProductionEntryCode = UTL.TransactionCode AND UTL.IDFlow = 14

GO
