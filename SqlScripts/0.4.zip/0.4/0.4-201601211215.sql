--Robby Prima Suherlan http://tp.voxteneo.co.id/entity/1880
--Jejen Suhendar

ALTER VIEW [dbo].[ExePlantProductionEntryVerificationView]
AS
    SELECT eppev.ProductionEntryCode,
		 LocationCode,
		 UnitCode,
		 Shift,
		 ProcessGroup,
		 ProcessOrder,
		 GroupCode,
		 BrandCode,
		 KPSYear,
		 KPSWeek,
		 ProductionDate,
		 WorkHour,
		 TPKValue,
		 TotalTargetValue,
		 TotalActualValue,
		 TotalCapacityValue,
		 Remark,
		 eppev.CreatedDate,
		 eppev.CreatedBy,
		 eppev.UpdatedDate,
		 eppev.UpdatedBy,
		 Flag_Manual,
		 table1.A,
		 table1.I,
		 table1.C,
		 table1.CH,
		 table1.CT,
		 table1.SLS_SLP,
		 table1.ETC,
		 table1.Plant,
		 table1.Actual,
		 CASE WHEN UTL.IDFlow IS NULL THEN 0 ELSE 1 END AS VerifySystem,
		 eppev.VerifyManual 	  
		 FROM (
			 SELECT SUM(CASE WHEN eppe.AbsentCodeEblek = 'A' THEN 1 ELSE 0 END) AS A,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'I' THEN 1 ELSE 0 END) AS I,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'C' THEN 1 ELSE 0 END) AS C,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'CH' THEN 1 ELSE 0 END) AS CH,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'CT' THEN 1 ELSE 0 END) AS CT,
				   SUM(CASE WHEN eppe.AbsentCodeEblek IN ( 'SLS', 'SLP' ) THEN 1 ELSE 0 END) AS SLS_SLP,
				   SUM(CASE WHEN eppe.AbsentCodeEblek NOT IN ( 'SLS', 'SLP', 'CT', 'CH', 'C', 'I', 'A' ) THEN 1 ELSE 0 END) AS ETC ,
				   eppe.ProductionEntryCode,
				   SUM(eppe.ProdTarget) AS Plant,
				   SUM(eppe.ProdActual) AS Actual
			 FROM dbo.ExePlantProductionEntry eppe
				 WHERE eppe.AbsentCodeEblek IS NOT NULL
			 GROUP BY eppe.ProductionEntryCode 
    ) AS table1
	INNER JOIN dbo.ExePlantProductionEntryVerification eppev ON table1.ProductionEntryCode = eppev.ProductionEntryCode
	LEFT JOIN dbo.UtilTransactionLogs as UTL ON table1.ProductionEntryCode = UTL.TransactionCode AND UTL.IDFlow = 14

GO