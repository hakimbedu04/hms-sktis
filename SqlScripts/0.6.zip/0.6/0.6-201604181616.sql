-- =============================================
-- Author:		Abud
-- Create date: 2016-04-06
-- Description:	Function buat get wages absent report dialy
-- =============================================
ALTER FUNCTION [dbo].[GetWagesReportAbsentDialy]
(	
	@ProductionDate DATE = NULL,
	@LocationCode varchar(10) = NULL,
	@UnitCode varchar(10) =  NULL,
	@ProcessGroup varchar(50) = NULL
)
RETURNS TABLE 
AS
RETURN 
( 
	SELECT ROW_NUMBER() OVER (
                          ORDER BY LocationCode) AS id,
       LocationCode,
       ProdUnit,
       BrandGroupCode,
       ProcessGroup,
       ProdGroup,
       ProductionDate,
       Terdaftar,
       Alpa,
       Ijin,
       Sakit,
       Cuti,
       CutiHamil,
       CutiTahunan,
       Skorsing,
       ABS(TerdaftarAwal - TerdaftarAkhir) AS Keluar,
       Terdaftar - Alpa - Ijin - Cuti - CutiHamil - CutiTahunan - Skorsing AS Masuk,
       ABS(TerdaftarAwal - TerdaftarAkhir) AS Turnover,
       (CAST(Terdaftar AS FLOAT) - Alpa - Ijin - Cuti - CutiHamil - CutiTahunan - Skorsing) / CAST(Terdaftar AS FLOAT) * 100 AS Kehadiran,
       ((Alpa + Ijin + Cuti + CutiHamil + CutiTahunan + Skorsing) / CAST(Terdaftar AS FLOAT)) * 100 AS Absensi
FROM
  (SELECT MAX(pc.BrandGroupCode) AS BrandGroupCode,
          MAX(pc.LocationCode) AS LocationCode,
          MAX(pc.UnitCode) AS ProdUnit,
          MAX(pc.ProcessGroup) AS ProcessGroup,
          MAX(pc.GroupCode) AS ProdGroup,
          MAX(pc.ProductionDate) AS ProductionDate,
          COUNT(pc.EmployeeID) AS Terdaftar,
          SUM(CASE WHEN pc.EblekAbsentType = 'A' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS Alpa,
          SUM(CASE WHEN pc.EblekAbsentType = 'I' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS Ijin,
          SUM(CASE WHEN pc.EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS Sakit,
          SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS Cuti,
          SUM(CASE WHEN pc.EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS CutiHamil,
          SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS CutiTahunan,
          SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS Skorsing,
		  SUM(CASE WHEN pc.ProductionDate = ISNULL(@ProductionDate,pc.ProductionDate) THEN 1 ELSE 0 END) AS TerdaftarAwal,
		  SUM(CASE WHEN pc.ProductionDate = ISNULL(@ProductionDate,pc.ProductionDate) THEN 1 ELSE 0 END) AS TerdaftarAkhir
   FROM dbo.ProductionCard AS pc
   WHERE pc.ProductionDate = ISNULL(@ProductionDate,pc.ProductionDate)
     AND pc.LocationCode = ISNULL(@LocationCode, pc.LocationCode)
     AND pc.UnitCode = ISNULL(@UnitCode, pc.UnitCode)
     AND pc.ProcessGroup = ISNULL(@ProcessGroup, pc.ProcessGroup)
   GROUP BY pc.LocationCode,
            pc.UnitCode,
			pc.GroupCode,
			--pc.ProcessGroup,
			pc.BrandGroupCode,
			pc.ProductionDate) AS SOURCE
)


GO


