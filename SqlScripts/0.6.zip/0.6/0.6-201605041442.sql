-- =============================================
-- Author:		Abud
-- Create date: 2016-04-11
-- Description:	Function buat get wages absent report dialy lebih dari 1 hari
-- =============================================
ALTER FUNCTION [dbo].[GetWagesReportAbsentDialyMore]
(	
	@startDate DATE = NULL,
	@endDate DATE = NULL,
	@LocationCode varchar(10) = NULL,
	@UnitCode varchar(10) =  NULL,
	@ProcessGroup varchar(50) = NULL
)
RETURNS TABLE 
AS
RETURN 
( 
	SELECT ROW_NUMBER() OVER (
                          ORDER BY LocationCode) AS id,
       LocationCode,
       ProdUnit,
       BrandGroupCode,
       ProcessGroup,
       ProdGroup,
       ProductionDate,
       Terdaftar,
       Alpa,
       Ijin,
       Sakit,
       Cuti,
       CutiHamil,
       CutiTahunan,
       Skorsing,
       (CASE WHEN TerdaftarAkhir > 0 THEN ABS(TerdaftarAkhir - TerdaftarAwal) ELSE 0 END) AS Keluar,
       CEILING(Masuk) AS Masuk,
       ABS(TerdaftarAkhir - TerdaftarAwal) AS Turnover,
	   (CASE WHEN TerdaftarAkhir > 0 THEN ABS(TerdaftarAkhir  - TerdaftarAwal) / TerdaftarAkhir ELSE 0 END) AS TurnoverPersen,
       (CAST(Terdaftar AS FLOAT) - Alpa - Ijin - Sakit -  Cuti - CutiHamil - CutiTahunan - Skorsing) / CAST(Terdaftar AS FLOAT) * 100 AS Kehadiran,
       ((Alpa + Ijin + Sakit + Cuti + CutiHamil + CutiTahunan + Skorsing) / CAST(Terdaftar AS FLOAT)) * 100 AS Absensi
FROM
  (SELECT MAX(pc.BrandGroupCode) AS BrandGroupCode,
          MAX(pc.LocationCode) AS LocationCode,
          MAX(pc.UnitCode) AS ProdUnit,
          MAX(pc.ProcessGroup) AS ProcessGroup,
          MAX(pc.GroupCode) AS ProdGroup,
          MAX(pc.ProductionDate) AS ProductionDate,
          CEILING(
			CAST(COUNT(pc.EmployeeID) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT ) 
			) AS Terdaftar,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'A' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS Alpa,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'I' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS Ijin,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS Sakit,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS Cuti,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS CutiHamil,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS CutiTahunan,
          CEILING(
			CAST(SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS Skorsing,
		  CEILING(
			CAST(SUM(CASE WHEN pc.ProductionDate = ISNULL(@startDate,pc.ProductionDate) THEN 1 ELSE 0 END) AS FLOAT) / 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS TerdaftarAwal,
		  CEILING(
			(
				SELECT COUNT(*)
				FROM dbo.ProductionCard AS sub
				WHERE 
					sub.LocationCode = MAX(pc.LocationCode) 
					AND sub.UnitCode = MAX(pc.UnitCode)
					AND sub.BrandGroupCode = MAX(pc.BrandGroupCode)
					AND sub.GroupCode = MAX(pc.GroupCode)
					AND sub.ProcessGroup = MAX(pc.ProcessGroup)
					AND sub.ProductionDate = DATEADD(DAY,1,@endDate)
			) 
			/ 
			CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT)
			) AS TerdaftarAkhir,
			(
			CAST(COUNT(pc.EmployeeID) - 
			SUM(CASE WHEN pc.EblekAbsentType = 'A' AND pc.Remark IS NULL THEN 1 ELSE 0 END) -
			SUM(CASE WHEN pc.EblekAbsentType = 'I' AND pc.Remark IS NULL THEN 1 ELSE 0 END) -
			SUM(CASE WHEN pc.EblekAbsentType = 'S' AND pc.Remark IS NULL THEN 1 ELSE 0 END) -
			SUM(CASE WHEN pc.EblekAbsentType = 'C' AND pc.Remark IS NULL THEN 1 ELSE 0 END) -
			SUM(CASE WHEN pc.EblekAbsentType = 'CH' AND pc.Remark IS NULL THEN 1 ELSE 0 END) -
			SUM(CASE WHEN pc.EblekAbsentType = 'CT' AND pc.Remark IS NULL THEN 1 ELSE 0 END) -
			SUM(CASE WHEN pc.EblekAbsentType = 'SKR' AND pc.Remark IS NULL THEN 1 ELSE 0 END) 
			AS FLOAT) / CAST(dbo.GetDiffDayProdCard(@startDate,@endDate,pc.LocationCode,pc.BrandGroupCode,pc.UnitCode,pc.GroupCode,pc.ProcessGroup) AS FLOAT) 
			) AS Masuk
   FROM dbo.ProductionCard AS pc
   WHERE pc.ProductionDate >= ISNULL(@startDate,pc.ProductionDate)
     AND pc.ProductionDate <= ISNULL(@endDate,pc.ProductionDate)
     AND pc.LocationCode = ISNULL(@LocationCode, pc.LocationCode)
     AND pc.UnitCode = ISNULL(@UnitCode, pc.UnitCode)
     AND pc.ProcessGroup = ISNULL(@ProcessGroup, pc.ProcessGroup)
   GROUP BY pc.LocationCode,
            pc.UnitCode,
			pc.GroupCode,
			pc.ProcessGroup,
			pc.BrandGroupCode
			--pc.ProductionDate
			) AS SOURCE
)

GO


