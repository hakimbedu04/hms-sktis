-- =============================================
-- Author:		Opun Buds
-- Create date: 2016-04-22
-- Description:	Function buat 
-- =============================================
CREATE FUNCTION [dbo].[GetProcessFromProdCard] 
(	
	@StartDate DATE = NULL,
	@EndDate DATE = NULL,
	@LocationCode varchar(20)= NULL,
	@UnitCode varchar(20) = NULL
)
RETURNS @ProcessGroup TABLE (id int,ProcessGroup varchar(100))
AS
BEGIN
	INSERT INTO @ProcessGroup
	SELECT 
		MAX(mp.ProcessOrder) AS Id,
		pc.ProcessGroup
	FROM dbo.ProductionCard AS pc
	JOIN dbo.MstGenProcess AS mp ON mp.ProcessGroup = pc.ProcessGroup 
	WHERE
		pc.ProductionDate >= ISNULL(@StartDate,pc.ProductionDate)
		AND pc.ProductionDate <= ISNULL(@EndDate,pc.ProductionDate)
		AND pc.LocationCode = ISNULL(@LocationCode,pc.LocationCode)
		AND pc.UnitCode = ISNULL(@UnitCode,pc.UnitCode)
	GROUP BY pc.ProcessGroup
	ORDER BY MAX(mp.ProcessOrder) ASC
	RETURN
END
GO
