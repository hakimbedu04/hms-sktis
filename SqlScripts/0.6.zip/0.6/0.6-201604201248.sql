-- Description: Fix IDFlow mapping
-- Ticket: http://tp.voxteneo.co.id/entity/3462
-- Author: Dwi Yudha

UPDATE UtilFlows
SET ActionButton = 385
WHERE IDFlow = 44