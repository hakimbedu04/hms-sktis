USE [SKT_DEV]
GO

/****** Object:  View [dbo].[AdjustmentTypeByBrandCode]    Script Date: 02-May-16 4:14:10 PM ******/
--author = I Made Ardi Siskayana

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[AdjustmentTypeByBrandCode]
AS
SELECT DISTINCT b.BrandCode, gl.ListDetail, gl.ProcessID
FROM            dbo.ProcessSettingsAndLocationView AS a INNER JOIN
                         dbo.MstGenBrand AS b ON a.BrandGroupCode = b.BrandGroupCode INNER JOIN
                         dbo.MstGenLocStatus AS c ON c.LocationCode = a.LocationCode INNER JOIN
                             (SELECT        ListDetail, LEFT(ListDetail, 1) AS ProcessID
                               FROM            dbo.MstGenList
                               WHERE        (ListGroup = 'ProdAdjType')) AS gl ON gl.ProcessID = a.ProcessIdentifier OR gl.ProcessID = 0


GO


