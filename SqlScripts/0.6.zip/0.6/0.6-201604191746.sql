/****** Object:  UserDefinedFunction [dbo].[GetUserAndEmail]    Script Date: 4/18/2016 5:26:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Get User Email on Return Eblek Release Approval
-- Ticket: http://tp.voxteneo.co.id/entity/3783
-- Author: AZKA
-- Updated: 1.0 - 2016/04/19
-- =============================================

CREATE FUNCTION [dbo].[GetUserAndEmail]
(	
	@FunctionName as varchar(50),
	@ButtonName as varchar(50),
	@LocationCode as varchar(50),
	@UnitCode as varchar(50),
	@BrandCode as varchar(50),
	@Shift int,
	@KpsYear int,
	@KpsWeek int
)
RETURNS @UserAndEmail TABLE (UserAD VARCHAR(50), Email VARCHAR(50))
AS
BEGIN
	IF(@FunctionName LIKE 'EblekReleaseApproval')
	BEGIN
		INSERT INTO @UserAndEmail
			SELECT ad.UserAD, ad.Email 
			FROM UtilUsersResponsibility ur
			inner join MstADTemp ad on ad.UserAD = ur.UserAD
			where ur.IDResponsibility IN 
			(
				select IDResponsibility from UtilResponsibilityRules where IDResponsibility IN 
				(
					select IDResponsibility from UtilResponsibility where IDRole = 
					(
						select IDRole from UtilRoles where IDRole = (select DestinationRole from UtilFlows where ActionButton = 
							(select IDFunction from UtilFunctions where FunctionName = @ButtonName and ParentIDFunction = 
							(select IDFunction from UtilFunctions where FunctionName = @FunctionName)))
					)
				)and IDRule IN (select IDRule from UtilRules where Location = @LocationCode and Unit = @UnitCode)
			)
	END;
	RETURN;
END;