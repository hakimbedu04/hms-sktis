/****** Object:  View [dbo].[ExeReportProdStockProcessView]    Script Date: 4/28/2016 6:16:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Edit
-- Author: AZKA
-- Updated: 4/28/2016
-- =============================================

ALTER VIEW [dbo].[ExeReportProdStockProcessView]
AS
WITH BeginStock AS
(
SELECT BrandGroupCode, BrandCode, LocationCode, UnitCode, ProductionDate, KPSYear, KPSWeek, [11] AS BeginStockInternalMove, [13] AS BeginStockExternalMove, 
	Production, 
	TPKValue as Planning,
	Production - TPKValue as VarianceStick,
	COALESCE(((Production - TPKValue) / NULLIF(TPKValue, 0)) * 100, 0) as VariancePercent
	FROM 
	(
		SELECT 
			brand.BrandGroupCode,
			ep.BrandCode,
			ep.UnitCode,
			ep.LocationCode, 
			ep.UOMOrder,
			ep.ProductionDate,
			ep.KPSYear,
			ep.KPSWeek, 
			ep.BeginningStock,
			bg.Production,
			bg2.TPKValue
		FROM 
			ExeReportByProcess ep INNER JOIN
			MstGenBrand brand on brand.BrandCode = ep.BrandCode INNER JOIN
			(
				select LocationCode, BrandCode, ProductionDate, sum(Production) as Production
				from ExeReportByGroups where (ProcessGroup = 'STAMPING' or ProcessGroup = 'WRAPPING')
				group by
					LocationCode,
					BrandCode, 
					ProductionDate
			) bg on bg.LocationCode = ep.LocationCode and bg.BrandCode = ep.BrandCode and bg.ProductionDate = ep.ProductionDate INNER JOIN
			(
				select LocationCode, BrandCode, ProductionDate, sum(TPKValue) as TPKValue
				from ExeReportByGroups where (ProcessGroup = 'STAMPING' or ProcessGroup = 'WRAPPING')
				group by
					LocationCode,
					BrandCode, 
					ProductionDate
			) bg2 on bg2.LocationCode = ep.LocationCode and bg2.BrandCode = ep.BrandCode and bg2.ProductionDate = ep.ProductionDate
		WHERE 
			UOMOrder in (11,13) AND (ep.ProcessGroup = 'STAMPING' or ep.ProcessGroup = 'WRAPPING')
	) byProcess
	PIVOT
	(
		SUM(BeginningStock)
		FOR UOMOrder IN ([11], [13])
	) AS piv
),
Movement AS 
(
	SELECT [11] AS PAP, [13] AS PAG
	FROM 
	(
		SELECT  
			ep.UOMOrder,
			ep.KeluarBersih
		FROM 
			ExeReportByProcess ep INNER JOIN
			MstGenBrand brand on brand.BrandCode = ep.BrandCode INNER JOIN
			(
				select LocationCode, BrandCode, ProductionDate, sum(Production) as Production
				from ExeReportByGroups where (ProcessGroup = 'STAMPING' or ProcessGroup = 'WRAPPING')
				group by
					LocationCode,
					BrandCode, 
					ProductionDate
			) bg on bg.LocationCode = ep.LocationCode and bg.BrandCode = ep.BrandCode and bg.ProductionDate = ep.ProductionDate INNER JOIN
			(
				select LocationCode, BrandCode, ProductionDate, sum(TPKValue) as TPKValue
				from ExeReportByGroups where (ProcessGroup = 'STAMPING' or ProcessGroup = 'WRAPPING')
				group by
					LocationCode,
					BrandCode, 
					ProductionDate
			) bg2 on bg2.LocationCode = ep.LocationCode and bg2.BrandCode = ep.BrandCode and bg2.ProductionDate = ep.ProductionDate
		WHERE 
			UOMOrder in (11,13) AND (ep.ProcessGroup = 'STAMPING' or ep.ProcessGroup = 'WRAPPING')
	) byProcess
	PIVOT
	(
		SUM(KeluarBersih)
		FOR UOMOrder IN ([11], [13])
	) AS piv
),
EndingStock AS 
(
	SELECT [11] AS EndingStockInternalMove, [13] AS EndingStockExternalMove
	FROM 
	(
		SELECT  
			ep.UOMOrder,
			ep.EndingStock
		FROM 
			ExeReportByProcess ep INNER JOIN
			MstGenBrand brand on brand.BrandCode = ep.BrandCode INNER JOIN
			(
				select LocationCode, BrandCode, ProductionDate, sum(Production) as Production
				from ExeReportByGroups where (ProcessGroup = 'STAMPING' or ProcessGroup = 'WRAPPING')
				group by
					LocationCode,
					BrandCode, 
					ProductionDate
			) bg on bg.LocationCode = ep.LocationCode and bg.BrandCode = ep.BrandCode and bg.ProductionDate = ep.ProductionDate INNER JOIN
			(
				select LocationCode, BrandCode, ProductionDate, sum(TPKValue) as TPKValue
				from ExeReportByGroups where (ProcessGroup = 'STAMPING' or ProcessGroup = 'WRAPPING')
				group by
					LocationCode,
					BrandCode, 
					ProductionDate
			) bg2 on bg2.LocationCode = ep.LocationCode and bg2.BrandCode = ep.BrandCode and bg2.ProductionDate = ep.ProductionDate
		WHERE 
			UOMOrder in (11,13) AND (ep.ProcessGroup = 'STAMPING' or ep.ProcessGroup = 'WRAPPING')
	) byProcess
	PIVOT
	(
		SUM(EndingStock)
		FOR UOMOrder IN ([11], [13])
	) AS piv
)
SELECT *
FROM BeginStock B
CROSS JOIN Movement M
CROSS JOIN EndingStock E


GO


