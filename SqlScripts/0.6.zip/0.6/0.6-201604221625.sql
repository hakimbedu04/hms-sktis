ALTER FUNCTION [dbo].[GetKeluarBersihExeReportByProcess] (
	@ProcessGroup varchar(16),
	@LocationCode varchar(8),
	@UnitCode varchar(4),
	@BrandCode varchar(11),
	@KPSYear int,
	@KPSWeek int,
	@ProductionDate datetime,
	@ProcessOrder int
) RETURNS FLOAT
AS
	BEGIN
		DECLARE @KeluarBersih FLOAT

		IF (@ProcessGroup = 'CUTTING' OR @ProcessGroup = 'FOILROLL')
		BEGIN
			SELECT @KeluarBersih = Production FROM dbo.ExeReportByProcess 
				where 
						LocationCode = @LocationCode AND
						UnitCode = @UnitCode AND
						BrandCode = @BrandCode AND
						KPSYear = @KPSYear AND
						KPSWeek = @KPSWeek AND
						ProductionDate = @ProductionDate AND
						ProcessGroup = 'STICKWRAPPING'
		END
		IF (@ProcessGroup = 'ROLLING')
		BEGIN
			SELECT @KeluarBersih = Production FROM dbo.ExeReportByProcess 
				where 
						LocationCode = @LocationCode AND
						UnitCode = @UnitCode AND
						BrandCode = @BrandCode AND
						KPSYear = @KPSYear AND
						KPSWeek = @KPSWeek AND
						ProductionDate = @ProductionDate AND
						ProcessGroup = 'CUTTING'
		END
		ELSE
		BEGIN
			SELECT TOP 1 @KeluarBersih = Production FROM dbo.ExeReportByProcess 
				where 
						LocationCode = @LocationCode AND
						UnitCode = @UnitCode AND
						BrandCode = @BrandCode AND
						KPSYear = @KPSYear AND
						KPSWeek = @KPSWeek AND
						ProductionDate = @ProductionDate AND
						ProcessOrder > @ProcessOrder
		END

		RETURN @KeluarBersih;
	END;

GO


