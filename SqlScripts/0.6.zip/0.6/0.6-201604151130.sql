
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_TPO float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_ROLL float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_CUTT float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_PACK float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_STAMP float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_FWRP float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_SWRP float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_GEN float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Multi_WRP float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Out float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN Attend float
ALTER TABLE [SKT_DEV].[dbo].[ExeReportByGroupsWeekly]
 ALTER COLUMN ActualWorker float