-- Description: Modify TPOFeeExeGLAccruedListView
-- Ticket: http://tp.voxteneo.co.id/entity/1431
-- Author: Azka

ALTER VIEW [dbo].[TPOFeeExeGLAccruedListView]
AS
SELECT
    box.KPSYear,
    box.KPSWeek,
    brand.BrandGroupCode,
    box.BrandCode,
    box.LocationCode,
    loc.LocationName,
    loc.ParentLocationCode,
    box.TargetManual1,
    box.TargetManual2,
    box.TargetManual3,
    box.TargetManual4,
    box.TargetManual5,
    box.TargetManual6,
    box.TargetManual7,
    box.ProcessWorkHours1,
    box.ProcessWorkHours2,
    box.ProcessWorkHours3,
    box.ProcessWorkHours4,
    box.ProcessWorkHours5,
    box.ProcessWorkHours6,
    box.ProcessWorkHours7
FROM dbo.PlanTPOTargetProductionKelompokBox AS box
INNER JOIN dbo.MstGenLocation AS loc
    ON loc.LocationCode = box.LocationCode
INNER JOIN dbo.MstGenBrand AS brand
    ON brand.BrandCode = box.BrandCode
INNER JOIN dbo.TPOFeeHdrPlan TFHP
	ON TFHP.BrandGroupCode = brand.BrandGroupCode
	AND TFHP.LocationCode = box.LocationCode
	AND TFHP.KPSYear = box.KPSYear
	AND TFHP.KPSWeek = box.KPSWeek
GO


