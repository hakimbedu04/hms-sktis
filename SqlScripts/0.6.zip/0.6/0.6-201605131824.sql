-- =============================================
-- Description: [Report By Group] monthly workhour
-- Ticket: http://tp.voxteneo.co.id/entity/6470
-- Author: AZKA
-- Updated: 1.0 - 2016/05/13
-- =============================================

ALTER TABLE [dbo].[ExeReportByGroupsMonthly]
   ALTER COLUMN WorkHour REAL