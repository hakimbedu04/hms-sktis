
ALTER TABLE [SKT_DEV].[dbo].[ExePlantProductionEntry]
 ALTER COLUMN PRODTARGET real null
ALTER TABLE [SKT_DEV].[dbo].[ExePlantProductionEntry]
 ALTER COLUMN PRODACTUAL real null