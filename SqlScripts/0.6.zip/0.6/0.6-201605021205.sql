/****** Object:  View [dbo].[WagesProductionCardApprovalView]    Script Date: 5/2/2016 9:34:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Description: Get Production Card Approval List
-- Ticket: http://tp.voxteneo.com/entity/59031
-- Author: Whisnu Sucitanuary

-- Description: Change INNER JOIN to LEFT JOIN
-- Author: Harizal

-- Description: Add RevisionType and UpdatedDate
-- Ticket: http://tp.voxteneo.co.id/entity/3743
-- Author: Indra Permana

-- Description: Add CONVERT(VARCHAR(1), card.RevisionType))
-- Ticket: http://tp.voxteneo.co.id/entity/5238
-- Author: Azka
-- Date: 2016/04/22

-- Description: Add shift
-- Ticket: http://tp.voxteneo.co.id/entity/6353
-- Author: Azka
-- Date: 2016/05/02

ALTER VIEW [dbo].[WagesProductionCardApprovalView]
AS
SELECT ROW_NUMBER() OVER(ORDER BY card.ProductionCardCode DESC) AS Row,
	   MAX(card.RevisionType) RevisionType,
	   card.ProductionCardCode,
       card.LocationCode,
       card.UnitCode,
       card.BrandGroupCode AS BrandCode,
       card.ProductionDate,
       trans.IDFlow,
             CASE
                 WHEN [trans].IDFlow = 21
                 THEN 'DRAFT'
                 WHEN [trans].IDFlow = 22
                 THEN 'SUBMITTED'
                 WHEN [trans].IDFlow = 25
                 THEN 'APPROVED'
                 WHEN [trans].IDFlow = 26
                 THEN 'COMPLETED'
             END AS Status,
       AD.UserAD,
       role.RolesName,
	   MAX(card.UpdatedDate) UpdatedDate,
	   card.Shift
FROM dbo.ProductionCard AS card
     INNER JOIN dbo.UtilTransactionLogs AS trans ON trans.TransactionCode = (card.ProductionCardCode + '/' + CONVERT(VARCHAR(1), card.RevisionType))
     LEFT JOIN dbo.MstADTemp AS AD ON AD.UserAD = trans.CreatedBy
     LEFT JOIN dbo.UtilUsersResponsibility AS userresponse ON userresponse.UserAD = AD.UserAD
     LEFT JOIN dbo.UtilResponsibility AS response ON response.IDResponsibility = userresponse.IDResponsibility
     LEFT JOIN dbo.UtilRoles AS role ON role.IDRole = response.IDRole
WHERE( trans.IDFlow IN( 21, 22, 25, 26 ) )
GROUP BY card.ProductionCardCode, card.LocationCode, card.UnitCode, card.BrandGroupCode, card.ProductionDate, AD.UserAD, role.RolesName, trans.IDFlow,  card.Shift--, card.UpdatedDate

GO


