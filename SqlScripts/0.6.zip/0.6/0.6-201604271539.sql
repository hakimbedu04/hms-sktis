--author : tim HMS

CREATE Procedure [dbo].[AvailablePositionNumberView]
(
	@LocationCode varchar(10),
	@GroupCode varchar(5)	
)
as
Begin
  select nilai3.LocationCode,nilai3.EmployeeNumber,nilai3.GroupCode,(select StatusEmp  from dbo.MstGenEmpStatus  where StatusIdentifier =  SUBSTRING(GroupCode,2,1) ) as Status,nilai3.UnitCode,nilai3.ProcessSettingsCode   from(SELECT distinct  (SELECT  EmployeeNumber  
  FROM [dbo].[MstPlantEmpJobsDataAcv]  
  where LocationCode = @LocationCode and GroupCode = @GroupCode and EmployeeNumber =  A.EmployeeNumber  ) EmployeeNumber
  FROM [dbo].[MstPlantEmpJobsDataAll] As A
  where LocationCode = @LocationCode and GroupCode = @GroupCode)  nilai1   Right Join
  (select * from(SELECT distinct locationcode,(EmployeeNumber) EmployeeNumber,GroupCode, UnitCode,ProcessSettingsCode,Status 
  FROM [MstPlantEmpJobsDataAll]
  where LocationCode = @LocationCode and GroupCode = @GroupCode) as nilai2) nilai3 on nilai1.EmployeeNumber = nilai3.EmployeeNumber
  where nilai1.EmployeeNumber is null	
 End