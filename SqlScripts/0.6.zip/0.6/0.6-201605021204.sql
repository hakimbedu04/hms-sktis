-- Description: Create user AD view\
-- Author: Azka
-- Date: 2016/05/02

CREATE view UserADResponsibilityRolesView
as
select 
AD.UserAD, 
AD.Name, 
AD.Email, 
AD.StatusActive, 
response.IDResponsibility,
 response.ResponsibilityName,
 role.IDRole, 
 role.RolesCode, 
 role.RolesName 
from MstADTemp AD
  INNER JOIN dbo.UtilUsersResponsibility AS userresponse ON userresponse.UserAD = AD.UserAD
     INNER JOIN dbo.UtilResponsibility AS response ON response.IDResponsibility = userresponse.IDResponsibility
     INNER JOIN dbo.UtilRoles AS role ON role.IDRole = response.IDRole