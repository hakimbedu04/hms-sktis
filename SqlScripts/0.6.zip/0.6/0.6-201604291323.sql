USE [SKT_DEV]
GO
/****** Object:  StoredProcedure [dbo].[GetReportSummaryProcessTargets]    Script Date: 04/29/2016 10:08:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Harizal Hilmi
-- editor : indra permana
-- Create date:	Hari ini
-- Description:	http://tp.voxteneo.co.id/entity/1513
-- =============================================
-- =============================================
-- Author:		indra permana
-- Create date:	-
-- Description:	-
-- =============================================
-- =============================================
-- Author:		Tantan supriadi
-- Create date:	02-16-2016
-- Description:	http://tp.voxteneo.co.id/entity/2981
-- =============================================
-- =============================================
-- Author:		Abdurrahman Hakim
-- Create date:	04-27-2016
-- Description:	http://tp.voxteneo.co.id/entity/5284
-- =============================================
ALTER PROCEDURE [dbo].[GetReportSummaryProcessTargets]
	@Location varchar(50),
	@Year int,
	@Week int,
	@DateFrom datetime,
	@DateTo date,
	@Decimal int,
	@filterType varchar(10)
AS
BEGIN
	SET DATEFIRST 1
    DECLARE @StarDateWeek date, @EndDateWeek date
	DECLARE @kpsyear int 
	DECLARE @kpsweek int
	DECLARE @kpsweekArr varchar(MAX)
	DECLARE @listOfWeeks table (weeks int);
    -- Get StartDate and EndDate from MstGenWeek
    SELECT @StarDateWeek = mgw.StartDate, @EndDateWeek = mgw.EndDate FROM dbo.MstGenWeek mgw WHERE mgw.Week = @Week AND mgw.Year = @Year

	DECLARE @pptpkTable AS TABLE (LocationCode varchar(50), UnitCode varchar(50), BrandCode varchar(50), ProcessGroup varchar(50), KPSYear int, KPSWeek int, TargetManual real)
    DECLARE @pttpkTable AS TABLE (LocationCode varchar(50), UnitCode varchar(50), BrandCode varchar(50), ProcessGroup varchar(50), KPSYear int, KPSWeek int, TargetManual real)

    DECLARE @int int =  1
	DECLARE @query1 varchar(max)
	DECLARE @query2 varchar(max)
		
	IF @filterType = 'Week'	 
	BEGIN
	SET @DateFrom = @StarDateWeek
	SET @DateTo = @EndDateWeek
	END
	
	IF @filterType = 'Date'	 
	BEGIN
	SET @DateFrom = @DateFrom
	SET @DateTo = @DateTo
	END
    
    WHILE @DateFrom <= @DateTo
    BEGIN   
		 SET @query1 = 'SELECT pptpk.LocationCode, pptpk.BrandCode, pptpk.ProcessGroup, pptpk.KPSYear, pptpk.KPSWeek,';
		 SET @query2  = '';
		--SELECT  @int = DATEDIFF(DAY, @DateFrom, @DateTo)

		SET @kpsyear = (select top 1 g.Year FROM MstGenWeek g 
		    where g.StartDate <= @DateFrom AND g.EndDate >=@DateFrom)
		
			SET @kpsweek = (select top 1 g.Week FROM MstGenWeek g 
			   where g.StartDate <= @DateFrom AND g.EndDate >=@DateFrom and g.Year = @Year) 
		if (@kpsweek is not null)
		begin
			insert @listOfWeeks(weeks) values (@kpsweek);
			
			--select @kpsweek
			
			--IF @int >= 7
   			--BEGIN
     			--SET @int = @int%7
			--END
			SELECT  @int = datepart(dw, @DateFrom)
			SET @query2 = @query2 + ' ISNULL(pptpk.TargetManual' + CAST(@int AS varchar) +', 0) +'
			SET @int = @int + 1
			
		 
			INSERT INTO @pptpkTable ( LocationCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual, UnitCode )
			EXEC (@query1 + @query2 + '0 AS TargetManual, pptpk.UnitCode FROM PlanPlantTargetProductionKelompok pptpk WHERE pptpk.KPSYear = ' + @kpsyear + ' AND pptpk.KPSWeek = ' + @kpsweek)

			INSERT INTO @pttpkTable ( LocationCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual, UnitCode )
			EXEC (@query1 + @query2 + '0 AS TargetManual, ''PROD'' UnitCode FROM PlanTPOTargetProductionKelompok pptpk WHERE pptpk.KPSYear = ' + @kpsyear + ' AND pptpk.KPSWeek = ' + @kpsweek)
			
		end
		SET @DateFrom = DateAdd(day, 1, @DateFrom)
	END

    SET @int = 1;
    DECLARE @indexWIPDetail int = 1;
    WHILE @StarDateWeek <= @EndDateWeek
    BEGIN
	   IF @StarDateWeek = @DateTo
   	    BEGIN
     	    SET @indexWIPDetail = @int
	    END
	    SET @int = @int + 1
	    
	    
	    SET @StarDateWeek = DateAdd(day, 1, @StarDateWeek)
    END

    SET @query1 = 'SELECT ppw.LocationCode, ppw.UnitCode,ppw.BrandCode,''WIPGunting'' AS ProcessGroup, ppw.KPSYear, ppw.KPSWeek, ppw.WIPStock' + CAST(@indexWIPDetail AS varchar) + ' FROM dbo.PlanPlantWIPDetail ppw WHERE ppw.ProcessGroup =''CUTTING'' '
    SET @query2 = 'SELECT ppw.LocationCode, ppw.UnitCode,ppw.BrandCode,''WIPPak'' AS ProcessGroup, ppw.KPSYear, ppw.KPSWeek, ppw.WIPStock' + CAST(@indexWIPDetail AS varchar) + ' FROM dbo.PlanPlantWIPDetail ppw WHERE ppw.ProcessGroup =''PACKING'' '
    INSERT INTO @pttpkTable ( LocationCode, UnitCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual )
    EXEC (@query1)
    INSERT INTO @pttpkTable ( LocationCode, UnitCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual )
    EXEC (@query2)
    
 IF @filterType = 'Week'	 
	BEGIN   
		--SELECT * FROM @pptpkTable
		BEGIN
		SELECT Result.LocationCode,
			Result.UnitCode,
			Result.BrandCode,
			ROUND(ISNULL(Result.ROLLING, 0),@Decimal) Giling,
			ROUND(ISNULL(Result.CUTTING, 0),@Decimal) Gunting,
			ROUND(ISNULL(Result.PACKING, 0),@Decimal) Pak,
			ROUND(ISNULL(Result.WIPGunting, 0),@Decimal) WIPGunting,
			ROUND(ISNULL(Result.WIPPak, 0),@Decimal) WIPPak,
			ROUND(ISNULL(Result.Banderol, 0),@Decimal) AS Banderol,
			ROUND(ISNULL(ISNULL(Result.Banderol, 0) * (Select psv.UOMEblek From ProcessSettingsAndLocationView psv inner join MstGenBrand br on psv.BrandGroupCode = br.BrandGroupCode where psv.LocationCode = Result.LocationCode and br.BrandCode = Result.BrandCode and ProcessGroup = 'STAMPING') / mgbg.StickPerBox,0),@Decimal) AS Box
		FROM (
			SELECT [LocationCode], [UnitCode], [BrandCode], [ROLLING], [CUTTING], [PACKING], ISNULL([WRAPPING], 0) + [STAMPING] AS Banderol,0 as [WIPGunting],0 as [WIPPak]
			FROM (
				SELECT * FROM (
					SELECT pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup, SUM(pptpk.TargetManual) AS TargetManual1 FROM @pptpkTable pptpk  
					WHERE ( pptpk.LocationCode IN ( SELECT LocationCode FROM [dbo].[GetLocations](@Location, - 1) ) ) AND pptpk.KPSYear  = @Year AND pptpk.KPSWeek in (SELECT DISTINCT weeks from @listOfWeeks)
					GROUP BY pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup ) AS A
				) AS B
			PIVOT(SUM(TargetManual1) FOR [ProcessGroup] IN ( [ROLLING], [CUTTING], [PACKING], [WRAPPING], [STAMPING])) AS P
		
			UNION
		
			SELECT [LocationCode], [UnitCode], [BrandCode], [ROLLING], [CUTTING], [PACKING],ISNULL([WRAPPING], 0) + [STAMPING] AS Banderol,WIPGunting,WIPPak
			FROM (
				SELECT * FROM (
					SELECT pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup, SUM(pptpk.TargetManual) AS TargetManual1 FROM @pttpkTable pptpk
					WHERE ( pptpk.LocationCode IN ( SELECT LocationCode FROM [dbo].[GetLocations](@Location, - 1) ) ) AND pptpk.KPSYear = @Year AND pptpk.KPSWeek in (SELECT DISTINCT weeks from @listOfWeeks)
					GROUP BY pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup ) AS A
				) AS B
			PIVOT(SUM(TargetManual1) FOR [ProcessGroup] IN ( [ROLLING], [CUTTING], [PACKING],[WRAPPING], [STAMPING],WIPGunting,WIPPak )) AS P
			) AS Result
		LEFT JOIN dbo.MstGenBrand mgb	ON Result.BrandCode = mgb.BrandCode
		INNER JOIN dbo.MstGenBrandGroup mgbg ON mgbg.BrandGroupCode = mgb.BrandGroupCode
	END
	END
	IF @filterType = 'date'	 
	BEGIN   
		--SELECT * FROM @pptpkTable
		BEGIN
		SELECT Result.LocationCode,
			Result.UnitCode,
			Result.BrandCode,
			ROUND(ISNULL(Result.ROLLING, 0),@Decimal) Giling,
			ROUND(ISNULL(Result.CUTTING, 0),@Decimal) Gunting,
			ROUND(ISNULL(Result.PACKING, 0),@Decimal) Pak,
			ROUND(ISNULL(Result.WIPGunting, 0),@Decimal) WIPGunting,
			ROUND(ISNULL(Result.WIPPak, 0),@Decimal) WIPPak,
			ROUND(ISNULL(Result.Banderol, 0),@Decimal) AS Banderol,
			ROUND(ISNULL(ISNULL(Result.Banderol, 0) * (Select psv.UOMEblek From ProcessSettingsAndLocationView psv inner join MstGenBrand br on psv.BrandGroupCode = br.BrandGroupCode where psv.LocationCode = Result.LocationCode and br.BrandCode = Result.BrandCode and ProcessGroup = 'STAMPING') / mgbg.StickPerBox,0),@Decimal) AS Box
		FROM (
			SELECT [LocationCode], [UnitCode], [BrandCode], [ROLLING], [CUTTING], [PACKING], ISNULL([WRAPPING], 0) + [STAMPING] AS Banderol, 0 as [WIPGunting], 0 as [WIPPak]
			FROM (
				SELECT * FROM (
					SELECT pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup, SUM(pptpk.TargetManual) AS TargetManual1 FROM @pptpkTable pptpk  
					WHERE ( pptpk.LocationCode IN ( SELECT LocationCode FROM [dbo].[GetLocations](@Location, - 1) ) ) AND pptpk.KPSYear  = @Year AND pptpk.KPSWeek in (SELECT DISTINCT weeks from @listOfWeeks)
					GROUP BY pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup ) AS A
				) AS B
			PIVOT(SUM(TargetManual1) FOR [ProcessGroup] IN ( [ROLLING], [CUTTING], [PACKING], [WRAPPING], [STAMPING] )) AS P
		
			UNION
		
			SELECT [LocationCode], [UnitCode], [BrandCode], [ROLLING], [CUTTING], [PACKING],ISNULL([WRAPPING], 0) + [STAMPING] AS Banderol, WIPGunting,  WIPPak
			FROM (
				SELECT * FROM (
					SELECT pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup, SUM(pptpk.TargetManual) AS TargetManual1 FROM @pttpkTable pptpk
					WHERE ( pptpk.LocationCode IN ( SELECT LocationCode FROM [dbo].[GetLocations](@Location, - 1) ) ) AND pptpk.KPSYear = @Year AND pptpk.KPSWeek in (SELECT DISTINCT weeks from @listOfWeeks)
					GROUP BY pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup ) AS A
				) AS B
			PIVOT(SUM(TargetManual1) FOR [ProcessGroup] IN ( [ROLLING], [CUTTING], [PACKING],[WRAPPING], [STAMPING], [WIPGunting],  [WIPPak] )) AS P
			) AS Result
		LEFT JOIN dbo.MstGenBrand mgb	ON Result.BrandCode = mgb.BrandCode
		INNER JOIN dbo.MstGenBrandGroup mgbg ON mgbg.BrandGroupCode = mgb.BrandGroupCode
	END
	END
END   


