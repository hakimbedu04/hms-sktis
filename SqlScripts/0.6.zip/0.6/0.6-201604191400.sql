
ALTER TABLE [SKT_DEV].[dbo].[ExePlantProductionEntryVerification]
 ALTER COLUMN TOTALTARGETVALUE real null
ALTER TABLE [SKT_DEV].[dbo].[ExePlantProductionEntryVerification]
 ALTER COLUMN TOTALACTUALVALUE real null