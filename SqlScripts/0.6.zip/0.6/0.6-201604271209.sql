/****** Object:  UserDefinedFunction [dbo].[GetExeReportDailyProductionAchievement]    Script Date: 4/27/2016 12:09:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Get Data Daily Production Achievement
-- Ticket: http://tp.voxteneo.co.id/entity/3045
-- Author: AZKA
-- Updated: 1.0 - 4/27/2016
-- =============================================

CREATE FUNCTION [dbo].[GetExeReportDailyProductionAchievement]
(
	@LocationCode as varchar(10),
	@KpsWeek int,
	@KpsYear int
)
RETURNS TABLE 
AS
RETURN
(
	with ProductionDaily as
		(
			select 
				SKTBrandCode, 
				BrandCode, 
				ABBR, 
				Package,
				StdStickPerHour,
				WorkerCount,
				LocationCode,
				KPSWeek,
				KPSYear,
				COALESCE([Monday], 0) as Monday, 
				COALESCE([Tuesday], 0) as Tuesday, 
				COALESCE([Wednesday], 0) as Wednesday, 
				COALESCE([Thursday], 0) as Thursday, 
				COALESCE([Friday], 0) as Friday, 
				COALESCE([Saturday], 0) as Saturday, 
				COALESCE([Sunday], 0) as Sunday,
				(COALESCE([Monday], 0)+COALESCE([Tuesday], 0)+COALESCE([Wednesday], 0)+COALESCE([Thursday], 0)+COALESCE([Friday], 0)+COALESCE([Saturday], 0)+COALESCE([Sunday], 0)) as Total
			from 
			(
				select 
					bygrp.SKTBrandCode,
					bygrp.BrandCode,
					bygrp.ABBR,
					bygrp.NameOfDay,
					bygrp.Production,
					Package,
					StdStickPerHour,
					WorkerCount,
					LocationCode,
					KPSWeek,
					KPSYear
				from
				(
					select 
						bg.SKTBrandCode,
						grp.BrandCode,
						loc.ABBR,
						grp.LocationCode,
						grp.ProductionDate,
						Datename(weekday, grp.ProductionDate) as [NameOfDay],
						sum(procc.KeluarBersih) as Production,
						grp.TPKValue,
						Coalesce(tpopkt.Package, 0) as Package,
						procsetview.StdStickPerHour,
						Coalesce(prodgrp.WorkerCount, 0) AS WorkerCount,
						grp.KPSWeek,
						grp.KPSYear
					from ExeReportByGroups grp
					inner join MstGenBrandGroup bg on bg.BrandGroupCode = grp.BrandGroupCode
					inner join MstGenLocation loc on loc.LocationCode = grp.LocationCode
					left join MstTPOPackage tpopkt on tpopkt.LocationCode = grp.LocationCode and tpopkt.BrandGroupCode = grp.BrandGroupCode 
					left join ProcessSettingsAndLocationView procsetview on grp.LocationCode = procsetview.LocationCode and grp.BrandGroupCode = procsetview.BrandGroupCode and procsetview.ProcessGroup = 'ROLLING' 
					left join MstPlantProductionGroup prodgrp on prodgrp.LocationCode = grp.LocationCode and prodgrp.UnitCode = grp.UnitCode and prodgrp.GroupCode = grp.GroupCode and prodgrp.ProcessGroup = grp.ProcessGroup
					left join ExeReportByProcess procc on procc.LocationCode = grp.LocationCode and procc.UnitCode = grp.UnitCode and procc.BrandCode = grp.BrandCode and procc.ProductionDate = grp.ProductionDate and procc.ProcessGroup = grp.ProcessGroup and procc.UOMOrder = 7
					where grp.LocationCode IN (select LocationCode from GetLastChildLocation(@LocationCode)) and grp.KPSWeek = @KpsWeek and grp.KPSYear = @KpsYear and (grp.ProcessGroup = 'STAMPING' or grp.ProcessGroup = 'WRAPPING')
					group by
						bg.SKTBrandCode,
						grp.BrandCode,
						grp.LocationCode,
						grp.ProductionDate,
						procc.BrandCode,
						loc.ABBR,
						grp.TPKValue,
						Package,
						procsetview.StdStickPerHour,
						prodgrp.WorkerCount,
						grp.KPSWeek,
						grp.KPSYear
				) bygrp


			)acv
			PIVOT
			(
				SUM(Production)
				FOR NameOfDay IN ([Monday], [Tuesday], [Wednesday], [Thursday], [Friday], [Saturday], [Sunday])
			) piv
		),
		PlanningDaily as
		(
					select 
						SKTBrandCode,
						BrandCode,
						ABBR,
						LocationCode,
						sum(TPKValue) as TPKValue
					from
					(
					select 
						bg.SKTBrandCode,
						grp.BrandCode,
						loc.ABBR,
						grp.LocationCode,
						ProductionDate,
						Datename(weekday, grp.ProductionDate) as [NameOfDay],
						sum(grp.TPKValue) as TPKValue,
						Coalesce(tpopkt.Package, 0) as Package,
						procsetview.StdStickPerHour,
						Coalesce(prodgrp.WorkerCount, 0) AS WorkerCount,
						grp.KPSWeek,
						grp.KPSYear
					from ExeReportByGroups grp
					inner join MstGenBrandGroup bg on bg.BrandGroupCode = grp.BrandGroupCode
					inner join MstGenLocation loc on loc.LocationCode = grp.LocationCode
					left join MstTPOPackage tpopkt on tpopkt.LocationCode = grp.LocationCode and tpopkt.BrandGroupCode = grp.BrandGroupCode 
					left join ProcessSettingsAndLocationView procsetview on grp.LocationCode = procsetview.LocationCode and grp.BrandGroupCode = procsetview.BrandGroupCode and procsetview.ProcessGroup = 'ROLLING' 
					left join MstPlantProductionGroup prodgrp on prodgrp.LocationCode = grp.LocationCode and prodgrp.UnitCode = grp.UnitCode and prodgrp.GroupCode = grp.GroupCode and prodgrp.ProcessGroup = grp.ProcessGroup
					where grp.LocationCode IN (select LocationCode from GetLastChildLocation(@LocationCode)) and grp.KPSWeek = @KpsWeek and grp.KPSYear = @KpsYear and (grp.ProcessGroup = 'STAMPING' or grp.ProcessGroup = 'WRAPPING')
					group by
						bg.SKTBrandCode,
						grp.BrandCode,
						grp.LocationCode,
						ProductionDate,
						BrandCode,
						loc.ABBR,
						Package,
						procsetview.StdStickPerHour,
						prodgrp.WorkerCount,
						grp.KPSWeek,
						grp.KPSYear
					) a
					group by
					SKTBrandCode,
						BrandCode,
						ABBR,
						LocationCode
		)
		SELECT 
			B.LocationCode,
			B.SKTBrandCode,
			B.BrandCode,
			B.ABBR,
			B.Monday, B.Tuesday, B.Wednesday, B.Thursday, B.Friday, B.Saturday, B.Sunday,
			B.Monday + B.Tuesday + B.Wednesday + B.Thursday + B.Friday + B.Saturday + B.Sunday as Total,
			P.TPKValue as Planning,
			(B.Total - P.TPKValue) as VarianceStick,
			CAST(COALESCE(((B.Total - P.TPKValue) / NULLIF(P.TPKValue, 0)), 0)  * 100 AS Decimal(10,2)) as VariancePercent,
			CAST(COALESCE((B.Total / NULLIF(P.TPKValue, 0)), 0) * 100 AS Decimal(10,2)) as ReliabilityPercent,
			B.Package,
			CASE WHEN (select dbo.GetParentLocationLastChild(B.LocationCode)) = 'PLANT' THEN CAST(COALESCE(P.TPKValue / NULLIF((B.StdStickPerHour * B.WorkerCount), 0), 0) AS Decimal(10,2))
			ELSE CAST(COALESCE(P.TPKValue / NULLIF((B.Package * 360 * B.StdStickPerHour), 0), 0) AS Decimal(10,2)) END as TWHEqv
		FROM ProductionDaily B
		INNER JOIN PlanningDaily P on P.SKTBrandCode = B.SKTBrandCode and P.BrandCode = B.BrandCode and P.LocationCode = B.LocationCode and P.ABBR = B.ABBR
)
