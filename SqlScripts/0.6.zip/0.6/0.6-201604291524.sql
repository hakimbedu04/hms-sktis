/****** Object:  UserDefinedFunction [dbo].[CalculateWorkHoursTPO]    Script Date: 4/29/2016 2:51:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: calculate workhour
-- Ticket: http://tp.voxteneo.co.id/entity/3815
-- Author: Azka
-- Update: 30/03/2016
-- =============================================

-- =============================================
-- Description: condition all 00:00
-- Ticket: http://tp.voxteneo.co.id/entity/6344
-- Author: Azka
-- Update: 4/29/2016
-- =============================================

ALTER FUNCTION [dbo].[CalculateWorkHoursTPO]
(
	@LocationCode VARCHAR(8),
	@GroupCode VARCHAR(4),
	@BrandCode VARCHAR(11),
	@ProsesGroup VARCHAR(16),
	@ProductionDate DATE,
	@KPSYear INT,
	@KPSWeek INT,
	@StatusEmp VARCHAR(16),
	@DayOfWeek INT
)
RETURNS DECIMAL(10,2)
AS
BEGIN
     DECLARE	@result					DECIMAL(10,2) = 0.00;
	 DECLARE	@countActualWorkHour	INT;
	 DECLARE	@TimeOut		TIME;
	 DECLARE	@TimeIn			TIME;
	 DECLARE	@BreakTime		TIME;

	 SELECT @countActualWorkHour = COUNT(*) FROM ExeTPOActualWorkHours WHERE LocationCode = @LocationCode AND 
																			UnitCode = 'PROD' AND 
																			BrandCode = @BrandCode AND
																			ProcessGroup = @ProsesGroup AND
																			ProductionDate = @ProductionDate AND
																			StatusEmp = @StatusEmp

	
	IF @countActualWorkHour = 0
	BEGIN
		SELECT @result = CASE @DayOfWeek
							WHEN 1 THEN ProcessWorkHours1
							WHEN 2 THEN ProcessWorkHours2
							WHEN 3 THEN ProcessWorkHours3
							WHEN 4 THEN ProcessWorkHours4
							WHEN 5 THEN ProcessWorkHours5
							WHEN 6 THEN ProcessWorkHours6
							WHEN 7 THEN ProcessWorkHours7
							END
		FROM PlanTPOTargetProductionKelompok WHERE LocationCode = @LocationCode AND 
																			BrandCode = @BrandCode AND
																			ProcessGroup = @ProsesGroup AND
																			KPSWeek = @KPSWeek AND
																			KPSYear = @KPSYear AND
																			StatusEmp = @StatusEmp AND
																			ProdGroup = @GroupCode
	END;
	ELSE
	BEGIN
		 -- Formula : In - Out - Break
		 -- (Different time In and Out) - Break

		 SELECT @TimeIn = TimeIn, @TimeOut = TimeOut, @BreakTime = BreakTime From ExeTPOActualWorkHours WHERE LocationCode = @LocationCode AND 
																												UnitCode = 'PROD' AND 
																												BrandCode = @BrandCode AND
																												ProcessGroup = @ProsesGroup AND
																												ProductionDate = @ProductionDate AND
																												StatusEmp = @StatusEmp
		

		IF (@TimeIn = CONVERT(TIME, '00:00:00.0000000')) AND (@TimeOut = CONVERT(TIME, '00:00:00.0000000')) AND (@BreakTime = CONVERT(TIME, '00:00:00.0000000'))
			BEGIN
				SET @result = 0;
			END; 
		ELSE
			BEGIN
				IF @TimeOut =  CONVERT(TIME, '00:00:00.0000000')
					 BEGIN
						SET @result = (CAST(ABS(DATEDIFF(MINUTE, @TimeIn, '23:00:00.0000000')) / 60.0 AS DECIMAL(10,2)) + 1) - CAST(ABS(DATEDIFF(MINUTE, '00:00:00.0000000', @BreakTime)) / 60.0 AS DECIMAL(10,2));
					 END;
				 ELSE IF @TimeIn =  CONVERT(TIME, '00:00:00.0000000') AND @TimeOut =  CONVERT(TIME, '00:00:00.0000000')
					 BEGIN
						SET @result = 24.00;
					 END;
				 ELSE
					 BEGIN
						SET @result = CAST(ABS(DATEDIFF(MINUTE, @TimeOut, @TimeIn)) / 60.0 AS DECIMAL(10,2)) - CAST(ABS(DATEDIFF(MINUTE, '00:00:00.0000000', @BreakTime)) / 60.0 AS DECIMAL(10,2))
					 END;
			END;
	END;

	RETURN @result;
END;


