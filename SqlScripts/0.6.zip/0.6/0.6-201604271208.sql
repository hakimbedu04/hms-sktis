/****** Object:  UserDefinedFunction [dbo].[GetParentLocationLastChild]    Script Date: 4/27/2016 12:06:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Get Parent Location TPO or PLANT
-- Ticket: http://tp.voxteneo.co.id/entity/3045
-- Author: AZKA
-- Updated: 1.0 - 4/27/2016
-- =============================================

CREATE FUNCTION [dbo].[GetParentLocationLastChild]
(
	@LocationCode VARCHAR(8)
)
RETURNS VARCHAR(10)
AS
BEGIN
     DECLARE	@result	 VARCHAR(10)
	 DECLARE	@parent VARCHAR(10)
	
	SELECT @parent = ParentLocationCode FROM MstGenLocation where LocationCode = @LocationCode

	IF(@parent = 'PLNT')
	BEGIN
		SET @result = 'PLANT'
	END;
	ELSE IF(@parent like 'REG%')
	BEGIN
		SET @result = 'TPO'
	END;
	ELSE
	BEGIN
		SET @result = ''
	END;
	RETURN @result;
END;


