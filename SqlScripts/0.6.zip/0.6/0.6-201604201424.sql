
USE [SKT_DEV]
GO

/****** Object:  View [dbo].[EMSSourceDataBrandView]    Script Date: 04/20/2016 12:37:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE view [dbo].[EMSSourceDataBrandView]
As
SELECT  B.IDMstWeek,A.LocationCode,C.ParentLocationCode,BrandCode,StartDate,EndDate 
FROM [SKT_DEV].[dbo].[PlanWeeklyProductionPlanning] A inner join [SKT_DEV].[dbo].[MstGenWeek] B 
on A.KPSYear = B.Year and A.KPSWeek = B.Week inner join [SKT_DEV].[dbo].[MstGenLocation] As C on
A.LocationCode = C.LocationCode

GO




USE [SKT_DEV]
GO
/****** Object:  StoredProcedure [dbo].[GetEMSSourceData]    Script Date: 04/20/2016 12:37:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================

-- Create date: 18-01-2016
-- Description:	EMS Source Data
-- Edited by: TIM HM Sampoerna

-- =============================================
CREATE PROCEDURE [dbo].[GetEMSSourceData]
	-- Add the parameters for the stored procedure here
	(
	@LocationCode varchar(20),
	@BrandCode varchar(20),
	@start Date,
    @enddate Date
    )
AS
BEGIN
	IF @LocationCode = 'SKT' and @BrandCode = 'All'
	Begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate >= @start and ProductionDate <= @enddate
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate >= @start and ProductionDate <= @enddate
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode 
	End
	ELSE IF @LocationCode = 'SKT' and @BrandCode != 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode 
	end
	ELSE If @LocationCode = 'PLNT' and @BrandCode = 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate 
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode						
			 where PLNT.ParentLocationCode = @LocationCode
	end	
	ELSE If @LocationCode = 'PLNT' and @BrandCode != 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode						
			 where PLNT.ParentLocationCode = @LocationCode
	end	
		ELSE If @LocationCode = 'TPO' and @BrandCode = 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate 
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode						
			 where PLNT.ParentLocationCode like '%REG%'
	end	
	ELSE If @LocationCode = 'TPO' and @BrandCode != 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode						
			 where PLNT.ParentLocationCode like '%REG%'
	end	
	ELSE If @LocationCode = 'REG1' or @LocationCode = 'REG2' or @LocationCode = 'REG3' or @LocationCode = 'REG4' and @BrandCode = 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate 
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode						
			 where PLNT.ParentLocationCode =  @LocationCode
	end	
	ELSE If @LocationCode = 'REG1' or @LocationCode = 'REG2' or @LocationCode = 'REG3' or @LocationCode = 'REG4' and @BrandCode != 'All'
	begin
	Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode						
			 where PLNT.ParentLocationCode =  @LocationCode
	end	
	ELSE IF @LocationCode != 'SKT' and @BrandCode = 'All'
	 Begin
			  Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate and LocationCode = @LocationCode 
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate and LocationCode = @LocationCode 
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode 
	End
	Else IF @LocationCode != 'SKT' and @BrandCode != 'All'
	Begin
			  Select Company,EMS.LocationCode,EMS.BrandGroupCode,EMS.BrandCode,DIS.Description,PackageQTY,ProducedQTY,UOM,ProductionDate From   (
			  SELECT Cast('3066' as varchar(10)) As Company ,Package.LocationCode,Package.BrandGroupCode ,Produced.BrandCode,PackageQTY,ProducedQTY,('STICK') As UOM,Package.ProductionDate
			  FROM ( (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as ProducedQTY ,ProductionDate   
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'CUTTING' and ProductionDate between @start and @enddate and LocationCode = @LocationCode And BrandCode = @BrandCode 
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate ) AS Produced  inner join
			  (SELECT LocationCode,BrandCode,BrandGroupCode,SUM( Production ) as PackageQTY ,ProductionDate  
			  FROM [SKT_DEV].[dbo].[ExeReportByGroups] where ProcessGroup = 'STAMPING' and ProductionDate between @start and @enddate and LocationCode = @LocationCode And BrandCode = @BrandCode
			  group by LocationCode,BrandCode,BrandGroupCode,ProductionDate) AS Package on Produced.LocationCode = Package.LocationCode and Produced.BrandCode = Package.BrandCode and Produced.ProductionDate = Package.ProductionDate
			 ) ) AS EMS inner join [SKT_DEV].[dbo].[MstGenBrand] AS DIS on EMS.BrandCode = DIS.BrandCode AND EMS.BrandGroupCode = DIS.BrandGroupCode inner join [SKT_DEV].[dbo].[MstGenLocation] PLNT on EMS.LocationCode = PLNT.LocationCode 
	End
  End