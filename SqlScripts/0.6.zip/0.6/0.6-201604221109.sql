-- =============================================

-- Create date: 20-04-2016
-- Description:	EMS Source Data
-- Edited by: TIM HM Sampoerna

-- =============================================	
Create Procedure [dbo].[EMSSourceDataBrandCodeView]	
(
	@LocationCode varchar(20),	
	@start Date,
    @enddate Date
    )
AS
Begin
  IF @LocationCode = 'SKT'
  Begin
  SELECT Distinct BrandCode
  FROM [SKT_DEV].[dbo].[EMSSourceDataBrandView]
  where IDMstWeek between  (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @start >= StartDate  and @start <= EndDate)  and (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @enddate >= StartDate  and @enddate <= EndDate) 
  order by BrandCode
  End
  Else IF @LocationCode = 'PLNT'
  Begin
  SELECT Distinct BrandCode
  FROM [SKT_DEV].[dbo].[EMSSourceDataBrandView]
  where IDMstWeek between  (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @start >= StartDate  and @start <= EndDate)  and (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @enddate >= StartDate  and @enddate <= EndDate) and ParentLocationCode = @LocationCode
  order by BrandCode
  End
  Else IF @LocationCode = 'TPO'
  Begin
  SELECT Distinct BrandCode 
  FROM [SKT_DEV].[dbo].[EMSSourceDataBrandView]
  where IDMstWeek between  (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @start >= StartDate  and @start <= EndDate)  and (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @enddate >= StartDate  and @enddate <= EndDate) and ParentLocationCode like '%REG%'
  order by BrandCode
  End
  Else IF @LocationCode = 'REG1' OR @LocationCode = 'REG2' OR @LocationCode = 'REG3' OR @LocationCode = 'REG4'
  Begin
  SELECT Distinct BrandCode 
  FROM [SKT_DEV].[dbo].[EMSSourceDataBrandView]
  where IDMstWeek between  (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @start >= StartDate  and @start <= EndDate)  and (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @enddate >= StartDate  and @enddate <= EndDate) and ParentLocationCode = @LocationCode
  order by BrandCode
  End
  Else 
  Begin
  SELECT Distinct BrandCode 
  FROM [SKT_DEV].[dbo].[EMSSourceDataBrandView]
  where IDMstWeek between  (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @start >= StartDate  and @start <= EndDate)  and (select IDMstWeek
  FROM [SKT_DEV].[dbo].[Mstgenweek] 
  where @enddate >= StartDate  and @enddate <= EndDate) and LocationCode = @LocationCode
  order by BrandCode 
  End
  
 End
 
 
 
  
