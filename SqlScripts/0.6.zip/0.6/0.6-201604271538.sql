--author : tim HMS
create view [dbo].[AvailabelPositionNumberGroup]
As
select *,(select StatusEmp  from dbo.MstGenEmpStatus  where StatusIdentifier =  SUBSTRING(GroupCode,2,1) ) as StatusEmp 
FROM [dbo].[MstPlantEmpJobsDataAcv]