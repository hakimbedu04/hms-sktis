-- =============================================
-- Author:		Abud
-- Create date: 2016-04-27
-- Description:	http://tp.voxteneo.co.id/entity/3747
-- =============================================
CREATE FUNCTION dbo.GetPlanPlantIndividualCapacityByReference
(	
	@LocationCode varchar(20),
	@UnitCode varchar(20),
	@BrandGroupCode varchar(30),
	@ProcessGroup varchar(30),
	@GroupCode varchar(20),
	@Workhour int,
	@StartDate DATE,
	@EndDate DATE
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT pev.ProductionDate,
       pev.GroupCode,
       pev.UnitCode,
       pev.LocationCode,
       pev.ProcessGroup,
       pev.BrandCode,
       brand.BrandGroupCode,
       pev.WorkHour,
       ISNULL(MIN(ProdActual) OVER (PARTITION BY emp.EmployeeID), 0) AS MinimumValue,
       ISNULL(MAX(ProdActual) OVER (PARTITION BY emp.EmployeeID), 0) AS MaximumValue,
       ISNULL(AVG(ProdActual) OVER (PARTITION BY emp.EmployeeID), 0) AS AverageValue,
       ISNULL(((
                  (SELECT MAX(ProdActual)
                   FROM
                     (SELECT TOP 50 PERCENT ProdActual
                      FROM dbo.ExePlantProductionEntryVerification
                      ORDER BY ProdActual) AS BottomHalf) +
                  (SELECT MIN(ProdActual)
                   FROM
                     (SELECT TOP 50 PERCENT ProdActual
                      FROM dbo.ExePlantProductionEntryVerification
                      ORDER BY ProdActual DESC) AS TopHalf)) / 2),0) AS MedianValue,
       ISNULL(ProdActual, 0) AS LatestValue,
       emp.EmployeeID AS EmployeeID,
       emp.EmployeeNumber AS EmployeeNumber,
       cwh.HoursCapacity3,
       cwh.HoursCapacity5,
       cwh.HoursCapacity6,
       cwh.HoursCapacity7,
       cwh.HoursCapacity8,
       cwh.HoursCapacity9,
       cwh.HoursCapacity10
	FROM dbo.ExePlantProductionEntryVerification AS pev
	INNER JOIN dbo.ExePlantProductionEntry AS pe ON pev.ProductionEntryCode = pe.ProductionEntryCode
	AND pe.AbsentType IS NULL
	AND (pe.ProdActual > 0
		 AND pe.ProdActual IS NOT NULL)
	INNER JOIN dbo.MstPlantEmpJobsDataAcv AS emp ON emp.EmployeeID = pe.EmployeeID
	INNER JOIN dbo.PlanPlantIndividualCapacityWorkHours AS cwh ON cwh.EmployeeID = pe.EmployeeID
	AND cwh.GroupCode = pev.GroupCode
	AND cwh.UnitCode = pev.UnitCode
	AND cwh.LocationCode = pev.LocationCode
	AND cwh.ProcessGroup = pev.ProcessGroup
	INNER JOIN dbo.MstGenBrand AS brand ON brand.BrandCode = pev.BrandCode

	WHERE
		pev.LocationCode = @LocationCode 
		AND pev.UnitCode = @UnitCode 
		AND brand.BrandGroupCode = @BrandGroupCode
		AND pev.ProcessGroup = @ProcessGroup
		AND pev.GroupCode = @GroupCode
		AND pev.WorkHour = @Workhour 
		AND pev.ProductionDate >= @StartDate
		AND pev.ProductionDate <= @EndDate
)
GO
