GO
ALTER TABLE dbo.MstPlantEmpJobsDataAcv SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.MstGenBrand SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.ExePlantWorkerAssignment
	DROP CONSTRAINT FK_EXEPLANTWORKERASSIGNMENT_REFERENCE_128_MSTPLANTPRODUCTIONGROUP
GO
ALTER TABLE dbo.ExePlantWorkerAssignment
	DROP CONSTRAINT FK_EXEPLANTWORKERASSIGNMENT_RELATIONSHIP_45_MSTPLANTPRODUCTIONGROUP
GO
ALTER TABLE dbo.MstPlantProductionGroup SET (LOCK_ESCALATION = TABLE)
GO
GO
CREATE TABLE dbo.Tmp_ExePlantWorkerAssignment
	(
	TransactionDate datetime NOT NULL,
	SourceLocationCode varchar(8) NOT NULL,
	SourceUnitCode varchar(4) NOT NULL,
	SourceShift int NULL,
	SourceProcessGroup varchar(16) NOT NULL,
	SourceGroupCode varchar(4) NOT NULL,
	SourceBrandCode varchar(11) NOT NULL,
	DestinationLocationCode varchar(8) NOT NULL,
	DestinationUnitCode varchar(4) NOT NULL,
	DestinationShift int NULL,
	DestinationProcessGroup varchar(16) NOT NULL,
	DestinationGroupCode varchar(4) NOT NULL,
	DestinationGroupCodeDummy varchar(6) NOT NULL,
	DestinationBrandCode varchar(11) NOT NULL,
	EmployeeID varchar(64) NOT NULL,
	EmployeeNumber varchar(6) NOT NULL,
	StartDate datetime NOT NULL,
	EndDate datetime NOT NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExePlantWorkerAssignment SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExePlantWorkerAssignment)
	 EXEC('INSERT INTO dbo.Tmp_ExePlantWorkerAssignment (SourceLocationCode, SourceUnitCode, SourceProcessGroup, SourceGroupCode, DestinationLocationCode, DestinationUnitCode, DestinationProcessGroup, DestinationGroupCode, DestinationGroupCodeDummy, EmployeeID, EmployeeNumber, StartDate, EndDate, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT SourceLocationCode, SourceUnitCode, SourceProcessGroup, SourceGroupCode, DestinationLocationCode, DestinationUnitCode, DestinationProcessGroup, DestinationGroupCode, DestinationGroupCodeDummy, EmployeeID, EmployeeNumber, StartDate, EndDate, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ExePlantWorkerAssignment WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ExePlantWorkerAssignment
GO
EXECUTE sp_rename N'dbo.Tmp_ExePlantWorkerAssignment', N'ExePlantWorkerAssignment', 'OBJECT' 
GO
ALTER TABLE dbo.ExePlantWorkerAssignment ADD CONSTRAINT
	PK_ExePlantWorkerAssignment_1 PRIMARY KEY CLUSTERED 
	(
	EmployeeID,
	StartDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExePlantWorkerAssignment ADD CONSTRAINT
	FK_EXEPLANTWORKERASSIGNMENT_REFERENCE_128_MSTPLANTPRODUCTIONGROUP FOREIGN KEY
	(
	DestinationGroupCode,
	DestinationUnitCode,
	DestinationLocationCode,
	DestinationProcessGroup
	) REFERENCES dbo.MstPlantProductionGroup
	(
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantWorkerAssignment ADD CONSTRAINT
	FK_EXEPLANTWORKERASSIGNMENT_RELATIONSHIP_45_MSTPLANTPRODUCTIONGROUP FOREIGN KEY
	(
	SourceGroupCode,
	SourceUnitCode,
	SourceLocationCode,
	SourceProcessGroup
	) REFERENCES dbo.MstPlantProductionGroup
	(
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantWorkerAssignment ADD CONSTRAINT
	FK_ExePlantWorkerAssignment_MstGenBrand FOREIGN KEY
	(
	SourceBrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantWorkerAssignment ADD CONSTRAINT
	FK_ExePlantWorkerAssignment_MstPlantEmpJobsDataAcv FOREIGN KEY
	(
	EmployeeID
	) REFERENCES dbo.MstPlantEmpJobsDataAcv
	(
	EmployeeID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantWorkerAssignment ADD CONSTRAINT
	FK_ExePlantWorkerAssignment_MstGenBrand1 FOREIGN KEY
	(
	DestinationBrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO