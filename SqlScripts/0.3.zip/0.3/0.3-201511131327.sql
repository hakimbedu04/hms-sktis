-- Delete the unique constraint.
ALTER TABLE dbo.ExePlantWorkerAbsenteeism 
DROP CONSTRAINT UQ_TransactionDate_ExePlantWorkerAbsenteeism;
