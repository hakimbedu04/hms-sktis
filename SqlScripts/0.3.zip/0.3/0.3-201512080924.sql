-- Description: Get Production Card Approval List Detail (PIVOT)
-- Ticket: http://tp.voxteneo.com/entity/59045
-- Author: Whisnu Sucitanuary
-- Changes: Add Production Card Field 
ALTER VIEW [dbo].[WagesProductionCardApprovalDetailView]
AS
SELECT        ProductionCardCode, LocationCode, UnitCode, ProductionDate, BrandCode, ProcessGroup, GroupCode, COUNT(*) AS Worker, SUM(Production) AS Production, SUM(UpahLain) AS UpahLain, 
                         SUM(CASE EblekAbsentType WHEN 'A' THEN 1 ELSE 0 END) AS A, SUM(CASE EblekAbsentType WHEN 'C' THEN 1 ELSE 0 END) AS C, SUM(CASE EblekAbsentType WHEN 'CH' THEN 1 ELSE 0 END) AS CH, 
                         SUM(CASE EblekAbsentType WHEN 'CT' THEN 1 ELSE 0 END) AS CT, SUM(CASE EblekAbsentType WHEN 'I' THEN 1 ELSE 0 END) AS I, SUM(CASE EblekAbsentType WHEN 'LL' THEN 1 ELSE 0 END) AS LL, 
                         SUM(CASE EblekAbsentType WHEN 'LO' THEN 1 ELSE 0 END) AS LO, SUM(CASE EblekAbsentType WHEN 'LP' THEN 1 ELSE 0 END) AS LP, SUM(CASE EblekAbsentType WHEN 'MO' THEN 1 ELSE 0 END) AS MO, 
                         SUM(CASE EblekAbsentType WHEN 'PG' THEN 1 ELSE 0 END) AS PG, SUM(CASE EblekAbsentType WHEN 'S' THEN 1 ELSE 0 END) AS S, SUM(CASE EblekAbsentType WHEN 'SB' THEN 1 ELSE 0 END) AS SB, 
                         SUM(CASE EblekAbsentType WHEN 'SKR' THEN 1 ELSE 0 END) AS SKR, SUM(CASE EblekAbsentType WHEN 'SLA' THEN 1 ELSE 0 END) AS SLA, SUM(CASE EblekAbsentType WHEN 'SLP' THEN 1 ELSE 0 END) 
                         AS SLP, SUM(CASE EblekAbsentType WHEN 'T' THEN 1 ELSE 0 END) AS T, SUM(CASE EblekAbsentType WHEN 'TL' THEN 1 ELSE 0 END) AS TL
FROM            dbo.ProductionCard
GROUP BY ProductionCardCode, LocationCode, UnitCode, ProductionDate, BrandCode, ProcessGroup, GroupCode
GO


-- Description: Get Production Card Approval List Detail (PIVOT)
-- Ticket: http://tp.voxteneo.com/entity/59045
-- Author: Whisnu Sucitanuary
-- Changes: Add Page Condition for ProductionCardApprovalDetail
ALTER PROCEDURE [dbo].[TransactionLog] 
-- Add the parameters for the stored procedure here
      @Separator        VARCHAR(20),
      @Page             VARCHAR(16),
      @Year             INT,
      @Week             INT,
      @code_1           VARCHAR(16),
      @code_2           VARCHAR(16),
      @code_3           VARCHAR(16),
      @code_4           VARCHAR(16),
      @code_5           VARCHAR(16),
      @code_6           VARCHAR(16),
      @code_7           VARCHAR(16),
      @code_8           VARCHAR(16),
      @code_9           VARCHAR(16),
      @Transaction_Date DATETIME,
      @ActionButton     VARCHAR(16),
      @ActionTime       DATETIME,
      @UserName         VARCHAR(32),
	 @TransactionCode  VARCHAR(128) = NULL
AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        DECLARE @IDFunct         INT,
                @IDButton        INT,
                @IDFlow          INT,
                --@TransactionCode VARCHAR(128),
                @MessageText     VARCHAR(128);
        -- checking the  page
        -- PLANNING
        IF( @Page LIKE 'WPP%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN				
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'Weekly%';
            END;
        IF( @Page LIKE 'TPU%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN				
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END

			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TargetProductionUnit%';
            END;
        IF( @Page LIKE 'TPKPLANT%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END

			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'PlantTargetProductionGroup%';
            END;
        IF( @Page LIKE 'TPKTPO%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOTargetProductionGroup%';
            END;
        -- MAINTENANCE
        IF( @Page LIKE 'MTNCREQ%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentRequest';
            END;
        IF( @Page LIKE 'MTNCFULL%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentFullfillment';
            END;
        IF( @Page LIKE 'MTNCFULL%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentFullfillment';
            END;
        IF( @Page LIKE 'MTNCTRANS%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentTransfer';
            END;
        IF( @Page LIKE 'MTNCRECV%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentReceive';
            END;
        IF( @Page LIKE 'MTNCREPPLNT%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentRepairPlant';
            END;
        IF( @Page LIKE 'MTNCREPTPO%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EquipmentRepairTPO';
            END;
        IF( @Page LIKE 'MTNCQI%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'QualityInspection';
            END;
        -- Plant Execution
        IF( @Page LIKE 'ABSENTEISMP%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'PieceRate';
            END;
        IF( @Page LIKE 'ABSENTEISMD%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'Daily';
            END;
        IF( @Page LIKE 'LOADBALANCINGM%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'MultiSkill';
            END;
        IF( @Page LIKE 'LOADBALANCINGS%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'SingleSkill';
            END;
        IF( @Page LIKE 'PlantProductionEntry%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'PlantProductionEntry%';
            END;
        IF( @Page LIKE 'ProductionEntryVerification' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
					SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
				
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionEntryVerification';
            END;
        IF( @Page LIKE 'TPOProductionEntry' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END

			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOProductionEntry';
            END;
        IF( @Page LIKE 'TPOProductionEntryVerification%' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'TPOProductionEntryVerification%';
            END;
        -- for wages
        IF( @Page LIKE 'ProductionCard' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
	                   SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
                
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionCard';
            END;
        IF( @Page LIKE 'ProductionCardRev' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionCardRev';
            END;
	   IF( @Page LIKE 'EblekRelease' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6);
				END
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'EblekRelease';
            END;
		IF( @Page LIKE 'ProductionCardApprovalDetail' )
            BEGIN
			 IF(@TransactionCode IS NULL OR @TransactionCode = '')
				BEGIN
				    SET @TransactionCode = CONVERT(NVARCHAR(50), @code_1) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_2) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_3) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_4) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_5) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_6) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_7) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_8) + CONVERT(NVARCHAR(50), @Separator) + CONVERT(NVARCHAR(50), @code_9);
				END
			 SELECT @IDFunct = IDFunction FROM UtilFunctions ufun WHERE ufun.FunctionName LIKE 'ProductionCardApprovalDetail';
            END;
        -- insert into transaction log table
        BEGIN
            SELECT @IDButton = IDFunction FROM UtilFunctions ufun WHERE ufun.ParentIDFunction = @IDFunct AND ufun.FunctionName = @ActionButton;
            SELECT @IDFlow = IDFlow, @MessageText = MessageText FROM UtilFlows uflow WHERE uflow.FormSource = @IDFunct AND uflow.ActionButton = @IDButton;

            INSERT INTO UtilTransactionLogs ( TransactionCode, TransactionDate, IDFlow, Comments, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy )
            VALUES( @TransactionCode, @Transaction_Date, @IDFlow, @MessageText, @ActionTime, @UserName, GETDATE(), @UserName );
        END;
    END;
GO