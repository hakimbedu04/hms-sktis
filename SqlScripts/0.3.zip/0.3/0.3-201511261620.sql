-- Description: Create View ExeProductionEntryPrintView
-- Ticket: http://tp.voxteneo.com/entity/54564
-- Author: Dwi Yudha

/****** Object:  View [dbo].[ExeProductionEntryPrintView]    Script Date: 28/10/2015 13:55:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ExeProductionEntryPrintView]
AS
SELECT DISTINCT pev.KPSYear, pev.KPSWeek, pe.EmployeeID, pe.EmployeeNumber,
        mon.AbsentType AS MonAbsentType, mon.AbsentRemark AS MonAbsentRemark, mon.ProdCapacity AS MonProdCapacity, mon.ProdTarget AS MonProdTarget, mon.ProdActual AS MonProdActual,
        tue.AbsentType AS TueAbsentType, tue.AbsentRemark AS TueAbsentRemark, tue.ProdCapacity AS TueProdCapacity, tue.ProdTarget AS TueProdTarget, tue.ProdActual AS TueProdActual,
        wed.AbsentType AS WedAbsentType, wed.AbsentRemark AS WedAbsentRemark, wed.ProdCapacity AS WedProdCapacity, wed.ProdTarget AS WedProdTarget, wed.ProdActual AS WedProdActual,
        thu.AbsentType AS ThuAbsentType, thu.AbsentRemark AS ThuAbsentRemark, thu.ProdCapacity AS ThuProdCapacity, thu.ProdTarget AS ThuProdTarget, thu.ProdActual AS ThuProdActual,
        fri.AbsentType AS FriAbsentType, fri.AbsentRemark AS FriAbsentRemark, fri.ProdCapacity AS FriProdCapacity, fri.ProdTarget AS FriProdTarget, fri.ProdActual AS FriProdActual,
        sat.AbsentType AS SatAbsentType, sat.AbsentRemark AS SatAbsentRemark, sat.ProdCapacity AS SatProdCapacity, sat.ProdTarget AS SatProdTarget, sat.ProdActual AS SatProdActual,
        sun.AbsentType AS SunAbsentType, sun.AbsentRemark AS SunAbsentRemark, sun.ProdCapacity AS SunProdCapacity, sun.ProdTarget AS SunProdTarget, sun.ProdActual AS SunProdActual,
        pev.LocationCode, pev.UnitCode, pev.Shift, pev.ProcessGroup, pev.GroupCode, pev.BrandCode
           
FROM ExePlantProductionEntry AS pe
JOIN ExePlantProductionEntryVerification AS pev ON pev.ProductionEntryCode = pe.ProductionEntryCode
LEFT JOIN ExePlantProductionEntry AS mon ON mon.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/1') AND mon.EmployeeID = pe.EmployeeID AND mon.EmployeeNumber = pe.EmployeeNumber
LEFT JOIN ExePlantProductionEntry AS tue ON tue.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/2') AND tue.EmployeeID = pe.EmployeeID AND tue.EmployeeNumber = pe.EmployeeNumber
LEFT JOIN ExePlantProductionEntry AS wed ON wed.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/3') AND wed.EmployeeID = pe.EmployeeID AND wed.EmployeeNumber = pe.EmployeeNumber
LEFT JOIN ExePlantProductionEntry AS thu ON thu.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/4') AND thu.EmployeeID = pe.EmployeeID AND thu.EmployeeNumber = pe.EmployeeNumber
LEFT JOIN ExePlantProductionEntry AS fri ON fri.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/5') AND fri.EmployeeID = pe.EmployeeID AND fri.EmployeeNumber = pe.EmployeeNumber
LEFT JOIN ExePlantProductionEntry AS sat ON sat.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/6') AND sat.EmployeeID = pe.EmployeeID AND sat.EmployeeNumber = pe.EmployeeNumber
LEFT JOIN ExePlantProductionEntry AS sun ON sun.ProductionEntryCode = ('EBL/'+pev.LocationCode+'/'+CAST( pev.Shift as varchar(1) )+'/'+pev.UnitCode+'/'+pev.GroupCode+'/'+pev.BrandCode+'/'+CAST( pev.KPSYear as varchar(4) )+'/'+CAST( pev.KPSWeek as varchar(2) )+'/7') AND sun.EmployeeID = pe.EmployeeID AND sun.EmployeeNumber = pe.EmployeeNumber
WHERE pev.ProductionEntryCode LIKE 'EBL/%'

GO