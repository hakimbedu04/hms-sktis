CREATE TABLE dbo.Tmp_ExePlantProductionEntryVerification
	(
	ProductionEntryCode varchar(64) NOT NULL,
	LocationCode varchar(64) NOT NULL,
	UnitCode varchar(64) NOT NULL,
	Shift int NOT NULL,
	ProcessGroup varchar(16) NOT NULL,
	ProcessOrder int NOT NULL,
	GroupCode varchar(20) NULL,
	BrandCode varchar(11) NOT NULL,
	KPSYear int NOT NULL,
	KPSWeek int NOT NULL,
	ProductionDate datetime NOT NULL,
	WorkHour int NOT NULL,
	TPKValue real NULL,
	TotalTargetValue int NULL,
	TotalActualValue int NULL,
	TotalCapacityValue int NULL,
	VerifySystem bit NULL,
	VerifyManual bit NULL,
	Remark varchar(256) NULL,
	CreatedDate datetime NULL,
	CreatedBy varchar(64) NULL,
	UpdatedDate datetime NULL,
	UpdatedBy varchar(64) NULL,
	Flag_Manual bit NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExePlantProductionEntryVerification SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExePlantProductionEntryVerification)
	 EXEC('INSERT INTO dbo.Tmp_ExePlantProductionEntryVerification (ProductionEntryCode, LocationCode, UnitCode, Shift, ProcessGroup, ProcessOrder, GroupCode, BrandCode, KPSYear, KPSWeek, ProductionDate, WorkHour, TPKValue, TotalTargetValue, TotalActualValue, TotalCapacityValue, VerifySystem, VerifyManual, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, Flag_Manual)
		SELECT ProductionEntryCode, LocationCode, UnitCode, Shift, ProcessGroup, ProcessOrder, GroupCode, BrandCode, KPSYear, KPSWeek, ProductionDate, WorkHour, CONVERT(real, TPKValue), TotalTargetValue, TotalActualValue, TotalCapacityValue, VerifySystem, VerifyManual, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, Flag_Manual FROM dbo.ExePlantProductionEntryVerification WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE dbo.ExeProductionEntryRelease
	DROP CONSTRAINT FK_ExeProductionEntryRelease
GO
ALTER TABLE dbo.ExePlantProductionEntry
	DROP CONSTRAINT FK_ExePlantProductionEntry_ExePlantProductionEntryVerification
GO
DROP TABLE dbo.ExePlantProductionEntryVerification
GO
EXECUTE sp_rename N'dbo.Tmp_ExePlantProductionEntryVerification', N'ExePlantProductionEntryVerification', 'OBJECT' 
GO
ALTER TABLE dbo.ExePlantProductionEntryVerification ADD CONSTRAINT
	PK_ExePlantProductionEntryVerification PRIMARY KEY CLUSTERED 
	(
	ProductionEntryCode
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExePlantProductionEntryVerification ADD CONSTRAINT
	UQ_ExePlantProductionEntryVerification UNIQUE NONCLUSTERED 
	(
	LocationCode,
	UnitCode,
	Shift,
	ProcessGroup,
	ProcessOrder,
	GroupCode,
	BrandCode,
	KPSYear,
	KPSWeek,
	ProductionDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExePlantProductionEntry WITH NOCHECK ADD CONSTRAINT
	FK_ExePlantProductionEntry_ExePlantProductionEntryVerification FOREIGN KEY
	(
	ProductionEntryCode
	) REFERENCES dbo.ExePlantProductionEntryVerification
	(
	ProductionEntryCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantProductionEntry
	NOCHECK CONSTRAINT FK_ExePlantProductionEntry_ExePlantProductionEntryVerification
GO
ALTER TABLE dbo.ExePlantProductionEntry SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.ExeProductionEntryRelease ADD CONSTRAINT
	FK_ExeProductionEntryRelease FOREIGN KEY
	(
	ProductionEntryCode
	) REFERENCES dbo.ExePlantProductionEntryVerification
	(
	ProductionEntryCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeProductionEntryRelease SET (LOCK_ESCALATION = TABLE)
