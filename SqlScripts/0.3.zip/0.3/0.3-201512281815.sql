-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
-- =============================================
-- Description: SP for Insert data to ExeReportByGroups Plant
-- Ticket: -
-- Author: Harizal
-- =============================================
CREATE PROCEDURE InsertPlantExeReportByGroups 
-- Add the parameters for the stored procedure here
       @LocationCode VARCHAR(50),
       @Unit         VARCHAR(50),
       @Brand        VARCHAR(50),
       @Shift        INT,
       @Year         INT,
       @Week         INT,
       @Date         DATETIME,
	  @CreatedBy	 varchar(50)
AS
    BEGIN
        INSERT INTO dbo.ExeReportByGroups
               ( LocationCode,
                 UnitCode,
                 ProcessGroup,
                 GroupCode,
                 BrandGroupCode,
                 BrandCode,
                 StatusEmp,
                 ProductionDate,
                 Shift,
                 Production,
                 TPKValue,
                 WorkHour,
                 WeekDay,
                 Absennce_A,
                 Absence_I,
                 Absence_C,
                 Absence_CH,
                 Absence_CT,
                 Absence_SLS,
                 Absence_SLP,
                 Absence_ETC,
                 Multi_TPO,
                 Multi_ROLL,
                 Multi_CUTT,
                 Multi_PACK,
                 Multi_STAMP,
                 Multi_FWRP,
                 Multi_SWRP,
                 Multi_GEN,
                 Multi_WRP,
                 Out,
                 Attend,
                 CreatedDate,
                 CreatedBy,
                 UpdatedDate,
                 UpdatedBy,
                 Register,
                 EmpIn,
                 KPSYear,
                 KPSWeek
               )
               SELECT eppev.LocationCode,
                      eppev.UnitCode,
                      eppev.ProcessGroup,
                      eppev.GroupCode,
                      mgb.BrandGroupCode,
                      eppev.BrandCode,
                      mges.StatusEmp,
                      eppev.ProductionDate,
                      eppev.Shift,
                      eppev.TotalActualValue Production,
                      eppev.TPKValue,
                      COALESCE(DATEDIFF(HOUR, ( DATEADD(MINUTE, (( DATEPART(HOUR, eawh.TimeIn) * 60 ) + DATEPART(MINUTE, eawh.TimeIn) * 60 ) + DATEPART(SECOND, eawh.TimeIn), eawh.BreakTime)), eawh.TimeOut), 7) WorkHour,
                      CASE DATEPART(DW, eppev.ProductionDate) - 1 WHEN 0 THEN 7 ELSE DATEPART(DW, eppev.ProductionDate) - 1 END WeekDay,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'A' ) Absence_A,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'I' ) Absence_I,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'C' ) Absence_C,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'CH' ) Absence_CH,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'CT' ) Absence_CT,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'SLS' ) Absence_SLS,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'SLP' ) Absence_SLP,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, NULL ) Absence_ETC,
                      0 Multi_TPO,
                      0 Multi_ROLL,
                      0 Multi_CUT,
                      0 Multi_PACK,
                      0 Multi_STAMP,
                      0 Multi_FWRP,
                      0 Multi_SWRP,
                      0 Multi_GEN,
                      0 Multi_WRP,
                      [dbo].GetAbsent( eppev.ProductionEntryCode, 'T' ) [Out],
                      dbo.MstPlantProductionGroup.WorkerCount - [dbo].GetAbsent( eppev.ProductionEntryCode, 'A' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'I' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'C' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'CH' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'CT' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'SLS' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'SLP' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, NULL ) [Attend],
                      GETDATE() CreatedDate,
                      @CreatedBy CreatedBy,
                      GETDATE() UpdatedDate,
                      @CreatedBy UpdatedDate,
                      dbo.MstPlantProductionGroup.WorkerCount Register,
                      dbo.MstPlantProductionGroup.WorkerCount - [dbo].GetAbsent( eppev.ProductionEntryCode, 'A' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'I' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'C' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'CH' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'CT' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'SLS' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'SLP' ) - [dbo].GetAbsent( eppev.ProductionEntryCode, NULL ) - [dbo].GetAbsent( eppev.ProductionEntryCode, 'T' ) AS [In],
                      eppev.KPSYear,
                      eppev.KPSWeek
               FROM dbo.ExePlantProductionEntryVerification eppev
                    INNER JOIN dbo.MstGenBrand mgb ON mgb.BrandCode = eppev.BrandCode
                    LEFT JOIN dbo.ExeActualWorkHours eawh ON eawh.LocationCode = eppev.LocationCode
                                                         AND eawh.UnitCode = eppev.UnitCode
                                                         AND eawh.Shift = eppev.Shift
                                                         AND eawh.ProductionDate = eppev.ProductionDate
                                                         AND eawh.ProcessGroup = eppev.ProcessGroup
                                                         AND eawh.BrandCode = eppev.BrandCode
                    LEFT JOIN dbo.MstPlantProductionGroup ON dbo.MstPlantProductionGroup.LocationCode = eppev.LocationCode
                                                         AND dbo.MstPlantProductionGroup.UnitCode = eppev.UnitCode
                                                         AND dbo.MstPlantProductionGroup.GroupCode = eppev.GroupCode
                                                         AND dbo.MstPlantProductionGroup.ProcessGroup = eppev.ProcessGroup
                    LEFT JOIN dbo.MstGenEmpStatus mges ON SUBSTRING(eppev.GroupCode, 2, 1) = mges.StatusIdentifier
               WHERE eppev.LocationCode = @LocationCode
                 AND eppev.KPSYear = @Year
                 AND eppev.KPSWeek = @Week
                 AND eppev.ProductionDate = @Date
                 AND eppev.Shift = @Shift
                 AND eppev.UnitCode = @Unit
                 AND eppev.BrandCode = @Brand;
    END;
GO