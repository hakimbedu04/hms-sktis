-- Description: Create ExePlantProductionEntryVerificationView
-- Ticket: http://tp.voxteneo.com/entity/54366
-- Author: Harizal Hilmi
/****** Object:  View [dbo].[ExePlantProductionEntryVerificationView]    Script Date: 23/11/2015 10:25:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ExePlantProductionEntryVerificationView]
AS
    SELECT eppev.ProductionEntryCode,
		 LocationCode,
		 UnitCode,
		 Shift,
		 ProcessGroup,
		 ProcessOrder,
		 GroupCode,
		 BrandCode,
		 KPSYear,
		 KPSWeek,
		 ProductionDate,
		 WorkHour,
		 TPKValue,
		 TotalTargetValue,
		 TotalActualValue,
		 TotalCapacityValue,
		 Remark,
		 CreatedDate,
		 CreatedBy,
		 UpdatedDate,
		 UpdatedBy,
		 Flag_Manual,
		 table1.A,
		 table1.I,
		 table1.C,
		 table1.CH,
		 table1.CT,
		 table1.SLS_SLP,
		 table1.ETC,
		 table1.Plant,
		 table1.Actual,
		 CASE WHEN eppev.TPKValue > 0 AND COALESCE(Actual, 0) = 0 THEN 0
			 WHEN eppev.TPKValue > 0 AND COALESCE(Actual, 0) > 0 THEN 1
			 WHEN eppev.TPKValue = 0 AND COALESCE(Actual, 0) = 0 THEN 1
		 ELSE 1 END AS VerifySystem, 
		 eppev.VerifyManual 	  
		 FROM (
			 SELECT SUM(CASE WHEN eppe.AbsentCodeEblek = 'A' THEN 1 ELSE 0 END) AS A,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'I' THEN 1 ELSE 0 END) AS I,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'C' THEN 1 ELSE 0 END) AS C,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'CH' THEN 1 ELSE 0 END) AS CH,
				   SUM(CASE WHEN eppe.AbsentCodeEblek = 'CT' THEN 1 ELSE 0 END) AS CT,
				   SUM(CASE WHEN eppe.AbsentCodeEblek IN ( 'SLS', 'SLP' ) THEN 1 ELSE 0 END) AS SLS_SLP,
				   SUM(CASE WHEN eppe.AbsentCodeEblek NOT IN ( 'SLS', 'SLP', 'CT', 'CH', 'C', 'I', 'A' ) THEN 1 ELSE 0 END) AS ETC ,
				   eppe.ProductionEntryCode,
				   SUM(eppe.ProdTarget) AS Plant,
				   SUM(eppe.ProdActual) AS Actual
			 FROM dbo.ExePlantProductionEntry eppe
				 WHERE eppe.AbsentCodeEblek IS NOT NULL
			 GROUP BY eppe.ProductionEntryCode 
    ) AS table1 INNER JOIN dbo.ExePlantProductionEntryVerification eppev ON table1.ProductionEntryCode = eppev.ProductionEntryCode

GO


