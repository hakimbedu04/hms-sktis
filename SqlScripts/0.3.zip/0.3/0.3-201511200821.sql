ALTER TABLE dbo.TPOFeeHdrPlan SET (LOCK_ESCALATION = TABLE)
GO
CREATE TABLE dbo.Tmp_TPOFeeProductionDailyPlan
	(
	TPOFeeCode varchar(64) NOT NULL,
	FeeDate date NOT NULL,
	KPSYear int NULL,
	KPSWeek int NULL,
	OuputSticks float(53) NULL,
	OutputBox float(53) NULL,
	JKN numeric(10, 0) NULL,
	JL1 numeric(10, 0) NULL,
	Jl2 numeric(10, 0) NULL,
	Jl3 numeric(10, 0) NULL,
	Jl4 numeric(10, 0) NULL,
	CreatedDate datetime NULL,
	CreatedBy varchar(64) NULL,
	UpdatedDate datetime NULL,
	UpdatedBy varchar(64) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TPOFeeProductionDailyPlan SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.TPOFeeProductionDailyPlan)
	 EXEC('INSERT INTO dbo.Tmp_TPOFeeProductionDailyPlan (FeeDate, KPSYear, KPSWeek, OuputSticks, OutputBox, JKN, JL1, Jl2, Jl3, Jl4, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT CONVERT(date, FeeDate), KPSYear, KPSWeek, OuputSticks, OutputBox, JKN, JL1, Jl2, Jl3, Jl4, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.TPOFeeProductionDailyPlan WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.TPOFeeProductionDailyPlan
GO
EXECUTE sp_rename N'dbo.Tmp_TPOFeeProductionDailyPlan', N'TPOFeeProductionDailyPlan', 'OBJECT' 
GO
ALTER TABLE dbo.TPOFeeProductionDailyPlan ADD CONSTRAINT
	PK_TPOFeeProductionDailyPlan PRIMARY KEY CLUSTERED 
	(
	TPOFeeCode,
	FeeDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.TPOFeeProductionDailyPlan ADD CONSTRAINT
	FK_TPOFeeProductionDailyPlan_TPOFeeHdrPlan FOREIGN KEY
	(
	TPOFeeCode
	) REFERENCES dbo.TPOFeeHdrPlan
	(
	TPOFeeCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO