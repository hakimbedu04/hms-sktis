-- Description: Adding new column (ProductionCardCode) to table Production Card
-- Ticket: http://tp.voxteneo.com/entity/59388
-- Author: Harizal


ALTER TABLE dbo.ProductionCard
ADD ProductionCardCode VARCHAR(64) NULL