-- Description: Please get data from ItemStatus "Sparepart" without space on table MstMntcItem.
-- Ticket: http://tp.voxteneo.com/entity/58404
-- Author: Harizal

UPDATE dbo.MstGenList set dbo.MstGenList.ListDetail = 'SPAREPART' WHERE ListDetail = 'SPARE PART'