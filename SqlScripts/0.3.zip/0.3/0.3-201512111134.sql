-- Description: Alter EquipmentRequestView
-- Ticket: http://tp.voxteneo.com/entity/59548
-- Author: Yudha

ALTER VIEW [dbo].[EquipmentRequestView]
AS
	SELECT RequestDate, 
		   ItemCode, 
		   ItemDescription, 
		   ReadyToUse, 
		   OnUse, 
		   OnRepair, 
		   TotalQty, 
		   ApprovedQty, 
		   LocationCode, 
		   RequestNumber, 
		   UpdatedBy 
	FROM   (SELECT ER.RequestDate, 
				   ER.ItemCode, 
				   MI.ItemDescription, 
				   TblInv.StackReady AS ReadyToUse, 
				   TblInv.StackOU    AS OnUse, 
				   TblInv.StackOR    AS OnRepair, 
				   ER.Qty            AS TotalQty, 
				   ER.ApprovedQty, 
				   ER.LocationCode, 
				   ER.RequestNumber, 
				   ER.UpdatedBy 
			FROM   MntcEquipmentRequest AS ER 
				   INNER JOIN MstMntcItem AS MI 
						   ON MI.ItemCode = ER.ItemCode 
				   CROSS APPLY (SELECT TOP(1) InventoryDate, 
											  ItemCode, 
											  LocationCode, 
											  ItemType, 
											  ItemDescription, 
											  Sum(CASE 
													WHEN ItemStatus = 'READY TO USE' 
												  THEN 
													EndingStock 
													ELSE 0 
												  END) AS StackReady, 
											  Sum(CASE 
													WHEN ItemStatus = 'ON USED' THEN 
													EndingStock 
													ELSE 0 
												  END) AS StackOU, 
											  Sum(CASE 
													WHEN ItemStatus = 'ON REPAIR' 
												  THEN 
													EndingStock 
													ELSE 0 
												  END) AS StackOR 
								FROM   (SELECT a.InventoryDate, 
											   a.ItemStatus, 
											   a.ItemCode, 
											   a.LocationCode, 
											   b.ItemType, 
											   b.ItemDescription, 
											   a.BeginningStock, 
											   a.StockIn, 
											   a.StockOut, 
											   a.EndingStock 
										FROM   dbo.MntcInventory AS a 
											   INNER JOIN dbo.MstMntcItem AS b 
													   ON b.ItemCode = a.ItemCode 
										WHERE  ( NOT EXISTS 
												 (SELECT 1 AS Expr1 
												  FROM   dbo.MntcInventoryDeltaView 
												  WHERE  ( InventoryDate = 
														   a.InventoryDate ) 
														 AND ( LocationCode = 
															   a.LocationCode ) 
														 AND ( UnitCode = 
															 a.UnitCode ) 
														 AND ( ItemStatus = 
															 a.ItemStatus ) 
														 AND ( ItemCode = 
											   a.ItemCode )) ) 
										UNION ALL 
										SELECT a.InventoryDate, 
											   a.ItemStatus, 
											   a.ItemCode, 
											   a.LocationCode, 
											   c.ItemType, 
											   c.ItemDescription, 
											   a.BeginningStock + b.DBeginningStock 
											   AS 
											   BeginningStock, 
											   a.StockIn + b.DStockIn 
											   AS 
											   StockIn, 
											   a.StockOut + b.DStockOut 
											   AS 
											   StockOut, 
											   a.EndingStock + b.DEndingStock 
											   AS 
											   EndingStock 
										FROM   dbo.MntcInventory AS a 
											   INNER JOIN dbo.MntcInventoryDeltaView 
														  AS b 
													   ON b.InventoryDate = 
														  a.InventoryDate 
														  AND 
											   b.ItemCode = a.ItemCode 
														  AND b.ItemStatus = 
															  a.ItemStatus 
														  AND b.LocationCode = 
															  a.LocationCode 
														  AND 
											   b.UnitCode = a.UnitCode 
											   INNER JOIN dbo.MstMntcItem AS c 
													   ON c.ItemCode = a.ItemCode 
										UNION ALL 
										SELECT ER.requestdate, 
											   '', 
											   ER.itemcode, 
											   ER.locationcode, 
											   '', 
											   '', 
											   '', 
											   '', 
											   '', 
											   '') AS Inventory 
								WHERE  LocationCode = ER.LocationCode 
									   AND ItemCode = ER.ItemCode 
									   AND InventoryDate = ER.RequestDate 
								GROUP  BY InventoryDate, 
										  ItemCode, 
										  LocationCode, 
										  ItemType, 
										  ItemDescription
								ORDER BY ItemType DESC) AS TblInv) AS EquipmentRequestView
GO


