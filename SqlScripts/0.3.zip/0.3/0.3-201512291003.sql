-- Description: Get Report By Status from ExeReportByGroups
-- Author: Whisnu Sucitanuary
-- Version: 1.0

CREATE VIEW [dbo].[ExeReportByStatusView]
AS
SELECT        g.LocationCode, g.UnitCode, g.Shift, g.BrandCode, g.ProcessGroup, g.StatusEmp, 
                         SUM(g.EmpIn - (g.Multi_CUTT + g.Multi_FWRP + g.Multi_GEN + g.Multi_PACK + g.Multi_ROLL + g.Multi_STAMP + g.Multi_SWRP + g.Multi_TPO + g.Multi_WRP)) AS ActualWorker, 
                         SUM(g.Absence_C + g.Absence_CH + g.Absence_CT + g.Absence_ETC + g.Absence_I + g.Absence_SLP + g.Absence_SLS + g.Absennce_A) AS ActualAbsWorker, AVG(g.WorkHour) AS ActualWorkHour, 
                         SUM(g.Production) AS PrdPerStk, SUM(g.Production) / AVG(g.WorkHour) 
                         / SUM(g.EmpIn - g.Multi_CUTT + g.Multi_FWRP + g.Multi_GEN + g.Multi_PACK + g.Multi_ROLL + g.Multi_STAMP + g.Multi_SWRP + g.Multi_TPO + g.Multi_WRP) AS StkPerHrPerPpl, SUM(g.Production) 
                         / AVG(g.WorkHour) AS StkPerHr, ROUND(CONVERT(decimal, SUM(g.Production)) /
                             (SELECT        SUM(Production) AS Expr1
                               FROM            dbo.ExeReportByGroups
                               WHERE        (LocationCode = g.LocationCode) AND (UnitCode = g.UnitCode) AND (BrandCode = g.BrandCode) AND (ProductionDate = g.ProductionDate)), 3) AS BalanceIndex, g.ProductionDate
FROM            dbo.ExeReportByGroups AS g INNER JOIN
                         dbo.MstGenProcess AS p ON p.ProcessGroup = g.ProcessGroup INNER JOIN
                         dbo.MstGenEmpStatus AS e ON e.StatusEmp = g.StatusEmp
GROUP BY g.LocationCode, g.UnitCode, g.Shift, g.BrandCode, g.ProcessGroup, g.StatusEmp, g.ProductionDate
GO


-- Description: Get Weekly Report By Status from ExeReportByGroups
-- Author: Whisnu Sucitanuary
-- Version: 1.0

CREATE VIEW [dbo].[ExeReportByStatusWeeklyView]
AS
SELECT        g.LocationCode, g.UnitCode, g.Shift, g.BrandCode, g.ProcessGroup, g.StatusEmp, 
                         SUM(g.EmpIn - (g.Multi_CUTT + g.Multi_FWRP + g.Multi_GEN + g.Multi_PACK + g.Multi_ROLL + g.Multi_STAMP + g.Multi_SWRP + g.Multi_TPO + g.Multi_WRP)) AS ActualWorker, 
                         SUM(g.Absence_C + g.Absence_CH + g.Absence_CT + g.Absence_ETC + g.Absence_I + g.Absence_SLP + g.Absence_SLS + g.Absennce_A) AS ActualAbsWorker, AVG(g.WorkHour) AS ActualWorkHour, 
                         SUM(g.Production) AS PrdPerStk, SUM(g.Production) / AVG(g.WorkHour) 
                         / SUM(g.EmpIn - g.Multi_CUTT + g.Multi_FWRP + g.Multi_GEN + g.Multi_PACK + g.Multi_ROLL + g.Multi_STAMP + g.Multi_SWRP + g.Multi_TPO + g.Multi_WRP) AS StkPerHrPerPpl, SUM(g.Production) 
                         / AVG(g.WorkHour) AS StkPerHr, ROUND(CONVERT(decimal, SUM(g.Production)) /
                             (SELECT        SUM(Production) AS Expr1
                               FROM            dbo.ExeReportByGroupsWeekly
                               WHERE        (LocationCode = g.LocationCode) AND (UnitCode = g.UnitCode) AND (BrandCode = g.BrandCode) AND (KPSYear = g.KPSYear) AND (KPSWeek = g.KPSWeek)), 3) AS BalanceIndex, g.KPSYear, 
                         g.KPSWeek
FROM            dbo.ExeReportByGroupsWeekly AS g INNER JOIN
                         dbo.MstGenProcess AS p ON p.ProcessGroup = g.ProcessGroup INNER JOIN
                         dbo.MstGenEmpStatus AS e ON e.StatusEmp = g.StatusEmp
GROUP BY g.LocationCode, g.UnitCode, g.Shift, g.BrandCode, g.ProcessGroup, g.StatusEmp, g.KPSYear, g.KPSWeek
GO


-- Description: Get Monthly Report By Status from ExeReportByGroups
-- Author: Whisnu Sucitanuary
-- Version: 1.0

CREATE VIEW [dbo].[ExeReportByStatusMonthlyView]
AS
SELECT        g.LocationCode, g.UnitCode, g.Shift, g.BrandCode, g.ProcessGroup, g.StatusEmp, 
                         SUM(g.EmpIn - (g.Multi_CUTT + g.Multi_FWRP + g.Multi_GEN + g.Multi_PACK + g.Multi_ROLL + g.Multi_STAMP + g.Multi_SWRP + g.Multi_TPO + g.Multi_WRP)) AS ActualWorker, 
                         SUM(g.Absence_C + g.Absence_CH + g.Absence_CT + g.Absence_ETC + g.Absence_I + g.Absence_SLP + g.Absence_SLS + g.Absennce_A) AS ActualAbsWorker, AVG(g.WorkHour) AS ActualWorkHour, 
                         SUM(g.Production) AS PrdPerStk, SUM(g.Production) / AVG(g.WorkHour) 
                         / SUM(g.EmpIn - g.Multi_CUTT + g.Multi_FWRP + g.Multi_GEN + g.Multi_PACK + g.Multi_ROLL + g.Multi_STAMP + g.Multi_SWRP + g.Multi_TPO + g.Multi_WRP) AS StkPerHrPerPpl, SUM(g.Production) 
                         / AVG(g.WorkHour) AS StkPerHr, ROUND(CONVERT(decimal, SUM(g.Production)) /
                             (SELECT        SUM(Production) AS Expr1
                               FROM            dbo.ExeReportByGroupsMonthly
                               WHERE        (LocationCode = g.LocationCode) AND (UnitCode = g.UnitCode) AND (BrandCode = g.BrandCode) AND (Year = g.Year) AND (Month = g.Month)), 3) AS BalanceIndex, g.Year, g.Month
FROM            dbo.ExeReportByGroupsMonthly AS g INNER JOIN
                         dbo.MstGenProcess AS p ON p.ProcessGroup = g.ProcessGroup INNER JOIN
                         dbo.MstGenEmpStatus AS e ON e.StatusEmp = g.StatusEmp
GROUP BY g.LocationCode, g.UnitCode, g.Shift, g.BrandCode, g.ProcessGroup, g.StatusEmp, g.Year, g.Month
GO