-- Description: Rename SQl Script
-- Ticket: Rename Sql Script Name
-- Author: Harizal

/****** Object:  View [dbo].[TargetProductionUnitViewPerBox]    Script Date: 06/11/2015 10:18:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'TargetProductionUnitStickPerBoxView') BEGIN
    EXEC sp_rename 'dbo.TargetProductionUnitStickPerBoxView', 'TargetProductionUnitPerBoxView'
END