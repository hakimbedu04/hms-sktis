-- Description: Update ExeReportByGroups
-- Ticket: story/56093-Update DB based on spec
-- Author: Bagus

Alter Table ExeReportByGroups Add Register int
