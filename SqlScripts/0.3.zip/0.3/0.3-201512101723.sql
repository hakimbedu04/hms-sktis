-- =============================================
-- Description: Create GetUserAdByRoleLocation
-- Ticket: http://tp.voxteneo.co.id/entity/264
-- Author: Harizal
-- =============================================


CREATE PROCEDURE [dbo].[GetUserAdByRoleLocation]
	@RoleCode varchar(50),
	@Location varchar(50)
AS
BEGIN

    SELECT uur.*, ur.RolesCode, ur3.Location
    FROM dbo.UtilRoles ur
	    INNER JOIN dbo.UtilResponsibility ur2 ON ur2.IDRole = ur.IDRole
	    INNER JOIN dbo.UtilResponsibilityRules urr ON urr.IDResponsibility = ur2.IDResponsibility
	    INNER JOIN dbo.UtilRules ur3 ON ur3.IDRule = urr.IDRule
	    INNER JOIN dbo.UtilUsersResponsibility uur ON uur.IDResponsibility = ur2.IDResponsibility
    WHERE ur.RolesCode = @RoleCode AND ur3.Location = @Location;
END

GO


