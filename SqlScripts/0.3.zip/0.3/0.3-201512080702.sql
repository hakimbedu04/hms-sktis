ALTER TABLE dbo.PlanTPOTargetProductionKelompokBox ADD
	ProcessWorkHours1 real NULL,
	ProcessWorkHours2 real NULL,
	ProcessWorkHours3 real NULL,
	ProcessWorkHours4 real NULL,
	ProcessWorkHours5 real NULL,
	ProcessWorkHours6 real NULL,
	ProcessWorkHours7 real NULL,
	TotalWorkHours real NULL