-- =============================================
-- Author:		Harizal Hilmi
-- Create date:	Hari ini
-- Description:	http://tp.voxteneo.co.id/entity/1513
-- =============================================
ALTER PROCEDURE [dbo].[GetReportSummaryProcessTargets]
	@Location varchar(50),
	@Year int,
	@Week int,
	@DateFrom datetime,
	@DateTo date,
	@Decimal int
AS
BEGIN

    DECLARE @StarDateWeek date, @EndDateWeek date
    -- Get StartDate and EndDate from MstGenWeek
    SELECT @StarDateWeek = mgw.StartDate, @EndDateWeek = mgw.EndDate FROM dbo.MstGenWeek mgw WHERE mgw.Week = @Week AND mgw.Year = @Year

    DECLARE @int int =  1, 
		  @query1 varchar(max) = 'SELECT pptpk.LocationCode, pptpk.BrandCode, pptpk.ProcessGroup, pptpk.KPSYear, pptpk.KPSWeek,',
		  @query2 varchar(max) = '';
    SELECT  @int = DATEDIFF(DAY, @StarDateWeek, @DateFrom)

    WHILE @DateFrom <= @DateTo
    BEGIN   
	  IF @int >= 7
   	    BEGIN
     	    SET @int = @int%7
	    END
	  
	  SET @query2 = @query2 + ' ISNULL(pptpk.TargetManual' + CAST(@int + 1 AS varchar) +', 0) +'
	  SET @int = @int + 1
	  SET @DateFrom = DateAdd(day, 1, @DateFrom)
	  
    END

    DECLARE @pptpkTable AS TABLE (LocationCode varchar(50), UnitCode varchar(50), BrandCode varchar(50), ProcessGroup varchar(50), KPSYear int, KPSWeek int, TargetManual real)
    DECLARE @pttpkTable AS TABLE (LocationCode varchar(50), UnitCode varchar(50), BrandCode varchar(50), ProcessGroup varchar(50), KPSYear int, KPSWeek int, TargetManual real)

    INSERT INTO @pptpkTable ( LocationCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual, UnitCode )
    EXEC (@query1 + @query2 + '0 AS TargetManual, pptpk.UnitCode FROM PlanPlantTargetProductionKelompok pptpk' )

    INSERT INTO @pttpkTable ( LocationCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual, UnitCode )
    EXEC (@query1 + @query2 + '0 AS TargetManual, ''PROD'' UnitCode FROM PlanTPOTargetProductionKelompok pptpk')

    SET @int = 1;
    DECLARE @indexWIPDetail int = 1;
    WHILE @StarDateWeek <= @EndDateWeek
    BEGIN
	   IF @StarDateWeek = @DateTo
   	    BEGIN
     	    SET @indexWIPDetail = @int
	    END
	    SET @int = @int + 1
	    SET @StarDateWeek = DateAdd(day, 1, @StarDateWeek)
    END

    SET @query1 = 'SELECT ppw.LocationCode, ppw.UnitCode,ppw.BrandCode,''WIPGunting'' AS ProcessGroup, ppw.KPSYear, ppw.KPSWeek, ppw.WIPStock' + CAST(@indexWIPDetail AS varchar) + ' FROM dbo.PlanPlantWIPDetail ppw WHERE ppw.ProcessGroup =''GUNTING'' '
    SET @query2 = 'SELECT ppw.LocationCode, ppw.UnitCode,ppw.BrandCode,''WIPPak'' AS ProcessGroup, ppw.KPSYear, ppw.KPSWeek, ppw.WIPStock' + CAST(@indexWIPDetail AS varchar) + ' FROM dbo.PlanPlantWIPDetail ppw WHERE ppw.ProcessGroup =''Pak'' '
    INSERT INTO @pptpkTable ( LocationCode, UnitCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual )
    EXEC (@query1)
    INSERT INTO @pptpkTable ( LocationCode, UnitCode, BrandCode, ProcessGroup, KPSYear, KPSWeek, TargetManual )
    EXEC (@query2)
    
    --SELECT * FROM @pptpkTable

    SELECT Result.LocationCode,
	    Result.UnitCode,
	    Result.BrandCode,
	    ISNULL(Result.ROLLING, 0) Giling,
	    ISNULL(Result.CUTTING, 0) Gunting,
	    ISNULL(Result.PACKING, 0) Pak,
	    ISNULL(Result.WIPGunting, 0) WIPGunting,
	    ISNULL(Result.WIPPak, 0) WIPPak,
	    ISNULL(Result.Banderol, 0) AS Banderol,
	    (ISNULL(Result.ROLLING, 0) + ISNULL(Result.CUTTING, 0) + ISNULL(Result.PACKING, 0) + ISNULL(Result.WIPGunting, 0) + ISNULL(Result.WIPPak, 0) + ISNULL(Result.Banderol, 0)) / mgbg.BalPerBox AS Box
    FROM (
	    SELECT [LocationCode], [UnitCode], [BrandCode], [ROLLING], [CUTTING], [PACKING], [WRAPPING] + [STAMPING] AS Banderol, [WIPGunting], [WIPPak]
	    FROM (
		    SELECT * FROM (
			    SELECT pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup, SUM(pptpk.TargetManual) AS TargetManual1 FROM @pptpkTable pptpk
			    WHERE ( pptpk.LocationCode IN ( SELECT LocationCode FROM [dbo].[GetLocations](@Location, - 1) ) ) AND pptpk.KPSYear = @Year AND pptpk.KPSWeek = @Week
			    GROUP BY pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup ) AS A
		    ) AS B
	    PIVOT(SUM(TargetManual1) FOR [ProcessGroup] IN ( [ROLLING], [CUTTING], [PACKING], [WRAPPING], [STAMPING], [WIPGunting], [WIPPak] )) AS P
	
	    UNION
	
	    SELECT [LocationCode], [UnitCode], [BrandCode], [ROLLING], [CUTTING], [PACKING], [WRAPPING] + [STAMPING] AS Banderol, 0 AS WIPGunting, 0 WIPPak
	    FROM (
		    SELECT * FROM (
			    SELECT pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup, SUM(pptpk.TargetManual) AS TargetManual1 FROM @pttpkTable pptpk
			    WHERE ( pptpk.LocationCode IN ( SELECT LocationCode FROM [dbo].[GetLocations](@Location, - 1) ) ) AND pptpk.KPSYear = @Year AND pptpk.KPSWeek = @Week
			    GROUP BY pptpk.LocationCode, pptpk.UnitCode, pptpk.BrandCode, pptpk.ProcessGroup ) AS A
		    ) AS B
	    PIVOT(SUM(TargetManual1) FOR [ProcessGroup] IN ( [ROLLING], [CUTTING], [PACKING], [WRAPPING], [STAMPING] )) AS P
	    ) AS Result
    LEFT JOIN dbo.MstGenBrand mgb	ON Result.BrandCode = mgb.BrandCode
    INNER JOIN dbo.MstGenBrandGroup mgbg ON mgbg.BrandGroupCode = mgb.BrandGroupCode
END


GO


