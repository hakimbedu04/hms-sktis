-- Description: Change table ExeTPOProduction schema
-- Ticket: http://tp.voxteneo.com/entity/57379
-- Author: Oka

-- Drop table ExePlantProductionEntry
DROP TABLE ExeTPOProduction

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExeTPOProduction
(
ProductionEntryCode VARCHAR(64) NOT NULL,
StatusEmp VARCHAR(64) NOT NULL,
StatusIdentifier INTEGER NOT NULL,
ProductionGroup VARCHAR(20) NOT NULL,
WorkerCount INTEGER,
Absent INTEGER,
ActualProduction REAL,
CreatedDate DATETIME NOT NULL,
CreatedBy VARCHAR(64) NOT NULL,
UpdatedDate DATETIME NOT NULL,
UpdatedBy VARCHAR(64) NOT NULL,
CONSTRAINT PK_ExeTPOProduction PRIMARY KEY (ProductionEntryCode, StatusEmp),
CONSTRAINT FK_ExeTPOProduction_ExeTPOProductionEntryVerification FOREIGN KEY(ProductionEntryCode)
REFERENCES ExeTPOProductionEntryVerification(ProductionEntryCode)
);