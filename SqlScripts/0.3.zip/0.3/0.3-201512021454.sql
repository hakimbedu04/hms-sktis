-- Description: Alter Column Absent in ProdCard
-- Ticket: submit Production Entry Verification
-- Author: Harizal Hilmi

ALTER TABLE dbo.ProductionCard
ALTER COLUMN Absent varchar(128)