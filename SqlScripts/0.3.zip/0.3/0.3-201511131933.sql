-- Description: DROP COLUMN ApprovedQty on MntcEquipmentFulfillment
-- Ticket: http://tp.voxteneo.com/entity/58245
-- Author: Oka

ALTER TABLE MntcEquipmentFulfillment
DROP COLUMN ApprovedQty