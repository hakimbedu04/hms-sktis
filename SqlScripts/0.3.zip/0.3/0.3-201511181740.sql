CREATE TABLE [dbo].[PlanTPOTargetProductionKelompokBox](
	[KPSYear] [int] NOT NULL,
	[KPSWeek] [int] NOT NULL,
	[LocationCode] [varchar](8) NOT NULL,
	[BrandCode] [varchar](11) NOT NULL,
	[TargetSystem1] [real] NULL,
	[TargetSystem2] [real] NULL,
	[TargetSystem3] [real] NULL,
	[TargetSystem4] [real] NULL,
	[TargetSystem5] [real] NULL,
	[TargetSystem6] [real] NULL,
	[TargetSystem7] [real] NULL,
	[TargetManual1] [real] NULL,
	[TargetManual2] [real] NULL,
	[TargetManual3] [real] NULL,
	[TargetManual4] [real] NULL,
	[TargetManual5] [real] NULL,
	[TargetManual6] [real] NULL,
	[TargetManual7] [real] NULL,
	[TotalTargetSystem] [real] NULL,
	[TotalTargetManual] [real] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](64) NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
	[UpdatedBy] [varchar](64) NOT NULL,
 CONSTRAINT [PK_PlanTPOTargetProductionKelompokBox_1] PRIMARY KEY CLUSTERED 
(
	[KPSYear] ASC,
	[KPSWeek] ASC,
	[LocationCode] ASC,
	[BrandCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[PlanTPOTargetProductionKelompokBox]  WITH CHECK ADD  CONSTRAINT [FK_PlanTPOTargetProductionKelompokBox_MstGenBrand] FOREIGN KEY([BrandCode])
REFERENCES [dbo].[MstGenBrand] ([BrandCode])
GO

ALTER TABLE [dbo].[PlanTPOTargetProductionKelompokBox] CHECK CONSTRAINT [FK_PlanTPOTargetProductionKelompokBox_MstGenBrand]
GO

ALTER TABLE [dbo].[PlanTPOTargetProductionKelompokBox]  WITH CHECK ADD  CONSTRAINT [FK_PlanTPOTargetProductionKelompokBox_MstGenLocation] FOREIGN KEY([LocationCode])
REFERENCES [dbo].[MstGenLocation] ([LocationCode])
GO

ALTER TABLE [dbo].[PlanTPOTargetProductionKelompokBox] CHECK CONSTRAINT [FK_PlanTPOTargetProductionKelompokBox_MstGenLocation]
GO


