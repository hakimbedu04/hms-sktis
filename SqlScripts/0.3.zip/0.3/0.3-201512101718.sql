-- Description: ALTER TABLE TPOFeeHdr
-- Author: Oka

ALTER TABLE TPOFeeHdr
ADD TotalJKN FLOAT, TotalJL1 FLOAT, TotalJL2 FLOAT, TotalJL3 FLOAT, TotalJL4 FLOAT