/****** Object:  View [dbo].[MaintenanceExecutionInventoryView]    Script Date: 23/10/2015 17:21:29 ******/
-- Description: Change InventoryView and UI
-- Ticket: http://tp.voxteneo.com/entity/56427
-- Author: Harizal

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[MaintenanceExecutionInventoryView]
AS
   -- SELECT ItemCode AS [Item Code], LocationCode,
		 --SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
			--	THEN mia.BeginningStock ELSE 0 END) AS StawIT,
		 --SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
			--	THEN mia.StockIn ELSE 0 END) AS InIT,
		 --SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
			--	THEN mia.StockOut ELSE 0 END) AS OutIT,
		 --SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
			--	THEN mia.EndingStock ELSE 0 END) AS StackIT,
		 --SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
			--	THEN mia.BeginningStock ELSE 0 END) AS StawQI,
		 --SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
			--	THEN mia.StockIn ELSE 0 END) AS InQI,
		 --SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
			--	THEN mia.StockOut ELSE 0 END) AS OutQI,
		 --SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
			--	THEN mia.EndingStock ELSE 0 END) AS StackQI,
		 --SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
			--	THEN mia.BeginningStock ELSE 0 END) AS StawReady,
		 --SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
			--	THEN mia.StockIn ELSE 0 END) AS InReady,
		 --SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
			--	THEN mia.StockOut ELSE 0 END) AS OutReady,
		 --SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
			--	THEN mia.EndingStock ELSE 0 END) AS StackReady,
		 --SUM(CASE WHEN mia.itemstatus = 'ON USED'  
			--	THEN mia.BeginningStock ELSE 0 END) AS StawOU,
		 --SUM(CASE WHEN mia.itemstatus = 'ON USED'  
			--	THEN mia.StockIn ELSE 0 END) AS InOU,
		 --SUM(CASE WHEN mia.itemstatus = 'ON USED'  
			--	THEN mia.StockOut ELSE 0 END) AS OutOU,
		 --SUM(CASE WHEN mia.itemstatus = 'ON USED'  
			--	THEN mia.EndingStock ELSE 0 END) AS StackOU,
		 --SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
			--	THEN mia.BeginningStock ELSE 0 END) AS StawOR,
		 --SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
			--	THEN mia.StockIn ELSE 0 END) AS InOR,
		 --SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
			--	THEN mia.StockOut ELSE 0 END) AS OutOR,
		 --SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
			--	THEN mia.EndingStock ELSE 0 END) AS StackOR,
		 --SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
			--	THEN mia.BeginningStock ELSE 0 END) AS StawBS,
		 --SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
			--	THEN mia.StockIn ELSE 0 END) AS InBS,
		 --SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
			--	THEN mia.StockOut ELSE 0 END) AS OutBS,
		 --SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
			--	THEN mia.EndingStock ELSE 0 END) AS StackBS
   -- FROM dbo.MntcInventoryAll mia
   -- WHERE mia.InventoryDate = CONVERT(date, GETDATE())
   -- GROUP BY --mia.InventoryDate,
		 --  mia.LocationCode,
		 --  --mia.UnitCode,
		 --  mia.ItemCode;

SELECT InventoryDate,
       ItemCode,
       LocationCode,
       ItemType,
       ItemDescription,
       SUM(CASE WHEN ItemStatus = 'IN TRANSIT' THEN BeginningStock ELSE 0 END) AS StawIT,
       SUM(CASE WHEN ItemStatus = 'IN TRANSIT' THEN StockIn ELSE 0 END) AS InIT,
       SUM(CASE WHEN ItemStatus = 'IN TRANSIT' THEN StockOut ELSE 0 END) AS OutIT,
       SUM(CASE WHEN ItemStatus = 'IN TRANSIT' THEN EndingStock ELSE 0 END) AS StackIT,
       SUM(CASE WHEN ItemStatus = 'ON QUALITY INSPECTION' THEN BeginningStock ELSE 0 END) AS StawQI,
       SUM(CASE WHEN ItemStatus = 'ON QUALITY INSPECTION' THEN StockIn ELSE 0 END) AS InQI,
       SUM(CASE WHEN ItemStatus = 'ON QUALITY INSPECTION' THEN StockOut ELSE 0 END) AS OutQI,
       SUM(CASE WHEN ItemStatus = 'ON QUALITY INSPECTION' THEN EndingStock ELSE 0 END) AS StackQI,
       SUM(CASE WHEN ItemStatus = 'READY TO USE' THEN BeginningStock ELSE 0 END) AS StawReady,
       SUM(CASE WHEN ItemStatus = 'READY TO USE' THEN StockIn ELSE 0 END) AS InReady,
       SUM(CASE WHEN ItemStatus = 'READY TO USE' THEN StockOut ELSE 0 END) AS OutReady,
       SUM(CASE WHEN ItemStatus = 'READY TO USE' THEN EndingStock ELSE 0 END) AS StackReady,
       SUM(CASE WHEN ItemStatus = 'ON USED' THEN BeginningStock ELSE 0 END) AS StawOU,
       SUM(CASE WHEN ItemStatus = 'ON USED' THEN StockIn ELSE 0 END) AS InOU,
       SUM(CASE WHEN ItemStatus = 'ON USED' THEN StockOut ELSE 0 END) AS OutOU,
       SUM(CASE WHEN ItemStatus = 'ON USED' THEN EndingStock ELSE 0 END) AS StackOU,
       SUM(CASE WHEN ItemStatus = 'ON REPAIR' THEN BeginningStock ELSE 0 END) AS StawOR,
       SUM(CASE WHEN ItemStatus = 'ON REPAIR' THEN StockIn ELSE 0 END) AS InOR,
       SUM(CASE WHEN ItemStatus = 'ON REPAIR' THEN StockOut ELSE 0 END) AS OutOR,
       SUM(CASE WHEN ItemStatus = 'ON REPAIR' THEN EndingStock ELSE 0 END) AS StackOR,
       SUM(CASE WHEN ItemStatus = 'BAD STOCK' THEN BeginningStock ELSE 0 END) AS StawBS,
       SUM(CASE WHEN ItemStatus = 'BAD STOCK' THEN StockIn ELSE 0 END) AS InBS,
       SUM(CASE WHEN ItemStatus = 'BAD STOCK' THEN StockOut ELSE 0 END) AS OutBS,
       SUM(CASE WHEN ItemStatus = 'BAD STOCK' THEN EndingStock ELSE 0 END) AS StackBS
FROM(
    SELECT a.InventoryDate,
           a.ItemStatus,
           a.ItemCode,
           a.LocationCode,
           b.ItemType,
           b.ItemDescription,
           BeginningStock,
           StockIn,
           StockOut,
           EndingStock
    FROM [MntcInventory] a
         INNER JOIN [MstMntcItem] b ON b.ItemCode = a.ItemCode
    WHERE NOT EXISTS(
             SELECT 1
             FROM [MntcInventoryDeltaView]
             WHERE InventoryDate = a.InventoryDate
               AND LocationCode = a.LocationCode
               AND UnitCode = a.UnitCode
               AND ItemStatus = a.ItemStatus
               AND ItemCode = a.ItemCode )
    UNION ALL
    SELECT a.InventoryDate,
           a.ItemStatus,
           a.ItemCode,
           a.LocationCode,
           c.ItemType,
           c.ItemDescription,
           BeginningStock + DBeginningStock AS BeginningStock,
           StockIn + DStockIn AS StockIn,
           StockOut + DStockOut AS StockOut,
           EndingStock + DEndingStock AS EndingStock
    FROM [MntcInventory] a
         INNER JOIN [MntcInventoryDeltaView] b ON b.InventoryDate = a.InventoryDate
                                              AND b.ItemCode = a.ItemCode
                                              AND b.ItemStatus = a.ItemStatus
                                              AND b.LocationCode = a.LocationCode
                                              AND b.UnitCode = a.UnitCode
         INNER JOIN [MstMntcItem] c ON c.ItemCode = a.ItemCode ) AS Inventory
GROUP BY Inventory.InventoryDate,
         --Inventory.ItemStatus,
         Inventory.ItemCode,
         Inventory.LocationCode,
         Inventory.ItemType,
         Inventory.ItemDescription;

GO

