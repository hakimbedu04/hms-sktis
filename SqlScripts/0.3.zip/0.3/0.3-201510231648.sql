-- Description: Update Table Exe TPO Production
-- Ticket: http://tp.voxteneo.com/entity/56093
-- Author: Bagus
CREATE TABLE dbo.Tmp_ExeTPOProduction
	(
	LocationCode varchar(8) NOT NULL,
	ProcessGroup varchar(16) NULL,
	ProcessOrder int NULL,
	StatusEmp varchar(16) NULL,
	StatusIdentifier char(1) NULL,
	ProductionGroup char(4) NOT NULL,
	KPSYear int NULL,
	KPSWeek int NULL,
	ProductionDate datetime NOT NULL,
	TPOProductionEntryCode varchar(255) NULL,
	TPOProductionEntryStatus int NULL,
	WorkHour int NULL,
	WorkerCount int NULL,
	Absent int NULL,
	ActualProduction int NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExeTPOProduction SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExeTPOProduction)
	 EXEC('INSERT INTO dbo.Tmp_ExeTPOProduction (LocationCode, ProcessGroup, StatusEmp, ProductionGroup, KPSYear, KPSWeek, ProductionDate, TPOProductionEntryCode, TPOProductionEntryStatus, WorkerCount, Absent, ActualProduction, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT LocationCode, ProcessGroup, StatusEmp, ProdGroup, KPSYear, KPSWeek, TPOProductionEntryDate, TPOProductionEntryCode, TPOProductionEntryStatus, WorkerCount, Absent, ActualProduction, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ExeTPOProduction WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ExeTPOProduction
GO
EXECUTE sp_rename N'dbo.Tmp_ExeTPOProduction', N'ExeTPOProduction', 'OBJECT' 
GO
ALTER TABLE dbo.ExeTPOProduction ADD CONSTRAINT
	PK_ExeTPOProduction_1 PRIMARY KEY CLUSTERED 
	(
	LocationCode,
	ProductionGroup,
	ProductionDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO