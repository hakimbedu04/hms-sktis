-- Description: TPOFeeExeActualView
-- Ticket: http://tp.voxteneo.co.id/entity/263
-- Author: Harizal

CREATE VIEW [dbo].[TPOFeeExeActualView]
AS
     SELECT th.TPOFeeCode,
            mgl.LocationName,
            mgbg.SKTBrandCode,
                 CASE utl.IDFlow
                     WHEN 40 THEN 'Open'
                     WHEN 41 THEN 'Draft'
                     WHEN 42 THEN 'Submited'
                     ELSE 'Open'
                 END AS Status,
            utl.CreatedBy PIC,
            th.LocationCode,
            th.BrandGroupCode,
            th.KPSYear,
            th.KPSWeek,
            th.BrandCode,
            th.TPOFeeTempID,
            th.TaxtNoProd,
            th.TaxtNoMgmt,
            th.CurrentApproval,
            th.CreatedDate,
            th.CreatedBy,
            th.UpdatedDate,
            th.UpdatedBy,
            th.Status AS Expr1,
            th.PengirimanL1,
            th.PengirimanL2,
            th.PengirimanL3,
            th.PengirimanL4,
            th.StickPerBox,
            th.TPOPackageValue,
            th.StickPerPackage,
            th.TotalProdStick,
            th.TotalProdBox,
            th.TotalProdJKN,
            th.TotalProdJl1,
            th.TotalProdJl2,
            th.TotalProdJl3,
            th.TotalProdJl4
     FROM dbo.TPOFeeHdr AS th
          INNER JOIN dbo.MstGenLocation AS mgl ON mgl.LocationCode = th.LocationCode
          INNER JOIN dbo.MstGenBrandGroup AS mgbg ON mgbg.BrandGroupCode = th.BrandGroupCode
          INNER JOIN( 
                      SELECT MAX(TransactionDate) AS TransDate,
                             TransactionCode AS TransCode
                      FROM dbo.UtilTransactionLogs AS utl
                      GROUP BY TransactionCode ) AS TransactionLogGroup ON th.TPOFeeCode = TransactionLogGroup.TransCode
          INNER JOIN dbo.UtilTransactionLogs AS utl ON TransactionLogGroup.TransDate = utl.TransactionDate
                                                   AND TransactionLogGroup.TransCode = utl.TransactionCode;
GO