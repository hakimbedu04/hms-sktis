GO
ALTER TABLE dbo.MstGenProcess SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.MstGenEmpStatus SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.ProductAdjustment
	DROP CONSTRAINT FK_PRODUCTADJUSTMENT_RELATIONSHIP_146_MSTPLANTUNIT
GO
ALTER TABLE dbo.MstPlantUnit SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.ProductAdjustment
	DROP CONSTRAINT FK_PRODUCTADJUSTMENT_RELATIONSHIP_145_MSTGENBRAND
GO
ALTER TABLE dbo.MstGenBrand SET (LOCK_ESCALATION = TABLE)
GO
GO
CREATE TABLE dbo.Tmp_ProductAdjustment
	(
	ProductionDate datetime NOT NULL,
	UnitCode varchar(4) NOT NULL,
	LocationCode varchar(8) NOT NULL,
	Shift int NOT NULL,
	BrandCode varchar(11) NOT NULL,
	ProcessGroup varchar(16) NOT NULL,
	AdjustmentType varchar(64) NOT NULL,
	CreatedDate datetime NULL,
	CreatedBy varchar(64) NULL,
	UpdatedDate datetime NULL,
	UpdatedBy varchar(64) NULL,
	AdjustmentValue int NULL,
	AdjustmentRemark varchar(128) NULL,
	StatusEmp varchar(16) NULL,
	StatusIdentifier char(1) NULL,
	GroupCode varchar(4) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ProductAdjustment SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ProductAdjustment)
	 EXEC('INSERT INTO dbo.Tmp_ProductAdjustment (ProducttionDate, UnitCode, LocationCode, BrandCode, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT ProducttionDate, UnitCode, LocationCode, BrandCode, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ProductAdjustment WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ProductAdjustment
GO
EXECUTE sp_rename N'dbo.Tmp_ProductAdjustment', N'ProductAdjustment', 'OBJECT' 
GO
ALTER TABLE dbo.ProductAdjustment ADD CONSTRAINT
	PK_PRODUCTADJUSTMENT PRIMARY KEY NONCLUSTERED 
	(
	ProductionDate,
	UnitCode,
	LocationCode,
	Shift,
	BrandCode,
	ProcessGroup,
	AdjustmentType
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ProductAdjustment ADD CONSTRAINT
	FK_PRODUCTADJUSTMENT_RELATIONSHIP_145_MSTGENBRAND FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ProductAdjustment ADD CONSTRAINT
	FK_PRODUCTADJUSTMENT_RELATIONSHIP_146_MSTPLANTUNIT FOREIGN KEY
	(
	UnitCode,
	LocationCode
	) REFERENCES dbo.MstPlantUnit
	(
	UnitCode,
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ProductAdjustment ADD CONSTRAINT
	FK_ProductAdjustment_MstGenEmpStatus FOREIGN KEY
	(
	StatusEmp
	) REFERENCES dbo.MstGenEmpStatus
	(
	StatusEmp
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ProductAdjustment ADD CONSTRAINT
	FK_ProductAdjustment_MstGenProcess FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
