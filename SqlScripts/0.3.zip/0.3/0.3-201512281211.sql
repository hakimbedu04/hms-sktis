--Description   : Extending BrandCode By Location View
--Author		: Whisnu

ALTER VIEW [dbo].[BrandCodeByLocationView]
AS
SELECT        B.BrandCode, BG.BrandGroupCode, BG.StatusActive, BG.SKTBrandCode, PSL.LocationCode
FROM            dbo.MstGenBrand AS B INNER JOIN
                         dbo.MstGenBrandGroup AS BG ON BG.BrandGroupCode = B.BrandGroupCode INNER JOIN
                         dbo.MstGenProcessSettings AS PS ON PS.BrandGroupCode = BG.BrandGroupCode INNER JOIN
						 dbo.MstGenProcessSettingsMapping PM ON PM.ProcessSettingsID = PS.ID INNER JOIN
                         dbo.MstGenProcessSettingsLocation AS PSL ON PSL.ID = PM.ProcessSettingsLocationID
GROUP BY B.BrandCode, BG.BrandGroupCode, BG.StatusActive, BG.SKTBrandCode, PSL.LocationCode

GO


