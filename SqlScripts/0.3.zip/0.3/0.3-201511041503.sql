-- Description: Change table ExeTPOProductionEntryVerification schema
-- Ticket: http://tp.voxteneo.com/entity/57390
-- Author: Oka

-- Drop table ExePlantProductionEntry
DROP TABLE ExeTPOProductionEntryVerification

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExeTPOProductionEntryVerification
(
ProductionEntryCode VARCHAR(64) NOT NULL,
LocationCode VARCHAR(8) NOT NULL,
ProcessGroup VARCHAR(16) NOT NULL,
ProcessOrder INTEGER NOT NULL,
BrandCode VARCHAR(11) NOT NULL,
KPSYear INTEGER NOT NULL,
KPSWeek INTEGER NOT NULL,
ProductionDate DATETIME NOT NULL,
WorkHour INTEGER NOT NULL,
TotalTPKValue REAL,
TotalActualValue REAL,
VerifySystem BIT,
VerifyManual BIT,
Remark VARCHAR,
CreatedDate DATETIME NOT NULL,
CreatedBy VARCHAR(64) NOT NULL,
UpdatedDate DATETIME NOT NULL,
UpdatedBy VARCHAR(64) NOT NULL,
CONSTRAINT PK_ExeTPOProductionEntryVerification PRIMARY KEY (ProductionEntryCode)
);