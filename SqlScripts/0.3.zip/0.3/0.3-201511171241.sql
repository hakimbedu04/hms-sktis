-- Description: Update to MntcAllView
-- Ticket: bug/8417 Point all the views related to Inventory to MtncinventoryViewAll
-- Author: Bagus
ALTER VIEW [dbo].[EquipmentRequestView]
AS
     SELECT RequestDate,
            ItemCode,
            ItemDescription,
            [Ready to Use] AS ReadyToUse,
            [On Used] AS OnUse,
            [On Repair] AS OnRepair,
            TotalQty,
            ApprovedQty,
            LocationCode,
            RequestNumber,
            UpdatedBy
     FROM( 
           SELECT ER.RequestDate,
                  ER.ItemCode,
                  MI.ItemDescription,
                  I.EndingStock,
                  I.ItemStatus,
                  ER.Qty AS TotalQty,
                  ER.ApprovedQty,
                  ER.LocationCode,
                  ER.RequestNumber,
                  ER.UpdatedBy
           FROM MntcEquipmentRequest AS ER
                INNER JOIN MstMntcItem AS MI ON MI.ItemCode = ER.ItemCode
                LEFT JOIN(
                    SELECT s1.InventoryDate,
                           s1.ItemCode,
                           s1.LocationCode,
                           s1.ItemStatus,
                           s1.EndingStock
                    FROM MntcInventoryAll s1
                         INNER JOIN(
                             SELECT MAX(InventoryDate) LAST_UPDATE_DATE_TIME,
                                    ItemCode,
                                    LocationCode,
                                    ItemStatus
                             FROM MntcInventoryAll
                             GROUP BY ItemCode,
                                      LocationCode,
                                      ItemStatus ) s2 ON s1.ItemCode = s2.ItemCode
                                                     AND s1.LocationCode = s2.LocationCode
                                                     AND s1.InventoryDate = s2.LAST_UPDATE_DATE_TIME
                                                     AND s1.ItemStatus = s2.ItemStatus ) AS I ON ER.ItemCode = I.ItemCode
                                                                                             AND ER.LocationCode = I.LocationCode ) AS A PIVOT( MAX(EndingStock) FOR ItemStatus IN( [Ready to Use],
                                                                                                                                                                                    [On Used],
                                                                                                                                                                                    [On Repair] )) AS EquipmentRequestView;

GO


