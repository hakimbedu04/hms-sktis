-- Description: Create View ExeTPOProductionView
-- Ticket: Task/#54566-View http://tp.voxteneo.com/entity/54566
-- Author: Harizal Hilmi

/****** Object:  View [dbo].[ExeTPOProductionView]    Script Date: 28/10/2015 13:55:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ExeTPOProductionView]
AS
SELECT        et.LocationCode, et.ProcessGroup, et.ProcessOrder, et.StatusEmp, et.StatusIdentifier, et.ProductionGroup, et.KPSYear, et.KPSWeek, et.ProductionDate, et.TPOProductionEntryCode, et.TPOProductionEntryStatus, 
                         et.WorkHour, et.WorkerCount, et.Absent, et.ActualProduction, et.CreatedDate, et.CreatedBy, et.UpdatedDate, et.UpdatedBy,et.BrandCode, ptpk_1.TotalTargetManual
FROM            dbo.ExeTPOProduction AS et LEFT JOIN
                             (SELECT        KPSYear, KPSWeek, ProcessGroup, LocationCode, StatusEmp, COALESCE (SUM(TotalTargetManual), 0) AS TotalTargetManual
                               FROM            dbo.PlanTPOTargetProductionKelompok AS ptpk
                               GROUP BY KPSYear, KPSWeek, ProcessGroup, LocationCode, StatusEmp) AS ptpk_1 ON ptpk_1.KPSYear = et.KPSYear AND ptpk_1.KPSWeek = et.KPSWeek AND ptpk_1.ProcessGroup = et.ProcessGroup AND 
                         ptpk_1.LocationCode = et.LocationCode AND ptpk_1.StatusEmp = et.StatusEmp

GO