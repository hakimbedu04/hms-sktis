-- Description: Alter view MaintenanceEquipmentFulfillmentView
-- Ticket: http://tp.voxteneo.com/entity/58245
-- Author: Oka

ALTER VIEW MaintenanceEquipmentFulfillmentView
AS
SELECT table1.LocationCode,
       table1.RequestDate,
       table1.RequestNumber,
       table1.CreatedBy,
       table1.FulFillmentDate,
       table1.ItemCode,
       table1.ItemDescription,
       tblInventoriReadyToUse.EndingStock AS ReadyToUse,
       tblInventoriOnUse.EndingStock AS OnUse,
       tblInventoriOnRepair.EndingStock AS OnRepair,
       table1.Qty AS RequestedQuantity,
       table1.ApprovedQty,
       table1.RequestToQty,
       table1.ApprovedQty - CASE
                                WHEN table1.RequestToQty IS NULL
                                THEN 0
                                ELSE table1.RequestToQty
                            END AS PurchaseQuantity,
       table1.PurchaseNumber,
       table1.UpdatedDate
FROM( 
      SELECT dbo.MntcEquipmentFulfillment.LocationCode,
             dbo.MntcEquipmentFulfillment.RequestDate,
             dbo.MntcEquipmentFulfillment.RequestNumber,
             dbo.MntcEquipmentFulfillment.CreatedBy,
             dbo.MntcEquipmentFulfillment.FulFillmentDate,
             dbo.MntcEquipmentFulfillment.ItemCode,
             dbo.MstMntcItem.ItemDescription,
             dbo.MntcEquipmentRequest.Qty,
             dbo.MntcEquipmentFulfillment.ApprovedQty,
             dbo.MntcEquipmentFulfillment.RequestToQty,
             dbo.MntcEquipmentFulfillment.PurchaseNumber,
             dbo.MntcEquipmentFulfillment.UpdatedDate
      FROM dbo.MntcEquipmentFulfillment
           INNER JOIN dbo.MstMntcItem ON dbo.MntcEquipmentFulfillment.ItemCode = dbo.MstMntcItem.ItemCode
           INNER JOIN dbo.MntcEquipmentRequest ON dbo.MntcEquipmentFulfillment.RequestDate = dbo.MntcEquipmentRequest.RequestDate
                                              AND dbo.MntcEquipmentFulfillment.ItemCode = dbo.MntcEquipmentRequest.ItemCode
                                              AND dbo.MntcEquipmentFulfillment.LocationCode = dbo.MntcEquipmentRequest.LocationCode
                                              AND dbo.MntcEquipmentFulfillment.RequestNumber = dbo.MntcEquipmentRequest.RequestNumber ) AS table1
    CROSS APPLY( 
                 SELECT TOP 1 InventoryDate,
                              ItemStatus,
                              ItemCode,
                              LocationCode,
                              UnitCode,
                              BeginningStock,
                              StockIn,
                              StockOut,
                              EndingStock
                 FROM dbo.MntcInventory
                 WHERE ItemStatus = 'Ready to Use'
                   AND ItemCode = table1.ItemCode
                   AND LocationCode = table1.LocationCode
                 ORDER BY InventoryDate DESC ) AS tblInventoriReadyToUse
               CROSS APPLY( 
                            SELECT TOP ( 1 ) InventoryDate,
                                             ItemStatus,
                                             ItemCode,
                                             LocationCode,
                                             UnitCode,
                                             BeginningStock,
                                             StockIn,
                                             StockOut,
                                             EndingStock
                            FROM dbo.MntcInventory
                            WHERE ItemStatus = 'On Used'
                              AND ItemCode = table1.ItemCode
                              AND LocationCode = table1.LocationCode
                            ORDER BY InventoryDate DESC ) AS tblInventoriOnUse
                          CROSS APPLY( 
                                       SELECT TOP ( 1 ) InventoryDate,
                                                        ItemStatus,
                                                        ItemCode,
                                                        LocationCode,
                                                        UnitCode,
                                                        BeginningStock,
                                                        StockIn,
                                                        StockOut,
                                                        EndingStock
                                       FROM dbo.MntcInventory AS MntcInventory_1
                                       WHERE ItemStatus = 'On Repair'
                                         AND ItemCode = table1.ItemCode
                                         AND LocationCode = table1.LocationCode
                                       ORDER BY InventoryDate DESC ) AS tblInventoriOnRepair;
GO