CREATE TABLE dbo.Tmp_ExePlantProductionEntryVerification
	(
	ProductionDate datetime NOT NULL,
	KPSYear int NOT NULL,
	KPSWeek int NOT NULL,
	ProcessGroup varchar(16) NOT NULL,
	GroupCode varchar(4) NOT NULL,
	BrandCode varchar(11) NOT NULL,
	LocationCode varchar(8) NOT NULL,
	UnitCode varchar(4) NOT NULL,
	Shift int NOT NULL,
	WorkHours int NOT NULL,
	ProductionDay int NOT NULL,
	TPKValue real NULL,
	StatusEmp varchar(16) NULL,
	StatusIdentifier char(1) NULL,
	ProcessOrder int NULL,
	TotalTargetValue int NULL,
	TotalActualValue int NULL,
	TotalCapacityValue int NULL,
	VerifySystem bit NULL,
	VerifyManual bit NULL,
	Remark varchar(256) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExePlantProductionEntryVerification SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExePlantProductionEntryVerification)
	 EXEC('INSERT INTO dbo.Tmp_ExePlantProductionEntryVerification (ProductionDate, KPSYear, KPSWeek, ProcessGroup, GroupCode, BrandCode, LocationCode, UnitCode, Shift, WorkHours, ProductionDay, TPKValue, StatusEmp, StatusIdentifier, ProcessOrder, TotalTargetValue, TotalActualValue, TotalCapacityValue, VerifySystem, VerifyManual, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT ProductionDate, KPSYear, KPSWeek, ProcessGroup, GroupCode, BrandCode, LocationCode, UnitCode, Shift, WorkHours, ProductionDay, CONVERT(real, TPKValue), StatusEmp, StatusIdentifier, ProcessOrder, TotalTargetValue, TotalActualValue, TotalCapacityValue, VerifySystem, VerifyManual, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ExePlantProductionEntryVerification WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ExePlantProductionEntryVerification
GO
EXECUTE sp_rename N'dbo.Tmp_ExePlantProductionEntryVerification', N'ExePlantProductionEntryVerification', 'OBJECT' 
GO
ALTER TABLE dbo.ExePlantProductionEntryVerification ADD CONSTRAINT
	PK_ExePlantProductionEntryVerification PRIMARY KEY CLUSTERED 
	(
	ProductionDate,
	KPSYear,
	KPSWeek,
	ProcessGroup,
	GroupCode,
	BrandCode,
	LocationCode,
	UnitCode,
	Shift,
	WorkHours,
	ProductionDay
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
