/****** Script for SelectTopNRows command from SSMS  ******/
ALTER view [dbo].[MntcInventoryAll] as
SELECT a.InventoryDate,
       a.ItemStatus,
       a.ItemCode,
       a.LocationCode,
       b.ItemType,
       b.ItemDescription,
       BeginningStock,
       StockIn,
       StockOut,
       EndingStock
FROM [MntcInventory] a
     INNER JOIN [MstMntcItem] b ON b.ItemCode = a.ItemCode
WHERE NOT EXISTS( 
                  SELECT 1
                  FROM [MntcInventoryDeltaView]
                  WHERE InventoryDate = a.InventoryDate
                    AND LocationCode = a.LocationCode
                    AND UnitCode = a.UnitCode
                    AND ItemStatus = a.ItemStatus
                    AND ItemCode = a.ItemCode )
UNION ALL
SELECT a.InventoryDate,
       a.ItemStatus,
       a.ItemCode,
       a.LocationCode,
       c.ItemType,
       c.ItemDescription,
       BeginningStock + DBeginningStock AS BeginningStock,
       StockIn + DStockIn AS StockIn,
       StockOut + DStockOut AS StockOut,
       EndingStock + DEndingStock AS EndingStock
FROM [MntcInventory] a
     INNER JOIN [MntcInventoryDeltaView] b ON b.InventoryDate = a.InventoryDate
                                          AND b.ItemCode = a.ItemCode
                                          AND b.ItemStatus = a.ItemStatus
                                          AND b.LocationCode = a.LocationCode
                                          AND b.UnitCode = a.UnitCode
     INNER JOIN [MstMntcItem] c ON c.ItemCode = a.ItemCode
--WHERE b.InventoryDate = a.InventoryDate
--  AND b.LocationCode = a.LocationCode
--  AND b.UnitCode = a.UnitCode
--  AND b.ItemStatus = a.ItemStatus
--  AND b.ItemCode = a.ItemCode;
GO


