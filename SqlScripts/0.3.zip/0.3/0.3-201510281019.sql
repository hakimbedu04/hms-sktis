-- Description: Get UserAD and Location ( need this view to get location by Responsibility )
-- Ticket: http://tp.voxteneo.com/entity/54537
-- Author: Oka

CREATE VIEW [dbo].GetLocationByResponsibilityView
AS

SELECT        dbo.MstADTemp.UserAD, dbo.UtilRules.Location
FROM            dbo.MstADTemp INNER JOIN
                         dbo.UtilUsersResponsibility ON dbo.MstADTemp.UserAD = dbo.UtilUsersResponsibility.UserAD INNER JOIN
                         dbo.UtilResponsibilityRules ON dbo.UtilUsersResponsibility.IDResponsibility = dbo.UtilResponsibilityRules.IDResponsibility INNER JOIN
                         dbo.UtilRules ON dbo.UtilResponsibilityRules.IDRule = dbo.UtilRules.IDRule

GO