ALTER TABLE dbo.ExeMaterialUsage
	DROP CONSTRAINT FK_EXEMATERIALUSAGE_RELATIONSHIP_44_MSTPLANTPRODUCTIONGROUP
GO
ALTER TABLE dbo.MstPlantProductionGroup SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.ExeMaterialUsage
	DROP CONSTRAINT FK_EXEMATERIALUSAGE_RELATIONSHIP_38_MSTGENMATERIAL
GO
ALTER TABLE dbo.MstGenMaterial SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.ExeMaterialUsage
	DROP CONSTRAINT FK_EXEMATERIALUSAGE_RELATIONSHIP_125_MSTGENBRANDGROUP
GO
ALTER TABLE dbo.MstGenBrandGroup SET (LOCK_ESCALATION = TABLE)
GO
CREATE TABLE dbo.Tmp_ExeMaterialUsage
	(
	LocationCode varchar(8) NOT NULL,
	UnitCode varchar(4) NULL,
	Shift int NOT NULL,
	BrandGroupCode varchar(20) NOT NULL,
	MaterialCode varchar(11) NOT NULL,
	GroupCode varchar(4) NOT NULL,
	ProcessGroup varchar(16) NULL,
	ProductionDate datetime NOT NULL,
	Sisa int NULL,
	Ambil1 int NULL,
	Ambil2 int NULL,
	Ambil3 int NULL,
	TobFM int NULL,
	TobStem int NULL,
	TobSapon int NULL,
	UncountableWaste int NULL,
	CountableWaste int NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExeMaterialUsage SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExeMaterialUsage)
	 EXEC('INSERT INTO dbo.Tmp_ExeMaterialUsage (LocationCode, UnitCode, BrandGroupCode, MaterialCode, GroupCode, ProcessGroup, ProductionDate, Sisa, Ambil1, Ambil2, Ambil3, TobFM, TobStem, TobSapon, UncountableWaste, CountableWaste, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT LocationCode, UnitCode, BrandGroupCode, MaterialCode, GroupCode, ProcessGroup, MaterialUsageDate, Sisa, Ambil1, Ambil2, Ambil3, TobFM, TobStem, TobSapon, UncountableWaste, CountableWaste, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ExeMaterialUsage WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ExeMaterialUsage
GO
EXECUTE sp_rename N'dbo.Tmp_ExeMaterialUsage', N'ExeMaterialUsage', 'OBJECT' 
GO
ALTER TABLE dbo.ExeMaterialUsage ADD CONSTRAINT
	PK_ExeMaterialUsage PRIMARY KEY CLUSTERED 
	(
	LocationCode,
	BrandGroupCode,
	MaterialCode,
	GroupCode,
	ProductionDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExeMaterialUsage ADD CONSTRAINT
	FK_EXEMATERIALUSAGE_RELATIONSHIP_125_MSTGENBRANDGROUP FOREIGN KEY
	(
	BrandGroupCode
	) REFERENCES dbo.MstGenBrandGroup
	(
	BrandGroupCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeMaterialUsage ADD CONSTRAINT
	FK_EXEMATERIALUSAGE_RELATIONSHIP_38_MSTGENMATERIAL FOREIGN KEY
	(
	MaterialCode
	) REFERENCES dbo.MstGenMaterial
	(
	MaterialCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeMaterialUsage ADD CONSTRAINT
	FK_EXEMATERIALUSAGE_RELATIONSHIP_44_MSTPLANTPRODUCTIONGROUP FOREIGN KEY
	(
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) REFERENCES dbo.MstPlantProductionGroup
	(
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
