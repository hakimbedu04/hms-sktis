CREATE VIEW [dbo].[ExePlantWorkerBalancingSingle]
AS
select *  from( select iw.EmployeeID,acvs.EmployeeNumber,acvs.EmployeeName,iw.LocationCode,iw.UnitCode as UnitCodeSource,iw.GroupCode,iw.ProcessGroup,'' as UnitCodeDestination,'' as GroupCodeDestination,cast('FALSE' as bit) as statfrom from PlanPlantIndividualCapacityWorkHours as iw inner join MstPlantEmpJobsDataAcv acvs on iw.EmployeeID = acvs.EmployeeID) as Y
 union
 select * from( select asgn.EmployeeID,asgn.EmployeeNumber,acvs.EmployeeName,asgn.SourceLocationCode as LocationCode,asgn.SourceUnitCode as UnitCodeSource,asgn.SourceGroupCode as GroupCodeSource,asgn.SourceProcessGroup as ProcessGroup,asgn.DestinationUnitCode as UnitCodeDestination,asgn.DestinationGroupCode as GroupCodeDestination,cast('TRUE' as bit) as statfrom from ExePlantWorkerAssignment as asgn inner join MstPlantEmpJobsDataAcv acvs on asgn.EmployeeID = acvs.EmployeeID
 where asgn.SourceProcessGroup = asgn.DestinationProcessGroup and CONVERT(VARCHAR(10),asgn.TransactionDate,110)=CONVERT(VARCHAR(10),GETDATE(),110)) as X 
GO

