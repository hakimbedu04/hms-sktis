ALTER TABLE dbo.TPOFeeHdr SET (LOCK_ESCALATION = TABLE)
GO
CREATE TABLE dbo.Tmp_TPOFeeCalculation
	(
	TPOFeeCode varchar(64) NOT NULL,
	ProductionFeeType int NOT NULL,
	KPSYear int NULL,
	KPSWeek int NULL,
	OrderFeeType int NULL,
	OutputProduction float(53) NULL,
	OutputBiaya float(53) NULL,
	Calculate float(53) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TPOFeeCalculation SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.TPOFeeCalculation)
	 EXEC('INSERT INTO dbo.Tmp_TPOFeeCalculation (ProductionFeeType, KPSYear, KPSWeek, OrderFeeType, OutputProduction, OutputBiaya, Calculate)
		SELECT ProductionFeeType, KPSYear, KPSWeek, [Order], OutputProduction, OutputBiaya, Calculate FROM dbo.TPOFeeCalculation WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.TPOFeeCalculation
GO
EXECUTE sp_rename N'dbo.Tmp_TPOFeeCalculation', N'TPOFeeCalculation', 'OBJECT' 
GO
ALTER TABLE dbo.TPOFeeCalculation ADD CONSTRAINT
	PK_TPOFeeCalculation_1 PRIMARY KEY CLUSTERED 
	(
	TPOFeeCode,
	ProductionFeeType
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.TPOFeeCalculation ADD CONSTRAINT
	FK_TPOFeeCalculation_TPOFeeHdr FOREIGN KEY
	(
	TPOFeeCode
	) REFERENCES dbo.TPOFeeHdr
	(
	TPOFeeCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

