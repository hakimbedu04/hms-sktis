-- Description: Change source MaintenanceExecutionInventoryView from MntcInventoryDeltaView to be MntcInventoryAll
-- Ticket: Bug#56354 - Change action on inventory page
-- Author: Harizal Hilmi

/****** Object:  View [dbo].[MaintenanceExecutionInventoryView]    Script Date: 23/10/2015 9:28:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[MaintenanceExecutionInventoryView]
AS
    SELECT ItemCode AS [Item Code], LocationCode,
		 SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
				THEN mia.BeginningStock ELSE 0 END) AS StawIT,
		 SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
				THEN mia.StockIn ELSE 0 END) AS InIT,
		 SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
				THEN mia.StockOut ELSE 0 END) AS OutIT,
		 SUM(CASE WHEN mia.itemstatus = 'IN TRANSIT' 
				THEN mia.EndingStock ELSE 0 END) AS StackIT,
		 SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
				THEN mia.BeginningStock ELSE 0 END) AS StawQI,
		 SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
				THEN mia.StockIn ELSE 0 END) AS InQI,
		 SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
				THEN mia.StockOut ELSE 0 END) AS OutQI,
		 SUM(CASE WHEN mia.itemstatus = 'ON QUALITY INSPECTION'  
				THEN mia.EndingStock ELSE 0 END) AS StackQI,
		 SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
				THEN mia.BeginningStock ELSE 0 END) AS StawReady,
		 SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
				THEN mia.StockIn ELSE 0 END) AS InReady,
		 SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
				THEN mia.StockOut ELSE 0 END) AS OutReady,
		 SUM(CASE WHEN mia.itemstatus = 'READY TO USE'  
				THEN mia.EndingStock ELSE 0 END) AS StackReady,
		 SUM(CASE WHEN mia.itemstatus = 'ON USED'  
				THEN mia.BeginningStock ELSE 0 END) AS StawOU,
		 SUM(CASE WHEN mia.itemstatus = 'ON USED'  
				THEN mia.StockIn ELSE 0 END) AS InOU,
		 SUM(CASE WHEN mia.itemstatus = 'ON USED'  
				THEN mia.StockOut ELSE 0 END) AS OutOU,
		 SUM(CASE WHEN mia.itemstatus = 'ON USED'  
				THEN mia.EndingStock ELSE 0 END) AS StackOU,
		 SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
				THEN mia.BeginningStock ELSE 0 END) AS StawOR,
		 SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
				THEN mia.StockIn ELSE 0 END) AS InOR,
		 SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
				THEN mia.StockOut ELSE 0 END) AS OutOR,
		 SUM(CASE WHEN mia.itemstatus = 'ON REPAIR'  
				THEN mia.EndingStock ELSE 0 END) AS StackOR,
		 SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
				THEN mia.BeginningStock ELSE 0 END) AS StawBS,
		 SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
				THEN mia.StockIn ELSE 0 END) AS InBS,
		 SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
				THEN mia.StockOut ELSE 0 END) AS OutBS,
		 SUM(CASE WHEN mia.itemstatus = 'BAD STOCK'  
				THEN mia.EndingStock ELSE 0 END) AS StackBS
    FROM dbo.MntcInventoryAll mia
    WHERE mia.InventoryDate = CONVERT(date, GETDATE())
    GROUP BY --mia.InventoryDate,
		   mia.LocationCode,
		   --mia.UnitCode,
		   mia.ItemCode;
GO


