-- Description: Alter ExeTPOProductionView for column migration from ExeTPOProduction to ExeTPOProductionEntryVerification table
-- Ticket: http://tp.voxteneo.com/entity/57777
-- Author: Whisnu

ALTER VIEW [dbo].[ExeTPOProductionView]
AS
SELECT        
	ete.LocationCode, 
	ete.ProcessGroup, 
	ete.ProcessOrder, 
	et.StatusEmp, 
	et.StatusIdentifier, 
	et.ProductionGroup, 
	ete.KPSYear, 
	ete.KPSWeek, 
	ete.ProductionDate, 
	ete.ProductionEntryCode,
	--et.TPOProductionEntryStatus, 
	ete.WorkHour, 
	et.WorkerCount, 
	et.Absent, 
	et.ActualProduction, 
	et.CreatedDate, 
	et.CreatedBy, 
	et.UpdatedDate, 
	et.UpdatedBy,
	ete.BrandCode, 
	ptpk.TotalTargetManual
FROM            
	dbo.ExeTPOProduction AS et INNER JOIN
	dbo.ExeTPOProductionEntryVerification ete ON ete.ProductionEntryCode = et.ProductionEntryCode LEFT OUTER JOIN
	(SELECT        
		KPSYear, 
		KPSWeek, 
		ProcessGroup, 
		LocationCode, 
		StatusEmp, 
		COALESCE (SUM(TotalTargetManual), 0) AS TotalTargetManual
	FROM            
		dbo.PlanTPOTargetProductionKelompok AS ptpk
	GROUP BY KPSYear, KPSWeek, ProcessGroup, LocationCode, StatusEmp) AS ptpk 
	ON ptpk.KPSYear = ete.KPSYear AND 
		ptpk.KPSWeek = ete.KPSWeek AND 
		ptpk.ProcessGroup = ete.ProcessGroup AND 
		ptpk.LocationCode = ete.LocationCode AND 
		ptpk.StatusEmp = et.StatusEmp

GO


