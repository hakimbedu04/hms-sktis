-- Description: delete UOM and ItemType on MntcInventory
-- Ticket: http://tp.voxteneo.com/entity/56427
-- Author: Bagus
alter table MntcInventory drop column UOM
alter table MntcInventory drop column ItemType