ALTER TABLE dbo.TPOFeeHdrPlan SET (LOCK_ESCALATION = TABLE)
GO
CREATE TABLE dbo.Tmp_TPOFeeCalculationPlan
	(
	TPOFeeCode varchar(64) NOT NULL,
	ProductionFeeType int NOT NULL,
	KPSYear int NULL,
	KPSWeek int NULL,
	OrderFeeType int NULL,
	OutputProduction float(53) NULL,
	OutputBiaya float(53) NULL,
	Calculate float(53) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TPOFeeCalculationPlan SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.TPOFeeCalculationPlan)
	 EXEC('INSERT INTO dbo.Tmp_TPOFeeCalculationPlan (ProductionFeeType, KPSYear, KPSWeek, OrderFeeType, OutputProduction, OutputBiaya, Calculate)
		SELECT ProductionFeeType, KPSYear, KPSWeek, [Order], OutputProduction, OutputBiaya, Calculate FROM dbo.TPOFeeCalculationPlan WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.TPOFeeCalculationPlan
GO
EXECUTE sp_rename N'dbo.Tmp_TPOFeeCalculationPlan', N'TPOFeeCalculationPlan', 'OBJECT' 
GO
ALTER TABLE dbo.TPOFeeCalculationPlan ADD CONSTRAINT
	PK_TPOFeeCalculationPlan_1 PRIMARY KEY CLUSTERED 
	(
	TPOFeeCode,
	ProductionFeeType
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.TPOFeeCalculationPlan ADD CONSTRAINT
	FK_TPOFeeCalculationPlan_TPOFeeHdrPlan FOREIGN KEY
	(
	TPOFeeCode
	) REFERENCES dbo.TPOFeeHdrPlan
	(
	TPOFeeCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 	
GO
