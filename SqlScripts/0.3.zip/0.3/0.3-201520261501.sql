-- Description: Worker Absenteeism View (need employee and absent type detail)
-- Ticket: http://tp.voxteneo.com/entity/56270
-- Author: Whisnu

CREATE VIEW [dbo].[ExePlantWorkerAbsenteeismView]
AS
SELECT        emp.EmployeeNumber, emp.EmployeeName, emp.ProcessSettingsCode, emp.GroupCode, abs.SktAbsentCode, abs.PayrollAbsentCode, wa.StartDateAbsent, wa.EmployeeID, wa.AbsentType, wa.EndDateAbsent, 
                         wa.ePaf, wa.Attachment, wa.AttachmentPath, wa.CreatedDate, wa.CreatedBy, wa.UpdatedDate, wa.UpdatedBy, wa.LocationCode, wa.UnitCode, wa.TransactionDate, wa.Shift
FROM            dbo.ExePlantWorkerAbsenteeism AS wa INNER JOIN
                         dbo.MstPlantEmpJobsDataAcv AS emp ON emp.EmployeeID = wa.EmployeeID INNER JOIN
                         dbo.MstPlantAbsentType AS abs ON abs.AbsentType = wa.AbsentType

GO