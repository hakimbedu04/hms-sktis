-- Description: Create new view ExePlantActualWorkHours
-- Ticket: task/33129-54570-save
-- Author: Yudha

GO
IF OBJECT_ID('ExePlantActualWorkHoursView', 'V') IS NOT NULL
    DROP VIEW [dbo].[ExePlantActualWorkHoursView];
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ExePlantActualWorkHoursView]
AS
SELECT DISTINCT 
                         pu.UnitCode, psl.LocationCode, p.ProcessGroup, p.ProcessOrder, null as BrandCode, null as StatusIdentifier, null as ProductionDate, null as Shift, null as StatusEmp, null as TimeIn, 
                         null as TimeOut, null as BreakTime
FROM            dbo.MstGenProcessSettingsLocation AS psl INNER JOIN
                         dbo.MstGenProcessSettingsMapping AS psm ON psm.ProcessSettingsLocationID = psl.ID INNER JOIN
                         dbo.MstGenProcessSettings AS ps ON ps.ID = psm.ProcessSettingsID INNER JOIN
                         dbo.MstGenProcess AS p ON p.ProcessGroup = ps.ProcessGroup INNER JOIN
                         dbo.MstPlantUnit AS pu ON pu.LocationCode = psl.LocationCode 
WHERE        (p.StatusActive = 1)