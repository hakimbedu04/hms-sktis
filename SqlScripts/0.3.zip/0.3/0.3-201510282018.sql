
ALTER TABLE dbo.MstGenProcessSettings
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_40_MSTGENPROCESS
GO
ALTER TABLE dbo.MstGenProcess SET (LOCK_ESCALATION = TABLE)
GO

ALTER TABLE dbo.MstGenProcessSettings
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_18_MSTGENBRANDGROUP
GO
ALTER TABLE dbo.MstGenBrandGroup SET (LOCK_ESCALATION = TABLE)
GO

CREATE TABLE dbo.Tmp_MstGenProcessSettings
	(
	IDProcess int NOT NULL,
	BrandGroupCode varchar(20) NULL,
	ProcessGroup varchar(16) NULL,
	ProcessIdentifier char(1) NOT NULL,
	StdStickPerHour int NULL,
	MinStickPerHour int NULL,
	UOMEblek int NULL,
	Remark varchar(256) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_MstGenProcessSettings SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.MstGenProcessSettings)
	 EXEC('INSERT INTO dbo.Tmp_MstGenProcessSettings (IDProcess, BrandGroupCode, ProcessGroup, ProcessIdentifier, StdStickPerHour, MinStickPerHour, UOMEblek, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT IDProcess, BrandGroupCode, ProcessGroup, ProcessIdentifier, StdStickPerHour, MinStickPerHour, UOMEblek, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.MstGenProcessSettings WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE dbo.MstGenProcessSettingsLocation
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGSLOC_RELATIONSHIP_16_MSTGENPROCESSSETTINGS
GO
DROP TABLE dbo.MstGenProcessSettings
GO
EXECUTE sp_rename N'dbo.Tmp_MstGenProcessSettings', N'MstGenProcessSettings', 'OBJECT' 
GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	PK_MSTGENPROCESSSETTINGS PRIMARY KEY NONCLUSTERED 
	(
	IDProcess,
	ProcessIdentifier
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_18_MSTGENBRANDGROUP FOREIGN KEY
	(
	BrandGroupCode
	) REFERENCES dbo.MstGenBrandGroup
	(
	BrandGroupCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_40_MSTGENPROCESS FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE dbo.MstGenProcessSettingsLocation ADD CONSTRAINT
	FK_MSTGENPROCESSSETTINGSLOC_RELATIONSHIP_16_MSTGENPROCESSSETTINGS FOREIGN KEY
	(
	IDProcess,
	ProcessIdentifier
	) REFERENCES dbo.MstGenProcessSettings
	(
	IDProcess,
	ProcessIdentifier
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.MstGenProcessSettingsLocation SET (LOCK_ESCALATION = TABLE)
GO
