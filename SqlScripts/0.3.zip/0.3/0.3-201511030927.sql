-- Description: Process Settings and Location Relation Modification
-- Ticket: http://tp.voxteneo.com/entity/56130
-- Author: Whisnu


-- MODIFIER MSTGENPROCESSSETTINGSLOCATION SCHEME
ALTER TABLE dbo.MstGenProcessSettingsLocation
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGSLOC_RELATIONSHIP_17_MSTGENLOCATION
GO
ALTER TABLE dbo.MstGenLocation SET (LOCK_ESCALATION = TABLE)
GO

ALTER TABLE dbo.MstGenProcessSettingsLocation
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGSLOC_RELATIONSHIP_16_MSTGENPROCESSSETTINGS
GO
ALTER TABLE dbo.MstGenProcessSettings SET (LOCK_ESCALATION = TABLE)
GO

CREATE TABLE dbo.Tmp_MstGenProcessSettingsLocation
	(
	ID bigint NOT NULL IDENTITY (1, 1),
	--IDProcess int NOT NULL,
	LocationCode varchar(8) NOT NULL,
	MaxWorker int NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_MstGenProcessSettingsLocation SET (LOCK_ESCALATION = TABLE)
GO
SET IDENTITY_INSERT dbo.Tmp_MstGenProcessSettingsLocation OFF
GO
IF EXISTS(SELECT * FROM dbo.MstGenProcessSettingsLocation)
	 EXEC('INSERT INTO dbo.Tmp_MstGenProcessSettingsLocation (LocationCode, MaxWorker, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT LocationCode, MaxWorker, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.MstGenProcessSettingsLocation WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE dbo.PlanPlantLineBalancing
	DROP CONSTRAINT FK_PLANPLANTLINEBALANCING_RELATIONSHIP_119_MSTGENPROCESSSETTINGSLOC
GO
DROP TABLE dbo.MstGenProcessSettingsLocation
GO
EXECUTE sp_rename N'dbo.Tmp_MstGenProcessSettingsLocation', N'MstGenProcessSettingsLocation', 'OBJECT' 
GO
ALTER TABLE dbo.MstGenProcessSettingsLocation ADD CONSTRAINT
	PK_MSTGENPROCESSSETTINGSLOCATION PRIMARY KEY CLUSTERED 
	(
	ID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MstGenProcessSettingsLocation WITH NOCHECK ADD CONSTRAINT
	FK_MSTGENPROCESSSETTINGSLOC_RELATIONSHIP_17_MSTGENLOCATION FOREIGN KEY
	(
	LocationCode
	) REFERENCES dbo.MstGenLocation
	(
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE dbo.PlanPlantLineBalancing SET (LOCK_ESCALATION = TABLE)
GO

-- MODIFIER MSTGENPROCESSSETTINGS SCHEME
ALTER TABLE dbo.MstGenProcessSettings
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_40_MSTGENPROCESS
GO
ALTER TABLE dbo.MstGenProcess SET (LOCK_ESCALATION = TABLE)
GO

ALTER TABLE dbo.MstGenProcessSettings
	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_18_MSTGENBRANDGROUP
GO
ALTER TABLE dbo.MstGenBrandGroup SET (LOCK_ESCALATION = TABLE)
GO

CREATE TABLE dbo.Tmp_MstGenProcessSettings
	(
	ID bigint NOT NULL IDENTITY (1, 1),
	IDProcess int NOT NULL,
	BrandGroupCode varchar(20) NULL,
	ProcessGroup varchar(16) NULL,
	StdStickPerHour int NULL,
	MinStickPerHour int NULL,
	UOMEblek int NULL,
	Remark varchar(256) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_MstGenProcessSettings SET (LOCK_ESCALATION = TABLE)
GO
SET IDENTITY_INSERT dbo.Tmp_MstGenProcessSettings OFF
GO
IF EXISTS(SELECT * FROM dbo.MstGenProcessSettings)
	 EXEC('INSERT INTO dbo.Tmp_MstGenProcessSettings (IDProcess, BrandGroupCode, ProcessGroup, StdStickPerHour, MinStickPerHour, UOMEblek, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT IDProcess, BrandGroupCode, ProcessGroup, StdStickPerHour, MinStickPerHour, UOMEblek, Remark, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.MstGenProcessSettings WITH (HOLDLOCK TABLOCKX)')
GO
-- Already Deleted From MstGenProcessSettingsLocation Above
--ALTER TABLE dbo.MstGenProcessSettingsLocation
--	DROP CONSTRAINT FK_MSTGENPROCESSSETTINGSLOC_RELATIONSHIP_16_MSTGENPROCESSSETTINGS
--GO
DROP TABLE dbo.MstGenProcessSettings
GO
EXECUTE sp_rename N'dbo.Tmp_MstGenProcessSettings', N'MstGenProcessSettings', 'OBJECT' 
GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	PK_MstGenProcessSettings PRIMARY KEY NONCLUSTERED 
	(
	ID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	IX_MstGenProcessSettings UNIQUE CLUSTERED 
	(
	IDProcess,
	BrandGroupCode,
	ProcessGroup
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_18_MSTGENBRANDGROUP FOREIGN KEY
	(
	BrandGroupCode
	) REFERENCES dbo.MstGenBrandGroup
	(
	BrandGroupCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.MstGenProcessSettings ADD CONSTRAINT
	FK_MSTGENPROCESSSETTINGS_RELATIONSHIP_40_MSTGENPROCESS FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

ALTER TABLE dbo.MstGenProcessSettingsLocation SET (LOCK_ESCALATION = TABLE)
GO

-- CREATE MSTGENPROCESSSETTINGS MAPPING TABLE
CREATE TABLE dbo.MstGenProcessSettingsMapping
	(
	ProcessSettingsID bigint NOT NULL,
	ProcessSettingsLocationID bigint NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.MstGenProcessSettingsMapping ADD CONSTRAINT
	PK_MstGenProcessSettingsMapping PRIMARY KEY CLUSTERED 
	(
	ProcessSettingsID,
	ProcessSettingsLocationID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MstGenProcessSettingsMapping SET (LOCK_ESCALATION = TABLE)
GO

-- MSTGENPROCESSSETTINGS MAPPING RELATIONSHIP
ALTER TABLE dbo.MstGenProcessSettingsLocation SET (LOCK_ESCALATION = TABLE)
GO

ALTER TABLE dbo.MstGenProcessSettings SET (LOCK_ESCALATION = TABLE)
GO

ALTER TABLE dbo.MstGenProcessSettingsMapping ADD CONSTRAINT
	FK_MstGenProcessSettingsMapping_MstGenProcessSettings FOREIGN KEY
	(
	ProcessSettingsID
	) REFERENCES dbo.MstGenProcessSettings
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.MstGenProcessSettingsMapping ADD CONSTRAINT
	FK_MstGenProcessSettingsMapping_MstGenProcessSettingsLocation FOREIGN KEY
	(
	ProcessSettingsLocationID
	) REFERENCES dbo.MstGenProcessSettingsLocation
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.MstGenProcessSettingsMapping SET (LOCK_ESCALATION = TABLE)
GO


-- ALTERING ALL VIEWS
-- BRANDCODEBYLOCATIONVIEW
ALTER VIEW [dbo].[BrandCodeByLocationView]
AS
SELECT        B.BrandCode, BG.BrandGroupCode, PSL.LocationCode
FROM            dbo.MstGenBrand AS B INNER JOIN
                         dbo.MstGenBrandGroup AS BG ON BG.BrandGroupCode = B.BrandGroupCode INNER JOIN
                         dbo.MstGenProcessSettings AS PS ON PS.BrandGroupCode = BG.BrandGroupCode INNER JOIN
						 dbo.MstGenProcessSettingsMapping PM ON PM.ProcessSettingsID = PS.ID INNER JOIN
                         dbo.MstGenProcessSettingsLocation AS PSL ON PSL.ID = PM.ProcessSettingsLocationID
GROUP BY B.BrandCode, BG.BrandGroupCode, PSL.LocationCode
GO

-- EQUIPMENTREQUIREMENTVIEW
ALTER VIEW [dbo].[EquipmentRequirementView]
AS
SELECT        mgps.BrandGroupCode, mgpsl.LocationCode, mtp.Package
FROM            dbo.MstGenProcessSettingsLocation AS mgpsl INNER JOIN
					dbo.MstGenProcessSettingsMapping AS mpsm ON mpsm.ProcessSettingsLocationID = mgpsl.ID INNER JOIN
                         dbo.MstGenProcessSettings AS mgps ON mgps.ID = mpsm.ProcessSettingsID INNER JOIN
                         dbo.MstGenLocation AS mgl ON mgl.LocationCode = mgpsl.LocationCode INNER JOIN
                         dbo.MstTPOPackage AS mtp ON mtp.BrandGroupCode = mgps.BrandGroupCode AND mtp.LocationCode = mgpsl.LocationCode
WHERE        (mgl.StatusActive = 1)
GROUP BY mgps.BrandGroupCode, mgpsl.LocationCode, mtp.Package
GO

-- EXEPLANTACTUALWORKHOURSVIEW
ALTER VIEW [dbo].[ExePlantActualWorkHoursView]
AS
SELECT     distinct(pu.UnitCode), psl.LocationCode, p.ProcessGroup, p.ProcessOrder, awh.BrandCode, 
awh.StatusIdentifier, awh.ProductionDate, awh.Shift, awh.StatusEmp, awh.TimeIn, 
                      awh.TimeOut, awh.BreakTime
FROM         dbo.MstGenProcessSettingsLocation AS psl INNER JOIN
                      dbo.MstGenProcessSettingsMapping AS psm ON psm.ProcessSettingsLocationID = psl.ID INNER JOIN 
                      dbo.MstGenProcessSettings AS ps ON ps.ID = psm.ProcessSettingsID INNER JOIN
                      dbo.MstGenProcess AS p ON p.ProcessGroup = ps.ProcessGroup INNER JOIN
                      dbo.MstPlantUnit AS pu ON pu.LocationCode = psl.LocationCode LEFT OUTER JOIN
                      dbo.ExeActualWorkHours AS awh ON awh.LocationCode = psl.LocationCode AND awh.UnitCode = pu.UnitCode
WHERE     (p.StatusActive = 1)
GO
