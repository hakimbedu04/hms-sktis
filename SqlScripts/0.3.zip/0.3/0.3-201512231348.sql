--Description   : Create table master tableau reports
--Author  : Oka
--Tiket   : http://192.168.62.216/TargetProcess/entity/1641

DROP TABLE MstTableauReport;

CREATE TABLE MstTableauReport
(
Id INT NOT NULL IDENTITY(1,1),
ReportType VARCHAR(256) NOT NULL,
ReportName VARCHAR(256) NOT NULL,
ReportUrl VARCHAR(256) NOT NULL,
CreatedBy VARCHAR(256) NOT NULL,
CreatedDate DATETIME NOT NULL,
CONSTRAINT PK_MstTableauReport PRIMARY KEY (Id)
);