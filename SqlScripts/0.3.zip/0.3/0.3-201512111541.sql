CREATE FUNCTION GetLocationDependWPP
(	
	  @PLNTorTPO varchar(10)
)
RETURNS  @location table ( LocationCode varchar(8))
AS
BEGIN
	insert into @location
	SELECT      Distinct  wpp.LocationCode
	FROM            PlanTmpWeeklyProductionPlanning AS wpp INNER JOIN
							 MstGenLocation AS L ON wpp.LocationCode = L.LocationCode 
	WHERE L.StatusActive = 1 and wpp.LocationCode in (select LocationCode from dbo.GetLocations(@PLNTorTPO,-1))
	return
END