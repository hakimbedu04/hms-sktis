-- Description: Create WorkerAssignmentRemoval
-- Ticket: http://tp.voxteneo.com/entity/54745
-- Author: Harizal

/****** Object:  Table [dbo].[WorkerAssignmentRemoval]    Script Date: 13/11/2015 15:47:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WorkerAssignmentRemoval](
	[ID] [int] NOT NULL,
	[ProductionEntryCode] [varchar](64) NULL,
	[EmployeeID] [varchar](64) NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
     [DeleteDate] [datetime] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](64) NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
	[UpdatedBy] [varchar](64) NOT NULL,
 CONSTRAINT [PK_WorkerAssignmentRemoval] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


