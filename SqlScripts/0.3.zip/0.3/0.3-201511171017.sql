-- Description: Create ExePlantProductionEntryReport View
-- Ticket: http://tp.voxteneo.com/entity/54564
-- Author: Yudha

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ExePlantProductionEntryReport]
AS
	SELECT '' AS DUMMY    
GO


