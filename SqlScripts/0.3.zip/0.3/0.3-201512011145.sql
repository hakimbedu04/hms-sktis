-- Description: Change table ExeProductionEntryRelease schema
-- Ticket: http://tp.voxteneo.com/entity/59410
-- Author: Oka

-- Drop table ExePlantProductionEntry
DROP TABLE ExeProductionEntryRelease

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExeProductionEntryRelease
(
ProductionEntryCode VARCHAR(64) NOT NULL ,
Remark VARCHAR(256),
IsLocked BIT,
CreatedDate DATETIME NOT NULL,
CreatedBy VARCHAR(64) NOT NULL,
UpdatedDate DATETIME NOT NULL,
UpdatedBy VARCHAR(64) NOT NULL,
CONSTRAINT PK_ExeProductionEntryRelease PRIMARY KEY (ProductionEntryCode),
CONSTRAINT FK_ExeProductionEntryRelease FOREIGN KEY(ProductionEntryCode) REFERENCES ExePlantProductionEntryVerification(ProductionEntryCode)
);



