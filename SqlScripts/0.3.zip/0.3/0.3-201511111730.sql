-- Description: Create combine view between Production Entry and Production Entry Verification
-- Ticket: http://tp.voxteneo.com/entity/57886
-- Author: Whisnu

CREATE VIEW [dbo].[ExeTPOProductionEntryVerificationView]
AS
SELECT        etv.LocationCode, etv.BrandCode, etv.KPSYear, etv.KPSWeek, etv.ProductionDate, etv.ProcessGroup, SUM(et.Absent) AS Absent, SUM(etv.TotalTPKValue) AS TotalTPKValue, SUM(etv.TotalActualValue) 
                         AS TotalActualValue, etv.VerifySystem
FROM            dbo.ExeTPOProduction AS et INNER JOIN
                         dbo.ExeTPOProductionEntryVerification AS etv ON etv.ProductionEntryCode = et.ProductionEntryCode
GROUP BY etv.LocationCode, etv.BrandCode, etv.KPSYear, etv.KPSWeek, etv.ProductionDate, etv.ProcessGroup, etv.VerifySystem

GO