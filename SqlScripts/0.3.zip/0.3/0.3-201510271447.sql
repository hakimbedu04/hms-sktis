-- Description: Update ProductionCard in PlantWages
-- Ticket: story/56093-Update DB based on spec
-- Author: Bagus

GO
ALTER TABLE dbo.ProductionCard
	DROP CONSTRAINT FK_PRODUCTIONCARD_RELATIONSHIP_55_MSTPLANTPRODUCTIONGROUP
GO
ALTER TABLE dbo.MstPlantProductionGroup SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.ProductionCard
	DROP CONSTRAINT FK_PRODUCTIONCARD_RELATIONSHIP_49_MSTGENBRANDGROUP
GO
ALTER TABLE dbo.MstGenBrand SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.ProductionCard
	DROP CONSTRAINT FK_PRODUCTIONCARD_RELATIONSHIP_122_MSTPLANTEMPJOBSDATAALL
GO
ALTER TABLE dbo.MstPlantEmpJobsDataAll SET (LOCK_ESCALATION = TABLE)
GO
GO
CREATE TABLE dbo.Tmp_ProductionCard
	(
	RevisionType int NOT NULL,
	LocationCode varchar(8) NOT NULL,
	UnitCode varchar(4) NOT NULL,
	Shift int NULL,
	BrandCode varchar(11) NOT NULL,
	BrandGroupCode varchar(20) NULL,
	ProcessGroup varchar(16) NOT NULL,
	GroupCode varchar(4) NOT NULL,
	EmployeeID varchar(64) NOT NULL,
	EmployeeNumber varchar(6) NULL,
	Production decimal(5, 0) NULL,
	ProductionDate datetime NOT NULL,
	WorkHours int NULL,
	Absent varchar(6) NULL,
	UpahLain decimal(5, 0) NULL,
	EblekAbsentType varchar(8) NULL,
	Remark varchar(256) NULL,
	Comments varchar(256) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ProductionCard SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ProductionCard)
	 EXEC('INSERT INTO dbo.Tmp_ProductionCard (RevisionType, LocationCode, UnitCode, Shift, BrandCode, ProcessGroup, GroupCode, EmployeeID, EmployeeNumber, Production, ProductionDate, WorkHours, Absent, UpahLain, EblekAbsentType, Remark, Comments, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT RevisionType, LocationCode, UnitCode, Shift, BrandCode, ProcessGroup, GroupCode, EmployeeID, EmployeeNumber, Production, ProductionDate, WorkHours, Absent, UpahLain, EblekAbsentType, Remark, Comments, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ProductionCard WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ProductionCard
GO
EXECUTE sp_rename N'dbo.Tmp_ProductionCard', N'ProductionCard', 'OBJECT' 
GO
ALTER TABLE dbo.ProductionCard ADD CONSTRAINT
	PK_PRODUCTIONCARD PRIMARY KEY NONCLUSTERED 
	(
	ProductionDate,
	RevisionType,
	BrandCode,
	EmployeeID,
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ProductionCard ADD CONSTRAINT
	FK_PRODUCTIONCARD_RELATIONSHIP_122_MSTPLANTEMPJOBSDATAALL FOREIGN KEY
	(
	EmployeeID
	) REFERENCES dbo.MstPlantEmpJobsDataAll
	(
	EmployeeID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ProductionCard ADD CONSTRAINT
	FK_PRODUCTIONCARD_RELATIONSHIP_49_MSTGENBRANDGROUP FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ProductionCard ADD CONSTRAINT
	FK_PRODUCTIONCARD_RELATIONSHIP_55_MSTPLANTPRODUCTIONGROUP FOREIGN KEY
	(
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) REFERENCES dbo.MstPlantProductionGroup
	(
	GroupCode,
	UnitCode,
	LocationCode,
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
