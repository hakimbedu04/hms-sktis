-- Description: Alter [dbo].[ExePlantActualWorkHoursView]
-- Ticket: http://tp.voxteneo.com/entity/61170
-- Author: Yudha

ALTER VIEW [dbo].[ExePlantActualWorkHoursView]
AS
	SELECT DISTINCT 
                         '' AS UnitCode, psl.LocationCode, p.ProcessGroup, p.ProcessOrder, b.BrandCode AS BrandCode, NULL AS StatusIdentifier, 
							 NULL AS ProductionDate, NULL AS Shift, NULL AS StatusEmp, NULL AS TimeIn, NULL 
							 AS TimeOut, NULL AS BreakTime
	FROM            dbo.MstGenProcessSettingsLocation AS psl INNER JOIN
							 dbo.MstGenProcessSettingsMapping AS psm ON psm.ProcessSettingsLocationID = psl.ID INNER JOIN
							 dbo.MstGenProcessSettings AS ps ON ps.ID = psm.ProcessSettingsID INNER JOIN
							 dbo.MstGenProcess AS p ON p.ProcessGroup = ps.ProcessGroup INNER JOIN
							 dbo.MstGenBrand AS b ON b.BrandGroupCode = ps.BrandGroupCode
	WHERE        (p.StatusActive = 1)
GO