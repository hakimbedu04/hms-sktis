-- Description: Change table MstGenMaterial, ExeMaterialUsage schema
-- Ticket: http://tp.voxteneo.com/entity/57142
-- Author: Oka

ALTER TABLE ExeMaterialUsage
DROP CONSTRAINT FK_EXEMATERIALUSAGE_RELATIONSHIP_38_MSTGENMATERIAL

ALTER TABLE MstGenMaterial
DROP CONSTRAINT PK_MSTGENMATERIAL

ALTER TABLE MstGenMaterial
ALTER COLUMN BrandGroupCode VARCHAR(20) NOT NULL

ALTER TABLE MstGenMaterial
ADD CONSTRAINT PK_MSTGENMATERIAL PRIMARY KEY (MaterialCode,BrandGroupCode)

ALTER TABLE ExeMaterialUsage
ADD CONSTRAINT FK_EXEMATERIALUSAGE_RELATIONSHIP_38_MSTGENMATERIAL FOREIGN KEY(MaterialCode, BrandGroupCode)
REFERENCES MstGenMaterial(MaterialCode, BrandGroupCode)

