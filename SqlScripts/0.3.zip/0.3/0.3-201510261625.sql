-- Description: Change Length processsettingcode on employee
-- Author: Bagus
ALTER TABLE MstPlantEmpJobsDataAll ALTER COLUMN ProcessSettingsCode VARCHAR(16)
ALTER TABLE MstPlantEmpJobsDataAcv ALTER COLUMN ProcessSettingsCode VARCHAR(16)
ALTER TABLE MstPlantEmpUpd ALTER COLUMN ProcessSettingsCode VARCHAR(16)
ALTER TABLE MstPlantEmpUpdTmp ALTER COLUMN ProcessSettingsCode VARCHAR(16)