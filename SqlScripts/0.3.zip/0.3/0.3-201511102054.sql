CREATE PROCEDURE [dbo].[SSISGetSwitchBrand]
     @KPSYear int, 
     @KPSWeek int,
     @ConvertMilion int,
     @ProccessName varchar(20),
     @daytype varchar(25),
     @UserName varchar(64)
AS
BEGIN
		SET NOCOUNT ON
		declare @startdate datetime,@enddate datetime,
				@ProcessWorkHours1 int,@ProcessWorkHours2 int,@ProcessWorkHours3 int,@ProcessWorkHours4 int,@ProcessWorkHours5 int,@ProcessWorkHours6 int,@ProcessWorkHours7 int,@TotalWorkHour int
				
				

		DECLARE @RawData TABLE 
				( 
					LocationCode varchar(8),
					UnitCode varchar(4),
					Shift int,
					Register int,
					Absent int,
					BrandGroupCode varchar(20),
					KPSYear int,
					KPSWeek int,
					ProductionStartDate datetime,
					WPP decimal,
					StickPerBox int,
					Holiday1 int,
					Holiday2 int,
					Holiday3 int,
					Holiday4 int,
					Holiday5 int,
					Holiday6 int,
					Holiday7 int,
					Capacity1 decimal(18,2),
					Capacity2 decimal(18,2),
					Capacity3 decimal(18,2),
					Capacity4 decimal(18,2),
					Capacity5 decimal(18,2),
					Capacity6 decimal(18,2),
					Capacity7 decimal(18,2),
					WorkHours1 decimal(18,2),
					WorkHours2 decimal(18,2),
					WorkHours3 decimal(18,2),
					WorkHours4 decimal(18,2),
					WorkHours5 decimal(18,2),
					WorkHours6 decimal(18,2),
					WorkHours7 decimal(18,2),
					production1 decimal(18,2),
					production2 decimal(18,2),
					production3 decimal(18,2),
					production4 decimal(18,2),
					production5 decimal(18,2),
					production6 decimal(18,2),
					production7 decimal(18,2),
					prodtotal1 decimal(18,2),
					prodtotal2 decimal(18,2),
					prodtotal3 decimal(18,2),
					prodtotal4 decimal(18,2),
					prodtotal5 decimal(18,2),
					prodtotal6 decimal(18,2),
					prodtotal7 decimal(18,2)
				 );

		--set @KPSYear = 2015
		--set @KPSWeek = 41
		--set @ProccessName = 'ROLLING'
		--set @daytype = 'Non-Holiday'
		--set @ConvertMilion = 1000000
		--set @UserName = 'pmi\sktis'


		select @startdate = StartDate,@enddate = EndDate from MstGenWeek where Year = @KPSYear and Week = @KPSWeek

		Declare @startdatehistory date Declare @endatehistory date 
		SELECT	@startdatehistory = min(StartDate),@endatehistory = max(enddate) 
		FROM	GetPastWeek(cast(@KPSYear as int),cast(@KPSWeek as int),3) past 
				inner join MstGenWeek week on week.Year = past.year and week.Week = past.week 


		SELECT	@ProcessWorkHours1= MAX(CASE WHEN day = 1 THEN JknHour END), @ProcessWorkHours2= MAX(CASE WHEN day = 2 THEN JknHour END), 
				@ProcessWorkHours3= MAX(CASE WHEN day = 3 THEN JknHour END), @ProcessWorkHours4= MAX(CASE WHEN day = 4 THEN JknHour END), 
				@ProcessWorkHours5= MAX(CASE WHEN day = 5 THEN JknHour END), @ProcessWorkHours6= MAX(CASE WHEN day = 6 THEN JknHour END), 
				@ProcessWorkHours7= MAX(CASE WHEN day = 7 THEN JknHour END), @TotalWorkHour= SUM(JknHour)
		FROM            MstGenStandardHours
		WHERE        (DayType = @daytype)
		GROUP BY DayType

		--------------------------------------------------------- collection row data----------------------------------------------------

		insert into @RawData
		select	unit.*, wpp.BrandGroupCode,wpp.KPSYear,wpp.KPSWeek,wpp.ProductionStartDate,wpp.WPP,wpp.StickPerBox,
				ISNULL(Holiday.Holiday1,0) as Holiday1,
				ISNULL(Holiday.Holiday2,0) as Holiday2,
				ISNULL(Holiday.Holiday3,0) as Holiday3,
				ISNULL(Holiday.Holiday4,0) as Holiday4,
				ISNULL(Holiday.Holiday5,0) as Holiday5,
				ISNULL(Holiday.Holiday6,0) as Holiday6,
				ISNULL(Holiday.Holiday7,0) as Holiday7,
				historical.Capacity1,historical.Capacity2,historical.Capacity3,historical.Capacity4,historical.Capacity5,historical.Capacity6,historical.Capacity7,
				historical.WorkHours1,historical.WorkHours2,historical.WorkHours3,historical.WorkHours4,historical.WorkHours5,historical.WorkHours6,historical.WorkHours7,
				historical.production1,historical.production2,historical.production3,historical.production4,historical.production5,historical.production6,historical.production7,
				historical.prodtotal1,historical.prodtotal2,historical.prodtotal3,historical.prodtotal4,historical.prodtotal5,historical.prodtotal6,historical.prodtotal7
		from
				-----------------------------------------------------------universe unit--------------------------------------------------
				(select	un.LocationCode,
						un.UnitCode,
						ls.shift,
						count(1) as register,
						max(isnull( absn.absncount,0) )as absent
				FROM	MstPlantUnit AS un		
						left outer join MstPlantEmpJobsDataAcv emp on un.LocationCode = emp.LocationCode and un.UnitCode = emp.UnitCode and emp.ProcessSettingsCode = @ProccessName
						LEFT OUTER JOIN (select	emp.UnitCode, count(*) absncount
										from	ExePlantWorkerAbsenteeism  absent
												inner join MstPlantEmpJobsDataAcv emp on absent.EmployeeID = emp.EmployeeID 
										where	emp.ProcessSettingsCode =@ProccessName and ((absent.StartDateAbsent  >= @startdate and  absent.EndDateAbsent <= @enddate ) or (absent.StartDateAbsent  <= @startdate and  absent.EndDateAbsent >= @enddate ))
										group by emp.UnitCode) absn on un.UnitCode = absn.UnitCode
						INNER JOIN GetLocationShift() ls on ls.locationcode = un.LocationCode

				where un.StatusActive = 1 and un.unitcode not in ('MTNC','PROD','WRHS')
				group by un.LocationCode,
						un.unitCode,ls.shift) as unit inner join 

				-----------------------------------------------------------temporary wpp--------------------------------------------------
				(SELECT     MstGenBrandGroup.BrandGroupCode,MAX(genWeek.StartDate) AS ProductionStartDate, MAX(planwpp.KPSYear) AS KPSYear, MAX(planwpp.KPSWeek) AS KPSWeek, planwpp.LocationCode, 
									  cast(SUM(planwpp.Value1) * @ConvertMilion as decimal) as WPP, max(switchbrand.SwitchBrand) as SwitchBrand,
									  max(MstGenBrandGroup.StickPerBox) StickPerBox
				FROM         MstGenBrandGroup INNER JOIN
									  MstGenBrand ON MstGenBrandGroup.BrandGroupCode = MstGenBrand.BrandGroupCode RIGHT OUTER JOIN
									  PlanTmpWeeklyProductionPlanning AS planwpp INNER JOIN
									  MstGenWeek AS genWeek ON genWeek.Week = planwpp.KPSWeek AND genWeek.Year = planwpp.KPSYear ON 
									  MstGenBrand.BrandCode = planwpp.BrandCode
									  inner join
									  (SELECT    WPP.LocationCode, case when COUNT(1) > 1 then 1 else 0 end as SwitchBrand
										FROM         PlanTmpWeeklyProductionPlanning  as wpp INNER JOIN
															  MstGenBrand ON WPP.BrandCode = MstGenBrand.BrandCode                      
										group by WPP.KPSYear, WPP.KPSWeek, WPP.LocationCode, MstGenBrand.BrandGroupCode) as switchbrand on
									  planwpp.LocationCode = switchbrand.LocationCode
				where switchbrand.switchbrand = 1                      
				GROUP BY planwpp.LocationCode,MstGenBrandGroup.BrandGroupCode) as wpp on unit.LocationCode = wpp.LocationCode
				
				left outer join
				-----------------------------------------------------------work hour depend on holiday--------------------------------------------------
				(select	LocationCode, 
						max(case when DATEPART(DW,HolidayDate)=2 then 1 end) Holiday1,
						max(case when DATEPART(DW,HolidayDate)=3 then 1 end) Holiday2,
						max(case when DATEPART(DW,HolidayDate)=4 then 1 end) Holiday3,
						max(case when DATEPART(DW,HolidayDate)=5 then 1 end) Holiday4,
						max(case when DATEPART(DW,HolidayDate)=6 then 1 end) Holiday5,
						max(case when DATEPART(DW,HolidayDate)=7 then 1 end) Holiday6,
						max(case when DATEPART(DW,HolidayDate)=1 then 1 end) Holiday7

				from	MstGenHoliday
				where	HolidayDate >= @startdate and 
						HolidayDate <= @enddate 
						and StatusActive = 1
				group by LocationCode) holiday on unit.LocationCode = holiday.LocationCode
					
				left outer join
				-----------------------------------------------------------Historical--------------------------------------------------
				(select	LocationCode,UnitCode,Shift,
						SUM(case when datepart(dw,ProductionDate) = 2 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity1,
						SUM(case when datepart(dw,ProductionDate) = 3 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity2,
						SUM(case when datepart(dw,ProductionDate) = 4 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity3,
						SUM(case when datepart(dw,ProductionDate) = 5 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity4,
						SUM(case when datepart(dw,ProductionDate) = 6 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity5,
						SUM(case when datepart(dw,ProductionDate) = 7 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity6,
						SUM(case when datepart(dw,ProductionDate) = 1 and processgroup = @ProccessName and production + UpahLain>0  then production + UpahLain else 0 end) AS Capacity7,
						
						SUM(case when datepart(dw,ProductionDate) = 2 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours1,
						SUM(case when datepart(dw,ProductionDate) = 3 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours2,
						SUM(case when datepart(dw,ProductionDate) = 4 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours3,
						SUM(case when datepart(dw,ProductionDate) = 5 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours4,
						SUM(case when datepart(dw,ProductionDate) = 6 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours5,
						SUM(case when datepart(dw,ProductionDate) = 7 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours6,
						SUM(case when datepart(dw,ProductionDate) = 1 and processgroup =  @ProccessName  and production + UpahLain>0 then WorkHours else 0 end) as WorkHours7,
						
						100*SUM(case when datepart(dw,ProductionDate) = 2 and Production + UpahLain > 0 then 1 else 0 end) as production1,
						100*SUM(case when datepart(dw,ProductionDate) = 3 and Production + UpahLain > 0 then 1 else 0 end) as production2,
						100*SUM(case when datepart(dw,ProductionDate) = 4 and Production + UpahLain > 0 then 1 else 0 end) as production3,
						100*SUM(case when datepart(dw,ProductionDate) = 5 and Production + UpahLain > 0 then 1 else 0 end) as production4,
						100*SUM(case when datepart(dw,ProductionDate) = 6 and Production + UpahLain > 0 then 1 else 0 end) as production5,
						100*SUM(case when datepart(dw,ProductionDate) = 7 and Production + UpahLain > 0 then 1 else 0 end) as production6,
						100*SUM(case when datepart(dw,ProductionDate) = 1 and Production + UpahLain > 0 then 1 else 0 end) as production7,
						
						SUM(case when datepart(dw,ProductionDate) = 2 then 1 else 0 end) as prodtotal1,
						SUM(case when datepart(dw,ProductionDate) = 3 then 1 else 0 end) as prodtotal2,
						SUM(case when datepart(dw,ProductionDate) = 4 then 1 else 0 end) as prodtotal3,
						SUM(case when datepart(dw,ProductionDate) = 5 then 1 else 0 end) as prodtotal4,
						SUM(case when datepart(dw,ProductionDate) = 6 then 1 else 0 end) as prodtotal5,
						SUM(case when datepart(dw,ProductionDate) = 7 then 1 else 0 end) as prodtotal6,
						SUM(case when datepart(dw,ProductionDate) = 1 then 1 else 0 end) as prodtotal7 
				from	ProductionCard 
				where	ProductionDate >= @startdatehistory and ProductionDate <= @endatehistory 
				group by LocationCode,UnitCode,Shift) as historical on unit.LocationCode = historical.LocationCode and unit.UnitCode = historical.UnitCode and unit.Shift = historical.Shift


		----------------------------------------------------------- colectiong source data---------------------------------------------------

				DECLARE @DerivedData TABLE 
						( 
							LocationId int,
							LocationCode varchar(8),
							UnitId int,
							UnitCode varchar(4),
							Shift int,
							Register int,
							Absent int,
							BrandGroupCode varchar(20),
							KPSYear int,
							KPSWeek int,
							ProductionStartDate datetime,
							WPP decimal,
							StickPerBox int,
							ProcessWorkHours1 int,
							ProcessWorkHours2 int,
							ProcessWorkHours3 int,
							ProcessWorkHours4 int,
							ProcessWorkHours5 int,
							ProcessWorkHours6 int,
							ProcessWorkHours7 int,
							HistoricalCapacityWorker1 decimal(18,2),
							HistoricalCapacityWorker2 decimal(18,2),
							HistoricalCapacityWorker3 decimal(18,2),
							HistoricalCapacityWorker4 decimal(18,2),
							HistoricalCapacityWorker5 decimal(18,2),
							HistoricalCapacityWorker6 decimal(18,2),
							HistoricalCapacityWorker7 decimal(18,2),
							HistoricalCapacityGroup1 decimal(18,2),
							HistoricalCapacityGroup2 decimal(18,2),
							HistoricalCapacityGroup3 decimal(18,2),
							HistoricalCapacityGroup4 decimal(18,2),
							HistoricalCapacityGroup5 decimal(18,2),
							HistoricalCapacityGroup6 decimal(18,2),
							HistoricalCapacityGroup7 decimal(18,2),
							PercentAttendance1 decimal(18,2),
							PercentAttendance2 decimal(18,2),
							PercentAttendance3 decimal(18,2),
							PercentAttendance4 decimal(18,2),
							PercentAttendance5 decimal(18,2),
							PercentAttendance6 decimal(18,2),
							PercentAttendance7 decimal(18,2)
						 );

				insert into	@DerivedData	
				select	locId.LocationId, rw.LocationCode,unid.UnitId,rw.UnitCode,Shift,Register,Absent,BrandGroupCode,KPSYear,KPSWeek,ProductionStartDate,WPP,StickPerBox,
						case when rw.Holiday1 = 0 then @ProcessWorkHours1 else 0 end as ProcessWorkHours1,
						case when rw.Holiday2 = 0 then @ProcessWorkHours2 else 0 end as ProcessWorkHours2,
						case when rw.Holiday3 = 0 then @ProcessWorkHours3 else 0 end as ProcessWorkHours3,
						case when rw.Holiday4 = 0 then @ProcessWorkHours4 else 0 end as ProcessWorkHours4,
						case when rw.Holiday5 = 0 then @ProcessWorkHours5 else 0 end as ProcessWorkHours5,
						case when rw.Holiday6 = 0 then @ProcessWorkHours6 else 0 end as ProcessWorkHours6,
						case when rw.Holiday7 = 0 then @ProcessWorkHours7 else 0 end as ProcessWorkHours7,
						case when WorkHours1 <> 0 then ROUND(Capacity1/WorkHours1,0) else 0 end as HistoricalCapacityWorker1,
						case when WorkHours2 <> 0 then ROUND(Capacity2/WorkHours2,0) else 0 end as HistoricalCapacityWorker2,
						case when WorkHours3 <> 0 then ROUND(Capacity3/WorkHours3,0) else 0 end as HistoricalCapacityWorker3,
						case when WorkHours4 <> 0 then ROUND(Capacity4/WorkHours4,0) else 0 end as HistoricalCapacityWorker4,
						case when WorkHours5 <> 0 then ROUND(Capacity5/WorkHours5,0) else 0 end as HistoricalCapacityWorker5,
						case when WorkHours6 <> 0 then ROUND(Capacity6/WorkHours6,0) else 0 end as HistoricalCapacityWorker6,
						case when WorkHours7 <> 0 then ROUND(Capacity7/WorkHours7,0) else 0 end as HistoricalCapacityWorker7,
						case when WorkHours1 <> 0 then ROUND((Capacity1/WorkHours1) * (register - absent),0) else 0 end as HistoricalCapacityGroup1,
						case when WorkHours2 <> 0 then ROUND((Capacity2/WorkHours2) * (register - absent),0) else 0 end as HistoricalCapacityGroup2,
						case when WorkHours3 <> 0 then ROUND((Capacity3/WorkHours3) * (register - absent),0) else 0 end as HistoricalCapacityGroup3,
						case when WorkHours4 <> 0 then ROUND((Capacity4/WorkHours4) * (register - absent),0) else 0 end as HistoricalCapacityGroup4,
						case when WorkHours5 <> 0 then ROUND((Capacity5/WorkHours5) * (register - absent),0) else 0 end as HistoricalCapacityGroup5,
						case when WorkHours6 <> 0 then ROUND((Capacity6/WorkHours6) * (register - absent),0) else 0 end as HistoricalCapacityGroup6,
						case when WorkHours7 <> 0 then ROUND((Capacity7/WorkHours7) * (register - absent),0) else 0 end as HistoricalCapacityGroup7,
						case when prodtotal1 <> 0 then ROUND(production1/prodtotal1,0) else 0 end as PercentAttendance1,
						case when prodtotal2 <> 0 then ROUND(production2/prodtotal2,0) else 0 end as PercentAttendance2,
						case when prodtotal3 <> 0 then ROUND(production3/prodtotal3,0) else 0 end as PercentAttendance3,
						case when prodtotal4 <> 0 then ROUND(production4/prodtotal4,0) else 0 end as PercentAttendance4,
						case when prodtotal5 <> 0 then ROUND(production5/prodtotal5,0) else 0 end as PercentAttendance5,
						case when prodtotal6 <> 0 then ROUND(production6/prodtotal6,0) else 0 end as PercentAttendance6,
						case when prodtotal7 <> 0 then ROUND(production7/prodtotal7,0) else 0 end as PercentAttendance7
				from	@RawData as rw

				left outer join
				(select	ROW_NUMBER() OVER(PARTITION BY LocationCode ORDER BY LocationCode) AS LocationId,
						locationcode
				from	@RawData
				group by locationcode) as locId  on  rw.LocationCode = locId.LocationCode

				left outer join
				(select	ROW_NUMBER() OVER(PARTITION BY locationcode ORDER BY unitcode) AS UnitId,
						locationcode,unitcode
				from	@RawData
				group by locationcode,unitcode) as UnId on rw.UnitCode = UnId.UnitCode and rw.LocationCode = unid.LocationCode

				DECLARE @TargetData TABLE 
						( 
							LocationId int,
							LocationCode varchar(8),
							BrandGroupCode varchar(20),
							UnitId int,
							UnitCode varchar(4),
							Shift int,
							BrandId int,
							BrandCode  varchar(11),
							WPP int,
							TargetSystem1 int,
							TargetSystem2 int,
							TargetSystem3 int,
							TargetSystem4 int,
							TargetSystem5 int,
							TargetSystem6 int,
							TargetSystem7 int,			
							NewTargetSystem1 int,
							NewTargetSystem2 int,
							NewTargetSystem3 int,
							NewTargetSystem4 int,
							NewTargetSystem5 int,
							NewTargetSystem6 int,
							NewTargetSystem7 int			
					);

				insert into @TargetData
				select targetperday.locationId,targetperday.LocationCode,targetperday.BrandGroupCode,UnitId,UnitCode,Shift,brand.BrandId,pln.BrandCode,
					   case when StickPerBox <> 0 then round((pln.Value1 * @ConvertMilion)/ StickPerBox,0) else 0 end AS wpp,
					   case when StickPerBox <> 0 then round(((targetperday.target1/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem1,
					   case when StickPerBox <> 0 then round(((targetperday.target2/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem2,
					   case when StickPerBox <> 0 then round(((targetperday.target3/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem3,
					   case when StickPerBox <> 0 then round(((targetperday.target4/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem4,
					   case when StickPerBox <> 0 then round(((targetperday.target5/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem5,
					   case when StickPerBox <> 0 then round(((targetperday.target6/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem6,
					   case when StickPerBox <> 0 then round(((targetperday.target7/totaltarget)* wpp)/StickPerBox,0) else 0 end as TargetSystem7,
					   0,0,0,0,0,0,0
				from
				(select LocationId,LocationCode,BrandGroupCode,UnitId,UnitCode,Shift,WPP,StickPerBox,
					   cast((HistoricalCapacityGroup1 * PercentAttendance1 * ProcessWorkHours1)as decimal(18,2)) as target1,
					   cast((HistoricalCapacityGroup2 * PercentAttendance2 * ProcessWorkHours2)as decimal(18,2)) as target2,
					   cast((HistoricalCapacityGroup3 * PercentAttendance3 * ProcessWorkHours3)as decimal(18,2)) as target3,
					   cast((HistoricalCapacityGroup4 * PercentAttendance4 * ProcessWorkHours4)as decimal(18,2)) as target4,
					   cast((HistoricalCapacityGroup5 * PercentAttendance5 * ProcessWorkHours5)as decimal(18,2)) as target5,
					   cast((HistoricalCapacityGroup6 * PercentAttendance6 * ProcessWorkHours6)as decimal(18,2)) as target6,
					   cast((HistoricalCapacityGroup7 * PercentAttendance7 * ProcessWorkHours7)as decimal(18,2)) as target7
				from @DerivedData ) as targetperday inner join

				(select LocationCode,BrandGroupCode,
					   sum(HistoricalCapacityGroup1 * PercentAttendance1 * ProcessWorkHours1) +
					   sum(HistoricalCapacityGroup2 * PercentAttendance2 * ProcessWorkHours2) +
					   sum(HistoricalCapacityGroup3 * PercentAttendance3 * ProcessWorkHours3) +
					   sum(HistoricalCapacityGroup4 * PercentAttendance4 * ProcessWorkHours4) +
					   sum(HistoricalCapacityGroup5 * PercentAttendance5 * ProcessWorkHours5) +
					   sum(HistoricalCapacityGroup6 * PercentAttendance6 * ProcessWorkHours6) +
					   sum(HistoricalCapacityGroup7 * PercentAttendance7 * ProcessWorkHours7) as TotalTarget
				from @DerivedData
				group by LocationCode,BrandGroupCode
				) totaltarget on targetperday.LocationCode = totaltarget.LocationCode and targetperday.BrandGroupCode = totaltarget.BrandGroupCode
				inner join 
				PlanTmpWeeklyProductionPlanning AS pln on pln.LocationCode = targetperday.LocationCode 
				
				left outer join
				(select ROW_NUMBER() OVER(ORDER BY BrandCode) AS BrandId, BrandCode from
					PlanTmpWeeklyProductionPlanning
						group by BrandCode)as brand 
				on pln.BrandCode = brand.BrandCode

				
						

		declare @currentlocation int, @currentunit int,@currentbrand int,@maxlocation int, @maxunit int,@maxbrand int, 
				@currentwwp decimal(18,2),@currenttarget decimal(18,2),
				@currentcapacity decimal(18,2),@Target7 decimal(18,2)

		select @maxlocation = MAX(LocationID), @maxunit = MAX(unitid), @maxbrand  = max(BrandId) from @TargetData

		set @currentlocation = 1
		set @currenttarget = 0

		WHILE @currentlocation <= @maxlocation
		BEGIN
			set @currentbrand = 1
			WHILE @currentbrand <= @maxbrand
			BEGIN
				
				select @currentwwp = MAX(wpp) from @TargetData where LocationId = @currentlocation and BrandId = @currentbrand
				
				--------------------day 1
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN
					select @currenttarget = MAX(TargetSystem1), @currentcapacity = MAX(NewTargetSystem1) from @TargetData where Locationid = @currentlocation and Unitid = @currentunit
					
					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem1 = case when  @currentwwp > TargetSystem1 then TargetSystem1 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
					
					set @currentunit = @currentunit + 1
				END
				
				--------------------day 2
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN
					select @currenttarget = MAX(TargetSystem2), @currentcapacity = MAX(NewTargetSystem2) from @TargetData where Locationid = @currentlocation and Unitid = @currentunit
					
					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem2 = case when  @currentwwp > TargetSystem2 then TargetSystem2 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
								
					set @currentunit = @currentunit + 1
				END
				
				--------------------day 3
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN		
					select @currenttarget = MAX(TargetSystem3), @currentcapacity = MAX(NewTargetSystem3) from @TargetData where Locationid = @currentlocation and Unitid = @currentunit

					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem3 = case when  @currentwwp > TargetSystem3 then TargetSystem3 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
					
					set @currentunit = @currentunit + 1
				END
				
				--------------------day 4
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN		
					select @currenttarget = MAX(TargetSystem4), @currentcapacity = MAX(NewTargetSystem4) from @TargetData where Locationid = @currentlocation and Unitid = @currentunit
					
					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem4 = case when  @currentwwp > TargetSystem4 then TargetSystem4 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
					
					set @currentunit = @currentunit + 1
				END
					
				--------------------day 5
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN		
					select @currenttarget = MAX(TargetSystem5), @currentcapacity = MAX(NewTargetSystem5) from @TargetData where Locationid = @currentlocation and Unitid = @currentunit
					
					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem5 = case when  @currentwwp > TargetSystem5 then TargetSystem5 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
					
					set @currentunit = @currentunit + 1
				END
				
				--------------------day 6
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN		
					select @Target7= MAX(TargetSystem7),@currenttarget = MAX(TargetSystem6), @currentcapacity = MAX(NewTargetSystem6)
					from @TargetData where Locationid = @currentlocation and Unitid = @currentunit
					
					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem6 = case when  @currentwwp > TargetSystem6 then TargetSystem6 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
					
					
					if (@currentwwp > 0 and @currentunit = @maxunit and @Target7 = 0)
					BEGIN
						update @TargetData set NewTargetSystem6 = TargetSystem6 + @currentwwp
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit	
						set @currentwwp = 0		
					END
					set @currentunit = @currentunit + 1
				END
				
				--------------------day 7
				set @currentunit = 1
				WHILE @currentunit <= @maxunit
				BEGIN		
					select @currenttarget = MAX(TargetSystem7), @currentcapacity = MAX(NewTargetSystem7)
					from @TargetData where Locationid = @currentlocation and Unitid = @currentunit
					if (@currentwwp > 0 ) or @currenttarget <> @currentcapacity
					begin		
						if @currentwwp <= 0 set @currentwwp = 0
									
						update @TargetData set NewTargetSystem7 = case when  @currentwwp > TargetSystem7 then TargetSystem7 - @currentcapacity else @currentwwp end
						where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit
						set @currentwwp = @currentwwp - @currenttarget + @currentcapacity
					end
					
					
					if (@currentwwp > 0 and @currentunit = @maxunit)
					update @TargetData set NewTargetSystem7 = TargetSystem7 + @currentwwp
					where LocationId = @currentlocation and BrandId = @currentbrand and UnitId =@currentunit			
					set @currentunit = @currentunit + 1
				END
				
				set @currentbrand = @currentbrand + 1
			end

			set @currentlocation = @currentlocation + 1
		END

		select drvd.ProductionStartDate,drvd.KPSYear,drvd.KPSWeek,trgt.BrandCode,trgt.LocationCode,trgt.unitcode,trgt.Shift,
			   'TPU/' + trgt.LocationCode + '/' + trgt.BrandCode +'/' + cast(drvd.KPSYear as varchar) + '/' + cast(drvd.KPSWeek as varchar) as TPUCode,
			   drvd.Register as WorkerRegister, drvd.Register - drvd.Absent as WorkerAvailable, drvd.Register - drvd.Absent as WorkerAlocation,
			   PercentAttendance1,PercentAttendance2,PercentAttendance3,PercentAttendance4,PercentAttendance5,PercentAttendance6,PercentAttendance7,
			   HistoricalCapacityWorker1,HistoricalCapacityWorker2,HistoricalCapacityWorker3,HistoricalCapacityWorker4,HistoricalCapacityWorker5,HistoricalCapacityWorker6,HistoricalCapacityWorker7,
			   HistoricalCapacityGroup1,HistoricalCapacityGroup2,HistoricalCapacityGroup3,HistoricalCapacityGroup4,HistoricalCapacityGroup5,HistoricalCapacityGroup6,HistoricalCapacityGroup7,
			   NewTargetSystem1 as TargetSystem1,NewTargetSystem2 as TargetSystem2,NewTargetSystem3 as TargetSystem3,NewTargetSystem4 as TargetSystem4,NewTargetSystem5 as TargetSystem5,NewTargetSystem6 as TargetSystem6,NewTargetSystem7 as TargetSystem7,
			   NewTargetSystem1 as TargetManual1,NewTargetSystem2 as TargetManual2,NewTargetSystem3 as TargetManual3,NewTargetSystem4 as TargetManual4,NewTargetSystem5 as TargetManual5,NewTargetSystem6 as TargetManual6,NewTargetSystem7 as TargetManual7,
			   ProcessWorkHours1,ProcessWorkHours2,ProcessWorkHours3,ProcessWorkHours4,ProcessWorkHours5,ProcessWorkHours6,ProcessWorkHours7,
			   ProcessWorkHours1 + ProcessWorkHours2+ProcessWorkHours3+ProcessWorkHours4+ProcessWorkHours5+ProcessWorkHours6+ProcessWorkHours7 as TotalWorkhours,
			   NewTargetSystem1+NewTargetSystem2+NewTargetSystem3+NewTargetSystem4+NewTargetSystem5+NewTargetSystem6+NewTargetSystem7 as TotalTargetSystem,
			   NewTargetSystem1+NewTargetSystem2+NewTargetSystem3+NewTargetSystem4+NewTargetSystem5+NewTargetSystem6+NewTargetSystem7 as TotalTargetManual,
			   GETDATE() as CreatedDate, @UserName + ' - System' as CreatedBy,
			   GETDATE() as UpdatedDate, @UserName + ' - System' as UpdatedBy	   
			   
		from @TargetData trgt inner join @DerivedData drvd on trgt.LocationCode = drvd.LocationCode and trgt.UnitCode = drvd.UnitCode and trgt.Shift = drvd.Shift
END
GO


