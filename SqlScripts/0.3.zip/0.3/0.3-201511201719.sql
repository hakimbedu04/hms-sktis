ALTER TABLE [dbo].[TPOFeeCalculation] DROP CONSTRAINT [PK_TPOFeeCalculation_1]
GO
ALTER TABLE dbo.TPOFeeCalculation ALTER COLUMN ProductionFeeType varchar ( 64) NOT NULL
/****** Object:  Index [PK_TPOFeeCalculation_1]    Script Date: 11/20/2015 5:26:28 PM ******/
ALTER TABLE [dbo].[TPOFeeCalculation] ADD  CONSTRAINT [PK_TPOFeeCalculation_1] PRIMARY KEY CLUSTERED 
(
	[TPOFeeCode] ASC,
	[ProductionFeeType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[TPOFeeCalculationPlan] DROP CONSTRAINT [PK_TPOFeeCalculationPlan_1]
GO
ALTER TABLE dbo.TPOFeeCalculationPlan ALTER COLUMN ProductionFeeType varchar ( 64) NOT NULL
/****** Object:  Index [PK_TPOFeeCalculationPlan_1]    Script Date: 11/20/2015 5:28:02 PM ******/
ALTER TABLE [dbo].[TPOFeeCalculationPlan] ADD  CONSTRAINT [PK_TPOFeeCalculationPlan_1] PRIMARY KEY CLUSTERED 
(
	[TPOFeeCode] ASC,
	[ProductionFeeType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JKNJam float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL1Jam float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL2Jam float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL3Jam float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL4Jam float 
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JKN float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL1 float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL2 float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL3 float
ALTER TABLE dbo.TPOFeeProductionDaily ALTER COLUMN JL4 float
ALTER TABLE dbo.TPOFeeProductionDailyPlan ALTER COLUMN JKN float
ALTER TABLE dbo.TPOFeeProductionDailyPlan ALTER COLUMN JL1 float
ALTER TABLE dbo.TPOFeeProductionDailyPlan ALTER COLUMN JL2 float
ALTER TABLE dbo.TPOFeeProductionDailyPlan ALTER COLUMN JL3 float
ALTER TABLE dbo.TPOFeeProductionDailyPlan ALTER COLUMN JL4 float 