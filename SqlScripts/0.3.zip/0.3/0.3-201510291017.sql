-- Description: Create table report for Production Execution
-- Ticket: task/56868-Report Production Execution - Exe Report by Process
-- Author: Bagus
CREATE TABLE [dbo].[ExeReportByProcess](
	[LocationCode] [varchar](8) NOT NULL,
	[UnitCode] [varchar](4) NOT NULL,
	[BrandCode] [varchar](11) NOT NULL,
	[KPSYear] [int] NOT NULL,
	[KPSWeek] [int] NOT NULL,
	[ProductionDate] [datetime] NOT NULL,
	[ProcessGroup] [varchar](16) NOT NULL,
	[ProcessOrder] [int] NOT NULL,
	[Shift] [int] NOT NULL,
	[Description] [varchar](64) NOT NULL,
	[UOM] [varchar](11) NOT NULL,
	[UOMOrder] [int] NOT NULL,
	[Production] [float] NOT NULL,
	[KeluarBersih] [float] NOT NULL,
	[RejectSample] [float] NOT NULL,
	[BeginningStock] [float] NOT NULL,
	[EndingStock] [float] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](64) NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
	[UpdatedBy] [varchar](64) NOT NULL,
 CONSTRAINT [PK_ExeReportByProcess] PRIMARY KEY CLUSTERED 
(
	[LocationCode] ASC,
	[UnitCode] ASC,
	[BrandCode] ASC,
	[ProductionDate] ASC,
	[ProcessOrder] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[ExeReportByProcess]  WITH CHECK ADD  CONSTRAINT [FK_ExeReportByProcess_MstGenBrand] FOREIGN KEY([BrandCode])
REFERENCES [dbo].[MstGenBrand] ([BrandCode])
GO

ALTER TABLE [dbo].[ExeReportByProcess] CHECK CONSTRAINT [FK_ExeReportByProcess_MstGenBrand]
GO

ALTER TABLE [dbo].[ExeReportByProcess]  WITH CHECK ADD  CONSTRAINT [FK_ExeReportByProcess_MstGenProcess] FOREIGN KEY([ProcessGroup])
REFERENCES [dbo].[MstGenProcess] ([ProcessGroup])
GO

ALTER TABLE [dbo].[ExeReportByProcess] CHECK CONSTRAINT [FK_ExeReportByProcess_MstGenProcess]
GO

ALTER TABLE [dbo].[ExeReportByProcess]  WITH CHECK ADD  CONSTRAINT [FK_ExeReportByProcess_MstPlantUnit] FOREIGN KEY([UnitCode], [LocationCode])
REFERENCES [dbo].[MstPlantUnit] ([UnitCode], [LocationCode])
GO

ALTER TABLE [dbo].[ExeReportByProcess] CHECK CONSTRAINT [FK_ExeReportByProcess_MstPlantUnit]
GO
