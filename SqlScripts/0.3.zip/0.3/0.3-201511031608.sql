-- Description: Change table ExePlantProductionEntryVerification schema
-- Ticket: http://tp.voxteneo.com/entity/57300
-- Author: Oka

-- Drop table ExePlantProductionEntryVerification
DROP TABLE ExePlantProductionEntryVerification

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExePlantProductionEntryVerification
(
ProductionEntryCode VARCHAR(64) NOT NULL,
LocationCode VARCHAR(64) NOT NULL UNIQUE,
UnitCode VARCHAR(64) NOT NULL UNIQUE,
Shift INTEGER NOT NULL UNIQUE,
ProcessGroup VARCHAR(16) NOT NULL UNIQUE,
ProcessOrder INTEGER NOT NULL UNIQUE,
GroupCode VARCHAR(20) UNIQUE,
BrandCode VARCHAR(11) NOT NULL UNIQUE,
KPSYear INTEGER NOT NULL UNIQUE,
KPSWeek INTEGER NOT NULL UNIQUE,
ProductionDate DATETIME NOT NULL UNIQUE,
WorkHour INTEGER NOT NULL,
TPKValue INTEGER,
TotalTargetValue INTEGER,
TotalActualValue INTEGER,
TotalCapacityValue INTEGER,
VerifySystem BIT,
VerifyManual BIT,
Remark VARCHAR(256),
CreatedDate DATETIME,
CreatedBy VARCHAR(64),
UpdatedDate DATETIME,
UpdatedBy VARCHAR(64),
CONSTRAINT PK_ExePlantProductionEntryVerification PRIMARY KEY (ProductionEntryCode)
);



