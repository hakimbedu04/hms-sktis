-- Description: ALTER VIEW
-- Ticket: http://tp.voxteneo.com/entity/59012
-- Author: Yudha

ALTER VIEW dbo.EquipmentRequestView
AS
SELECT        RequestDate, ItemCode, ItemDescription, ReadyToUse, OnUse, OnRepair, TotalQty, ApprovedQty, LocationCode, RequestNumber, UpdatedBy
FROM            (SELECT        ER.RequestDate, ER.ItemCode, MI.ItemDescription, tblInventoriReadyToUse.EndingStock AS ReadyToUse, tblInventoriOnUse.EndingStock AS OnUse, tblInventoriOnRepair.EndingStock AS OnRepair, ER.Qty AS TotalQty, ER.ApprovedQty, ER.LocationCode, ER.RequestNumber, ER.UpdatedBy
				  FROM            MntcEquipmentRequest AS ER INNER JOIN
											MstMntcItem AS MI ON MI.ItemCode = ER.ItemCode CROSS APPLY
					 (SELECT        TOP (1) InventoryDate, ItemStatus, ItemCode, LocationCode, UnitCode, BeginningStock, StockIn, StockOut, EndingStock
					   FROM            dbo.MntcInventoryAll
					   WHERE        ItemStatus = 'Ready to Use' AND ItemCode = ER.ItemCode AND LocationCode = ER.LocationCode
					   ORDER BY InventoryDate DESC) AS tblInventoriReadyToUse CROSS APPLY
					 (SELECT        TOP (1) InventoryDate, ItemStatus, ItemCode, LocationCode, UnitCode, BeginningStock, StockIn, StockOut, EndingStock
					   FROM            dbo.MntcInventoryAll
					   WHERE        ItemStatus = 'On Used' AND ItemCode = ER.ItemCode AND LocationCode = ER.LocationCode
					   ORDER BY InventoryDate DESC) AS tblInventoriOnUse CROSS APPLY
					 (SELECT        TOP (1) InventoryDate, ItemStatus, ItemCode, LocationCode, UnitCode, BeginningStock, StockIn, StockOut, EndingStock
					   FROM            dbo.MntcInventoryAll
					   WHERE        ItemStatus = 'On Repair' AND ItemCode = ER.ItemCode AND LocationCode = ER.LocationCode
					   ORDER BY InventoryDate DESC) AS tblInventoriOnRepair) AS EquipmentRequestView;
GO