-- Description: Change table ExePlantProductionEntry, ExePlantProductionEntryVerification schema
-- Ticket: --
-- Author: Oka

-- Drop table ExePlantProductionEntry
DROP TABLE ExePlantProductionEntry

-- Drop table ExePlantProductionEntryVerification
DROP TABLE ExePlantProductionEntryVerification

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExePlantProductionEntryVerification
(
ProductionEntryCode VARCHAR(64) NOT NULL,
LocationCode VARCHAR(64) NOT NULL,
UnitCode VARCHAR(64) NOT NULL,
Shift INTEGER NOT NULL,
ProcessGroup VARCHAR(16) NOT NULL,
ProcessOrder INTEGER NOT NULL,
GroupCode VARCHAR(20),
BrandCode VARCHAR(11) NOT NULL,
KPSYear INTEGER NOT NULL,
KPSWeek INTEGER NOT NULL,
ProductionDate DATETIME NOT NULL,
WorkHour INTEGER NOT NULL,
TPKValue INTEGER,
TotalTargetValue INTEGER,
TotalActualValue INTEGER,
TotalCapacityValue INTEGER,
VerifySystem BIT,
VerifyManual BIT,
Remark VARCHAR(256),
CreatedDate DATETIME,
CreatedBy VARCHAR(64),
UpdatedDate DATETIME,
UpdatedBy VARCHAR(64),
CONSTRAINT PK_ExePlantProductionEntryVerification PRIMARY KEY (ProductionEntryCode),
CONSTRAINT UQ_ExePlantProductionEntryVerification UNIQUE (LocationCode, UnitCode, Shift, ProcessGroup, ProcessOrder, GroupCode, BrandCode, KPSYear, KPSWeek, ProductionDate)
);

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExePlantProductionEntry
(
ProductionEntryCode VARCHAR(64) NOT NULL ,
EmployeeID VARCHAR(64) NOT NULL,
EmployeeNumber VARCHAR(11),
StatusEmp VARCHAR(64) NOT NULL,
StatusIdentifier INTEGER NOT NULL,
StartDateAbsent DATETIME,
AbsentType VARCHAR(128),
ProdCapacity INTEGER,
ProdTarget INTEGER,
ProdActual INTEGER,
AbsentRemark VARCHAR(8),
AbsentCodeEblek VARCHAR(128),
AbsentCodePayroll VARCHAR(128),
CreatedDate DATETIME NOT NULL,
CreatedBy VARCHAR(64) NOT NULL,
UpdatedDate DATETIME NOT NULL,
UpdatedBy VARCHAR(64) NOT NULL,
CONSTRAINT PK_ExePlantProductionEntry PRIMARY KEY (ProductionEntryCode, EmployeeID),
CONSTRAINT FK_ExePlantProductionEntry_MstPlantAbsentType FOREIGN KEY(AbsentType) REFERENCES MstPlantAbsentType(AbsentType),
CONSTRAINT FK_ExePlantProductionEntry_MstPlantEmpJobsDataAll FOREIGN KEY(EmployeeID) REFERENCES MstPlantEmpJobsDataAll(EmployeeID),
CONSTRAINT FK_ExePlantProductionEntry_ExePlantProductionEntryVerification FOREIGN KEY(ProductionEntryCode) REFERENCES ExePlantProductionEntryVerification(ProductionEntryCode)
);



