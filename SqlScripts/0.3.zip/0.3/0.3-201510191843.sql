-- Description: Create tabel MstClosingPayroll
-- Ticket: http://tp.voxteneo.com/entity/54555 | Task#54555 View
-- Author: Harizal Hilmi

CREATE TABLE [dbo].[MstClosingPayroll](
	[ClosingDate] [datetime] NOT NULL,
 CONSTRAINT [PK_MstClosingPayroll] PRIMARY KEY CLUSTERED 
(
	[ClosingDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]