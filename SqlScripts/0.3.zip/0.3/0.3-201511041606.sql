-- Description: Create ExeReportByGroupsMonthly
-- Ticket: story/56093-Update DB based on spec
-- Author: Bagus
CREATE TABLE [dbo].[ExeReportByGroupsMonthly](
	[LocationCode] [varchar](8) NOT NULL,
	[UnitCode] [varchar](4) NOT NULL,
	[ProcessGroup] [varchar](16) NOT NULL,
	[GroupCode] [varchar](4) NOT NULL,
	[BrandGroupCode] [varchar](20) NOT NULL,
	[BrandCode] [varchar](11) NOT NULL,
	[StatusEmp] [varchar](16) NOT NULL,
	[Month] [int] NOT NULL,
	[Year] [int] NOT NULL,
	[Shift] [int] NOT NULL,
	[Production] [int] NULL,
	[TPKValue] [real] NULL,
	[WorkHour] [int] NULL,
	[WeekDay] [int] NOT NULL,
	[Register] [int] NOT NULL,
	[Absennce_A] [float] NULL,
	[Absence_I] [float] NULL,
	[Absence_C] [float] NULL,
	[Absence_CH] [float] NULL,
	[Absence_CT] [float] NULL,
	[Absence_SLS] [float] NULL,
	[Absence_SLP] [float] NULL,
	[Absence_ETC] [float] NULL,
	[Multi_TPO] [int] NULL,
	[Multi_ROLL] [int] NULL,
	[Multi_CUTT] [int] NULL,
	[Multi_PACK] [int] NULL,
	[Multi_STAMP] [int] NULL,
	[Multi_FWRP] [int] NULL,
	[Multi_SWRP] [int] NULL,
	[Multi_GEN] [int] NULL,
	[Multi_WRP] [int] NULL,
	[Out] [int] NULL,
	[Attend] [int] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](64) NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
	[UpdatedBy] [varchar](64) NOT NULL,
 CONSTRAINT [PK_ExeReportByGroupsMonthly] PRIMARY KEY CLUSTERED 
(
	[LocationCode] ASC,
	[GroupCode] ASC,
	[BrandCode] ASC,
	[Month] ASC,
	[Year] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[ExeReportByGroupsMonthly]  WITH CHECK ADD  CONSTRAINT [FK_ExeReportByGroupsMonthly_MstGenBrand] FOREIGN KEY([BrandCode])
REFERENCES [dbo].[MstGenBrand] ([BrandCode])
GO

ALTER TABLE [dbo].[ExeReportByGroupsMonthly] CHECK CONSTRAINT [FK_ExeReportByGroupsMonthly_MstGenBrand]
GO

ALTER TABLE [dbo].[ExeReportByGroupsMonthly]  WITH CHECK ADD  CONSTRAINT [FK_ExeReportByGroupsMonthly_MstGenProcess] FOREIGN KEY([ProcessGroup])
REFERENCES [dbo].[MstGenProcess] ([ProcessGroup])
GO

ALTER TABLE [dbo].[ExeReportByGroupsMonthly] CHECK CONSTRAINT [FK_ExeReportByGroupsMonthly_MstGenProcess]
GO

ALTER TABLE [dbo].[ExeReportByGroupsMonthly]  WITH CHECK ADD  CONSTRAINT [FK_ExeReportByGroupsMonthly_MstPlantUnit] FOREIGN KEY([UnitCode], [LocationCode])
REFERENCES [dbo].[MstPlantUnit] ([UnitCode], [LocationCode])
GO

ALTER TABLE [dbo].[ExeReportByGroupsMonthly] CHECK CONSTRAINT [FK_ExeReportByGroupsMonthly_MstPlantUnit]
GO
