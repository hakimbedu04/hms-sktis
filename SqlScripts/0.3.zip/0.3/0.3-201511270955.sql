-- Description: Generating Production Entry Verification Report
-- Ticket: http://tp.voxteneo.com/entity/57888
-- Author: Whisnu Sucitanuary
-- Version: 1.1
-- Changes: Fix calculation for OutputBiaya

ALTER PROCEDURE [dbo].[TPOProductionEntryVerificationGenerateReport]
	@LocationCode varchar(8),
	@BrandCode varchar(11),
	@KPSYear int,
	@KPSWeek int,
	@ProductionDate date	
AS
BEGIN
	SET NOCOUNT ON;
	-- GLOBAL VARIABLE
	DECLARE @TPOFeeCode varchar(64)
	DECLARE @StickPerBox int

	-- GLOBAL DATA
	-- Master General Brand Group	
	DECLARE @BrandGroupCode varchar(20)
	SELECT
		@BrandGroupCode = bg.BrandGroupCode,
		@StickPerBox = bg.StickPerBox
	FROM MstGenBrandGroup bg
	INNER JOIN MstGenBrand b on b.BrandGroupCode = bg.BrandGroupCode 
	WHERE b.BrandCode = @BrandCode

	SET @TPOFeeCode = 'FEE/' + @LocationCode + '/' + @BrandGroupCode + '/' + CAST(@KPSYear AS varchar) + '/' + CAST(@KPSWeek AS varchar)

	-- Check TPO Fee Header
	DECLARE @TPOFeeHdrExist INT
	SELECT @TPOFeeHdrExist = COUNT(*) FROM TPOFeeHdr
	WHERE KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND BrandCode = @BrandCode AND LocationCode = @LocationCode

	IF @TPOFeeHdrExist <= 0
	BEGIN
	
		-- Master TPO Info
		DECLARE @PengirimanL1 varchar(64)
		DECLARE @PengirimanL2 varchar(64)
		DECLARE @PengirimanL3 varchar(64)
		DECLARE @PengirimanL4 varchar(64)
		SELECT 
			@PengirimanL1 = VendorName, 
			@PengirimanL2 = BankAccountNumber, 
			@PengirimanL3 = BankType, 
			@PengirimanL4 = BankBranch 
		FROM MstTPOInfo WHERE LocationCode = @LocationCode	

		-- Master TPO Package
		DECLARE @TPOPackageValue real
		SELECT
			@TPOPackageValue = Package
		FROM MstTPOPackage
		WHERE LocationCode = @LocationCode AND BrandGroupCode = @BrandGroupCode AND EffectiveDate = @ProductionDate

		-- Insert TPO Fee Header
		INSERT INTO TPOFeeHdr(
			KPSYear,
			KPSWeek,
			BrandGroupCode,
			BrandCode,
			LocationCode,
			CurrentApproval,
			CreatedDate,
			CreatedBy,
			UpdatedDate,
			UpdatedBy,
			TPOFeeCode,
			Status,
			PengirimanL1,
			PengirimanL2,
			PengirimanL3,
			PengirimanL4,
			StickPerBox,
			TPOPackageValue
		)
		SELECT 
			@KPSYear,
			@KPSWeek,
			@BrandGroupCode,
			@BrandCode,
			@LocationCode,
			'PMI/User',
			GETDATE(),
			'PMI/User',
			GETDATE(),
			'PMI/User',
			@TPOFeeCode,
			'DRAFT',
			@PengirimanL1,
			@PengirimanL2,
			@PengirimanL3,
			@PengirimanL4,
			@StickPerBox,
			@TPOPackageValue
	END

	-- Check TPO Fee Production Dialy
	DECLARE @TPOFeeProductionDailyExist INT
	SELECT @TPOFeeProductionDailyExist = COUNT(*) FROM TPOFeeProductionDaily
	WHERE TPOFeeCode = @TPOFeeCode AND FeeDate = @ProductionDate AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek

	IF @TPOFeeProductionDailyExist <= 0 
	BEGIN
		
		--DECLARE @LocationCode varchar(8) = 'IDAA'
		--DECLARE @BrandCode varchar(11) = 'FA010783.15'
		--DECLARE @KPSYear int = 2015
		--DECLARE @KPSWeek int = 41
		--DECLARE @ProductionDate DateTime = '2015-10-08'

		DECLARE @OutputSticks real
		SELECT @OutputSticks = sum(eblek.ActualProduction) FROM ExeTPOProductionEntryVerification eblekVerif
		INNER JOIN ExeTPOProduction eblek ON eblek.ProductionEntryCode = eblekVerif.ProductionEntryCode
		WHERE LocationCode = @LocationCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND ProductionDate = @ProductionDate

		DECLARE @JKNJam float
		DECLARE @Jl1Jam float
		DECLARE @Jl2Jam float
		DECLARE @Jl3Jam float
		DECLARE @Jl4Jam float
		DECLARE @JKNJamStd float
		DECLARE @Jl1JamStd float
		DECLARE @Jl2JamStd float
		DECLARE @Jl3JamStd float
		DECLARE @Jl4JamStd float

		-- Check whether ProductionDate is Holiday (it so skip to JL2Jam)
		DECLARE @IsHoliday int
		SELECT @IsHoliday = COUNT(*) FROM MstGenHoliday
		WHERE HolidayDate = @ProductionDate AND LocationCode = @LocationCode AND HolidayType = 'HOLIDAY'

		-- Standar Hours
		SELECT @JKNJamStd = JknHour, @Jl1JamStd = Jl1Hour, @Jl2JamStd = Jl2Hour, @Jl3JamStd = Jl3Hour, @Jl4JamStd = Jl4Hour FROM MstGenStandardHours
		WHERE UPPER(DayType) = UPPER(CASE WHEN @IsHoliday > 0 THEN 'HOLIDAY' ELSE 'NON-HOLIDAY' END) AND Day =  DATEPART(dw, @ProductionDate)

		DECLARE @JKNJamCalculation float
		SELECT TOP 1
			@JKNJamCalculation =
			CAST(DATEDIFF(HOUR,TimeIn,TimeOut) as float) -
			ROUND(CAST(DATEPART(hour,BreakTime) AS float)+(CAST(DATEPART(minute,BreakTime) AS float)/60),1)
		FROM ExeActualWorkHours
		WHERE LocationCode = @LocationCode AND BrandCode = @BrandCode AND ProductionDate = @ProductionDate

		DECLARE @Variance float
		IF @IsHoliday <= 0
		BEGIN
			-- Start From JKNJam
			IF @JKNJamCalculation > @JKNJamStd
			BEGIN
				SET @Variance = @JKNJamCalculation - @JKNJamStd
				SET @JKNJam = @JKNJamStd
				IF @Variance > @Jl1JamStd
				BEGIN
					SET @Variance = @Variance - @Jl1JamStd
					SET @Jl1Jam = @Jl1JamStd
					IF @Variance > @Jl2JamStd
					BEGIN
						SET @Variance = @Variance - @Jl2JamStd
						SET @Jl2Jam = @Jl2JamStd
						IF @Variance > @Jl3JamStd
						BEGIN
							SET @Variance = @Variance - @Jl3JamStd
							SET @Jl3Jam = @Jl3JamStd
							IF @Variance > @Jl4JamStd
							BEGIN
								SET @Variance = @Variance - @Jl4JamStd
								SET @Jl4Jam = @Jl4JamStd
							END
							ELSE
							BEGIN
								SET @Jl4Jam = @Variance
							END
						END
						ELSE
						BEGIN
							SET @Jl3Jam = @Variance
						END
					END
					ELSE
					BEGIN
						SET @Jl2Jam = @Variance
					END
				END
				ELSE
				BEGIN
					SET @Jl1Jam = @Variance
				END
			END
			ELSE			
			BEGIN
				SET @JKNJam = @JKNJamCalculation
			END
		
		END
		ELSE
		BEGIN
			-- Start From JL2Jam IF Holiday
			IF @JKNJamCalculation > @Jl2JamStd
			BEGIN
				SET @Variance = @JKNJamCalculation - @JL2JamStd
				SET @Jl2jam = @Jl2JamStd
				IF @Variance > @Jl3JamStd
				BEGIN
					SET @Variance = @Variance - @Jl3JamStd
					SET @Jl3Jam = @Jl3JamStd
					IF @Variance > @Jl4JamStd
					BEGIN
						SET @Variance = @Variance - @Jl4JamStd
						SET @Jl4Jam = @Jl4JamStd					
					END
					ELSE
					BEGIN
						SET @Jl4Jam = @Variance
					END
				END
				ELSE
				BEGIN
					SET @Jl3Jam = @Variance
				END
			END
			ELSE			
			BEGIN
				SET @Jl2Jam = @JKNJamCalculation
			END

		END

		DECLARE @Outputbox float = @OutputSticks / @StickPerBox

		INSERT INTO TPOFeeProductionDaily
		SELECT 
			@TPOFeeCode, 
			@ProductionDate, 
			@KPSYear, 
			@KPSWeek, 
			@OutputSticks,
			@Outputbox,
			@Outputbox * @JKNJam,
			@Outputbox * @Jl1Jam,
			@Outputbox * @Jl2Jam,
			@Outputbox * @Jl3Jam,
			@Outputbox * @Jl4Jam,
			GETDATE(),
			'PMI/User',
			GETDATE(),
			'PMI/User',
			@JKNJam,
			@Jl1Jam,
			@Jl2Jam,
			@Jl3Jam,
			@Jl4Jam
	END

	-- Check TPO Fee Calculation
	DECLARE @TPOFeeCalculationExist INT
	SELECT @TPOFeeCalculationExist = COUNT(*) FROM TPOFeeCalculation
	WHERE TPOFeeCode = @TPOFeeCode

		DECLARE @HDRTotalProdBox float
		DECLARE @HDRTotalProdJl1 float
		DECLARE @HDRTotalProdJl2 float
		DECLARE @HDRTotalProdJl3 float
		DECLARE @HDRTotalProdJl4 float
	
		SELECT @HDRTotalProdBox = TotalProdBox, @HDRTotalProdJl1 = TotalProdJl1, @HDRTotalProdJl2 = TotalProdJl2, @HDRTotalProdJl3 = TotalProdJl3, @HDRTotalProdJl4 = TotalProdJl4 FROM TPOFeeHdr
		WHERE TPOFeeCode = @TPOFeeCode AND LocationCode = @LocationCode AND BrandGroupCode = @BrandGroupCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND BrandCode = @BrandCode
	
		--DECLARE @DailyTotalJKNJam float
		--DECLARE @DailyTotalJL1Jam float
		--DECLARE @DailyTotalJL2Jam float
		--DECLARE @DailyTotalJL3Jam float
		--DECLARE @DailyTotalJL4Jam float

		--SELECT @DailyTotalJKNJam = SUM(COALESCE(JKNJam,0)), @DailyTotalJL1Jam = SUM(COALESCE(JL1Jam,0)), @DailyTotalJL2Jam = SUM(COALESCE(JL2Jam,0)), @DailyTotalJL3Jam = SUM(COALESCE(JL3Jam,0)), @DailyTotalJL4Jam = SUM(COALESCE(JL4Jam,0)) FROM TPOFeeProductionDaily
		--WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear and KPSWeek = @KPSWeek

		DECLARE @TPORateJKN float
		DECLARE @TPORateJl1 float
		DECLARE @TPORateJl2 float
		DECLARE @TPORateJl3 float
		DECLARE @TPORateJl4 float
		DECLARE @ManagementFee float
		DECLARE @ProductivityIncentives float

		SELECT @TPORateJKN = JKN, @TPORateJl1 = Jl1, @TPORateJl2 = Jl2, @TPORateJl3 = Jl3, @TPORateJl4 = Jl4, @ManagementFee = ManagementFee, @ProductivityIncentives = ProductivityIncentives FROM MstTPOFeeRate
		WHERE LocationCode= @LocationCode AND BrandGroupCode = @BrandGroupCode AND EffectiveDate = @ProductionDate

		--DECLARE @OutputBiaya1 float = (@DailyTotalJKNJam * @TPORateJKN)
		--DECLARE @OutputBiaya2 float = (@DailyTotalJL1Jam * @TPORateJl1)
		--DECLARE @OutputBiaya3 float = (@DailyTotalJL2Jam * @TPORateJl2)
		--DECLARE @OutputBiaya4 float = (@DailyTotalJL3Jam * @TPORateJl3)
		--DECLARE @OutputBiaya5 float = (@DailyTotalJL4Jam * @TPORateJl4)

		DECLARE @OutputBiaya1 float = (@TPORateJKN)
		DECLARE @OutputBiaya2 float = (@TPORateJl1)
		DECLARE @OutputBiaya3 float = (@TPORateJl2)
		DECLARE @OutputBiaya4 float = (@TPORateJl3)
		DECLARE @OutputBiaya5 float = (@TPORateJl4)


	IF @TPOFeeCalculationExist <= 0 
	BEGIN		

		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'JKN',@KPSYear,@KPSWeek,1,@HDRTotalProdBox,@OutputBiaya1,@HDRTotalProdBox*@OutputBiaya1
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'JL1',@KPSYear,@KPSWeek,2,@HDRTotalProdJl1,@OutputBiaya2,@HDRTotalProdJl1*@OutputBiaya2
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'JL2',@KPSYear,@KPSWeek,3,@HDRTotalProdJl2,@OutputBiaya3,@HDRTotalProdJl2*@OutputBiaya3
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'JL3',@KPSYear,@KPSWeek,4,@HDRTotalProdJl3,@OutputBiaya4,@HDRTotalProdJl3*@OutputBiaya4
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'JL4',@KPSYear,@KPSWeek,5,@HDRTotalProdJl4,@OutputBiaya5,@HDRTotalProdJl4*@OutputBiaya5
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Biaya Produksi',@KPSYear,@KPSWeek,6,@HDRTotalProdBox,NULL,@HDRTotalProdBox*@OutputBiaya1
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Jasa Manajemen',@KPSYear,@KPSWeek,7,@HDRTotalProdBox,@ManagementFee,@HDRTotalProdBox*@ManagementFee
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Total Biaya Produksi & Jasa Manajemen',@KPSYear,@KPSWeek,8,NULL,NULL,((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives))
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Pajak Jasa Manajemen Sebesar 2%',@KPSYear,@KPSWeek,9,NULL,NULL,(((@HDRTotalProdBox*@ManagementFee) * 2)/100)
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Total Biaya Yang Harus Dibayarkan Ke MPS',@KPSYear,@KPSWeek,10,NULL,NULL,(((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives)) - (((@HDRTotalProdBox*@ManagementFee) * 2)/100))
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Pembayaran',@KPSYear,@KPSWeek,11,NULL,NULL,(((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives)) - (((@HDRTotalProdBox*@ManagementFee) * 2)/100))
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Sisa yang harus dibayar',@KPSYear,@KPSWeek,12,NULL,NULL,0 --???
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'PPN Biaya Produksi 10%',@KPSYear,@KPSWeek,13,NULL,NULL,(((@HDRTotalProdBox*@ManagementFee) * 10)/100)
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'PPN Jasa Manajemen 10%',@KPSYear,@KPSWeek,14,NULL,NULL,(((@HDRTotalProdBox*@OutputBiaya1) * 10)/100)
		)
		INSERT INTO TPOFeeCalculation VALUES(
			@TPOFeeCode,'Total Bayar',@KPSYear,@KPSWeek,15,NULL,NULL,((((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives)) - (((@HDRTotalProdBox*@ManagementFee) * 2)/100)) + (((@HDRTotalProdBox*@ManagementFee) * 10)/100) + (((@HDRTotalProdBox*@OutputBiaya1) * 10)/100))
		)
	END
	ELSE
	BEGIN
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdBox,
			OutputBiaya = @OutputBiaya1,
			Calculate = @HDRTotalProdBox*@OutputBiaya1
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 1 AND ProductionFeeType = 'JKN'	
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdJl1,
			OutputBiaya = @OutputBiaya2,
			Calculate = @HDRTotalProdJl1*@OutputBiaya2
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 2 AND ProductionFeeType = 'JL1'	
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdJl2,
			OutputBiaya = @OutputBiaya3,
			Calculate = @HDRTotalProdJl2*@OutputBiaya3
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 3 AND ProductionFeeType = 'JL2'	
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdJl3,
			OutputBiaya = @OutputBiaya4,
			Calculate = @HDRTotalProdJl3*@OutputBiaya4
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 4 AND ProductionFeeType = 'JL3'	
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdJl4,
			OutputBiaya = @OutputBiaya5,
			Calculate = @HDRTotalProdJl4*@OutputBiaya5
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 5 AND ProductionFeeType = 'JL4'	
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdBox,		
			Calculate = @HDRTotalProdBox*@OutputBiaya1
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 6 AND ProductionFeeType = 'Biaya Produksi'	
		UPDATE TPOFeeCalculation SET
			OutputProduction = @HDRTotalProdBox,
			OutputBiaya = @ManagementFee,		
			Calculate = @HDRTotalProdBox*@ManagementFee
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 7 AND ProductionFeeType = 'Jasa Manajemen'
		UPDATE TPOFeeCalculation SET		
			Calculate = ((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives))
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 8 AND ProductionFeeType = 'Total Biaya Produksi & Jasa Manajemen'
		UPDATE TPOFeeCalculation SET				
			Calculate = (((@HDRTotalProdBox*@ManagementFee) * 2)/100)
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 9 AND ProductionFeeType = 'Pajak Jasa Manajemen Sebesar 2%'		
		UPDATE TPOFeeCalculation SET				
			Calculate = (((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives)) - (((@HDRTotalProdBox*@ManagementFee) * 2)/100))
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 10 AND ProductionFeeType = 'Total Biaya Yang Harus Dibayarkan Ke MPS'		
		UPDATE TPOFeeCalculation SET				
			Calculate = (((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives)) - (((@HDRTotalProdBox*@ManagementFee) * 2)/100))
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 11 AND ProductionFeeType = 'Pembayaran'
		UPDATE TPOFeeCalculation SET				
			Calculate = 0 --???
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 12 AND ProductionFeeType = 'Sisa yang harus dibayar'		
		UPDATE TPOFeeCalculation SET				
			Calculate = (((@HDRTotalProdBox*@ManagementFee) * 10)/100)
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 13 AND ProductionFeeType = 'PPN Biaya Produksi 10%'
		UPDATE TPOFeeCalculation SET				
			Calculate = (((@HDRTotalProdBox*@OutputBiaya1) * 10)/100)
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 14 AND ProductionFeeType = 'PPN Jasa Manajemen 10%'
		UPDATE TPOFeeCalculation SET				
			Calculate = ((((@HDRTotalProdBox*@OutputBiaya1)+(@HDRTotalProdBox*@ManagementFee)-(@HDRTotalProdBox*@ProductivityIncentives)) - (((@HDRTotalProdBox*@ManagementFee) * 2)/100)) + (((@HDRTotalProdBox*@ManagementFee) * 10)/100) + (((@HDRTotalProdBox*@OutputBiaya1) * 10)/100))
		WHERE TPOFeeCode = @TPOFeeCode AND KPSYear = @KPSYear AND KPSWeek = @KPSWeek AND OrderFeeType = 15 AND ProductionFeeType = 'Total Bayar'

	END
END

GO


