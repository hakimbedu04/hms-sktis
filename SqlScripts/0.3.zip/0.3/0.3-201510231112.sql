-- Description: Add relation ExePlantProductionEntry with MstPlantEmpJobsDataAll and MstPlantAbsentType
-- Ticket: http://tp.voxteneo.com/entity/54555 | Task#54555 View
-- Author: Harizal Hilmi

GO
ALTER TABLE dbo.MstPlantAbsentType SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.MstPlantEmpJobsDataAll SET (LOCK_ESCALATION = TABLE)
GO
GO
ALTER TABLE dbo.ExePlantProductionEntry ADD CONSTRAINT
	FK_ExePlantProductionEntry_MstPlantEmpJobsDataAll FOREIGN KEY
	(
	EmployeeID
	) REFERENCES dbo.MstPlantEmpJobsDataAll
	(
	EmployeeID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantProductionEntry ADD CONSTRAINT
	FK_ExePlantProductionEntry_MstPlantAbsentType FOREIGN KEY
	(
	AbsentType
	) REFERENCES dbo.MstPlantAbsentType
	(
	AbsentType
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExePlantProductionEntry SET (LOCK_ESCALATION = TABLE)
GO