-- Description: Please get data from ItemStatus "Sparepart" without space on table MstMntcItem.
-- Ticket: http://tp.voxteneo.com/entity/58404
-- Author: Harizal


/****** Object:  View [dbo].[MstMntcConvertGetItemDestinationView]    Script Date: 25/11/2015 11:20:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [dbo].[MstMntcConvertGetItemDestinationView]
AS
SELECT        A.ItemCode, B.ItemCode AS ItemCodeDest, B.ItemDescription, C.QtyConvert AS Qty
FROM            (SELECT        ItemCode, ItemDescription
                          FROM            dbo.MstMntcItem
                          WHERE        (ItemType <> 'SPAREPART')) AS A CROSS JOIN
                             (SELECT        ItemCode, ItemDescription
                               FROM            dbo.MstMntcItem AS MstMntcItem_1
                               WHERE        (ItemType = 'SPAREPART')) AS B LEFT OUTER JOIN
                             (SELECT        ItemCodeSource, ItemCodeDestination, QtyConvert
                               FROM            dbo.MstMntcConvert AS MstMntcConvert_1
                               WHERE        (ConversionType = 1)) AS C ON C.ItemCodeSource = A.ItemCode AND C.ItemCodeDestination = B.ItemCode

GO


