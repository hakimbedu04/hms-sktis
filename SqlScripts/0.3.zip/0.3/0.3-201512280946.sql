-- Description: Adding KPSYear and KPSWeek
-- Ticket: - SP insert ExeReportByGroups from Eblek Verifications
-- Author: Harizal

ALTER TABLE ExeReportByGroups ADD KPSYear int, KPSWeek int