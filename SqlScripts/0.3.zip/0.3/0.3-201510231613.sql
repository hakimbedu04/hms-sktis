-- Description: CreateNewtable Exe TPO Production Entry Verification
-- Ticket: http://tp.voxteneo.com/entity/56093
-- Author: Bagus

CREATE TABLE dbo.ExeTPOProductionEntryVerification
	(
	LocationCode varchar(8) NOT NULL,
	ProcessGroup varchar(16) NOT NULL,
	ProcessOrder int NOT NULL,
	BrandCode varchar(11) NOT NULL,
	KPSYear int NOT NULL,
	KPSWeek int NOT NULL, 
	ProductionDate datetime NOT NULL,
	TotalTPKValue int NULL,
	TotalActualValue int NULL,
	VerifySystem bit NULL,
	VerifyManual bit NULL,
	Remark varchar(256) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.ExeTPOProductionEntryVerification ADD CONSTRAINT
	PK_ExeTPOProductionEntryVerification PRIMARY KEY CLUSTERED 
	(
	LocationCode,
	ProcessGroup,
	BrandCode,
	KPSYear,
	KPSWeek,
	ProductionDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExeTPOProductionEntryVerification ADD CONSTRAINT
	FK_ExeTPOProductionEntryVerification_MstGenProcess FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeTPOProductionEntryVerification ADD CONSTRAINT
	FK_ExeTPOProductionEntryVerification_MstGenBrand FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeTPOProductionEntryVerification ADD CONSTRAINT
	FK_ExeTPOProductionEntryVerification_MstGenLocation FOREIGN KEY
	(
	LocationCode
	) REFERENCES dbo.MstGenLocation
	(
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO