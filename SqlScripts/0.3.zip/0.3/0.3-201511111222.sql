-- Description: Alter view for new logic
-- Ticket: http://tp.voxteneo.com/entity/54684
-- Author: Dwi Yudha

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[ExePlantActualWorkHoursView]
AS
	SELECT DISTINCT '' as UnitCode, psl.LocationCode, p.ProcessGroup, p.ProcessOrder, NULL AS BrandCode, NULL AS StatusIdentifier, NULL AS ProductionDate, NULL AS Shift, NULL 
                         AS StatusEmp, NULL AS TimeIn, NULL AS TimeOut, NULL AS BreakTime
	FROM dbo.MstGenProcessSettingsLocation AS psl INNER JOIN
                         dbo.MstGenProcessSettingsMapping AS psm ON psm.ProcessSettingsLocationID = psl.ID INNER JOIN
                         dbo.MstGenProcessSettings AS ps ON ps.ID = psm.ProcessSettingsID INNER JOIN
                         dbo.MstGenProcess AS p ON p.ProcessGroup = ps.ProcessGroup 
	WHERE (p.StatusActive = 1)
GO


