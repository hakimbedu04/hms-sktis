-- Description: Add Coloumn Flag_Manual in ExePlantProductionEntryVerification
-- Ticket: http://tp.voxteneo.com/entity/54366
-- Author: Harizal Hilmi

ALTER TABLE dbo.ExePlantProductionEntryVerification
ADD Flag_Manual BIT NULL