-- Description: Update to MntcAllView
-- Ticket: bug/8417 Point all the views related to Inventory to MtncinventoryViewAll
-- Author: Bagus
ALTER View [dbo].[MaintenanceEquipmentFulfillmentItemDetailView]

AS

SELECT        TOP (100) PERCENT dbo.MntcInventoryAll.ItemCode, dbo.MstMntcItem.ItemDescription, dbo.MntcInventoryAll.ItemStatus, dbo.MntcInventoryAll.EndingStock, 
                         dbo.MntcInventoryAll.LocationCode, dbo.MntcInventoryAll.InventoryDate
FROM            dbo.MstMntcItem INNER JOIN
                         dbo.MntcInventoryAll ON dbo.MstMntcItem.ItemCode = dbo.MntcInventoryAll.ItemCode
ORDER BY dbo.MntcInventoryAll.InventoryDate DESC

GO


