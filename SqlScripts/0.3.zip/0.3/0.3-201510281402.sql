-- Description: add BrandCode in ExeTPOProduction
-- Ticket: -
-- Author: Bagus

ALTER TABLE dbo.ExeTPOProduction ADD
	BrandCode varchar(11) NULL
GO
ALTER TABLE dbo.ExeTPOProduction ADD CONSTRAINT
	FK_ExeTPOProduction_MstGenLocation FOREIGN KEY
	(
	LocationCode
	) REFERENCES dbo.MstGenLocation
	(
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeTPOProduction ADD CONSTRAINT
	FK_ExeTPOProduction_MstGenBrand FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeTPOProduction ADD CONSTRAINT
	FK_ExeTPOProduction_MstGenProcess FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO