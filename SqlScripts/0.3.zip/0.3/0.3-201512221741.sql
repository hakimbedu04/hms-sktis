--Description   : Create table master tableau reports
--Author  : Oka
--Tiket   : http://192.168.62.216/TargetProcess/entity/1641

CREATE TABLE MstTableauReport
(
Id INT,
ReportType VARCHAR(256),
ReportName VARCHAR(256),
ReportUrl VARCHAR(256),
CreatedBy VARCHAR(256),
CreatedDate DATETIME,
CONSTRAINT PK_MstTableauReport PRIMARY KEY (Id)
);