-- Description: Alter table MntcEquipmentFulfillment
-- Ticket: http://tp.voxteneo.com/entity/58245
-- Author: Oka

ALTER TABLE MntcEquipmentFulfillment
ADD ApprovedQty NUMERIC(16,0)