-- Description: Create new view ExePlantActualWorkHours
-- Ticket: task/33129-54569-view
-- Author: Yudha

/****** Object:  View [dbo].[ExePlantActualWorkHoursView]    Script Date: 10/27/2015 17:13:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ExePlantActualWorkHoursView]
AS
SELECT     distinct(pu.UnitCode), psl.LocationCode, p.ProcessGroup, p.ProcessOrder, awh.BrandCode, 
awh.StatusIdentifier, awh.ProductionDate, awh.Shift, awh.StatusEmp, awh.TimeIn, 
                      awh.TimeOut, awh.BreakTime
FROM         dbo.MstGenProcessSettingsLocation AS psl INNER JOIN
                      dbo.MstGenProcessSettings AS ps ON ps.IDProcess = psl.IDProcess INNER JOIN
                      dbo.MstGenProcess AS p ON p.ProcessIdentifier = ps.ProcessIdentifier INNER JOIN
                      dbo.MstPlantUnit AS pu ON pu.LocationCode = psl.LocationCode LEFT OUTER JOIN
                      dbo.ExeActualWorkHours AS awh ON awh.LocationCode = psl.LocationCode AND awh.UnitCode = pu.UnitCode
WHERE     (p.StatusActive = 1)