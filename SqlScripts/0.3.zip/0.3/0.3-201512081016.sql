-- Description: Modify ExeProductionEntryRelease with UtilTransactionLogs View
-- Ticket: http://tp.voxteneo.com/entity/59286
-- Author: Azka

/****** Object:  View [dbo].[ExeProductionEntryReleaseTransactLogsView]    Script Date: 12/4/2015 9:53:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[ExeProductionEntryReleaseTransactLogsView]
as
select 
er.ProductionEntryCode, 
ev.LocationCode,
ev.UnitCode,
ev.[Shift], 
ev.ProcessGroup,
ev.ProductionDate as EblekDate,
ev.GroupCode,
ev.BrandCode,
er.IsLocked, 
er.Remark, 
ut.TransactionCode, 
ut.IDFlow
from ExePlantProductionEntryVerification ev
inner join ExeProductionEntryRelease er on er.ProductionEntryCode = ev.ProductionEntryCode
inner join UtilTransactionLogs ut on ut.TransactionCode = er.ProductionEntryCode
GO


