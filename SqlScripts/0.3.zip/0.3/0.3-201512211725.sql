-- Description: Update utilflows for eblek release
-- Ticket: bug excel id 141
-- Author: Azka
 
 UPDATE UtilFlows SET ActionButton = 153 WHERE IDFlow = 27
 GO