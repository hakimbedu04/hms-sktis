-- Description: Create ExePlantProductionEntryReport View
-- Ticket: http://tp.voxteneo.com/entity/54564
-- Author: Yudha

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS
         WHERE TABLE_NAME = 'ExePlantProductionEntryReport')
   DROP VIEW ExePlantProductionEntryReport    
GO