 ALTER VIEW [dbo].[EquipmentRequestView]
AS
 SELECT RequestDate,
            ItemCode,
            ItemDescription,
            [Ready to Use] AS ReadyToUse,
            [On Used] AS OnUse,
            [On Repair] AS OnRepair,
            TotalQty,
            ApprovedQty,
            LocationCode,
            RequestNumber,
            UpdatedBy
     FROM( 
           SELECT ER.RequestDate,
                  ER.ItemCode,
                  MI.ItemDescription,
                  I.EndingStock,
                  I.ItemStatus,
                  ER.Qty AS TotalQty,
                  ER.ApprovedQty,
                  ER.LocationCode,
                  ER.RequestNumber,
                  ER.UpdatedBy
           FROM MntcEquipmentRequest AS ER
                INNER JOIN MstMntcItem AS MI ON MI.ItemCode = ER.ItemCode
                LEFT JOIN(
                    SELECT *
                    FROM MntcInventoryAll s1
                     ) AS I ON ER.ItemCode = I.ItemCode
                    AND ER.LocationCode = I.LocationCode ) AS A PIVOT( MAX(EndingStock) FOR ItemStatus IN( [Ready to Use],
																										[On Used],
                                                                                                        [On Repair] )) AS EquipmentRequestView;

GO

