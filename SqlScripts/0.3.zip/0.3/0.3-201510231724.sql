-- Description: Create New table Exe TPO Production Actual Work Hours
-- Ticket: http://tp.voxteneo.com/entity/56093
-- Author: Bagus

CREATE TABLE [dbo].[ExeTPOActualWorkHours](
	[LocationCode] [varchar](8) NOT NULL,
	[UnitCode] [varchar](4) NOT NULL,
	[BrandCode] [varchar](11) NOT NULL,
	[ProductionDate] [datetime] NOT NULL,
	[ProcessGroup] [varchar](16) NOT NULL,
	[ProcessOrder] [int] NOT NULL,
	[StatusEmp] [varchar](16) NOT NULL,
	[StatusIdentifier] [char](1) NOT NULL,
	[TimeIn] [time](7) NULL,
	[TimeOut] [time](7) NULL,
	[BreakTime] [time](7) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](64) NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
	[UpdatedBy] [varchar](64) NOT NULL,
 CONSTRAINT [PK_ExeTPOActualWorkHours] PRIMARY KEY CLUSTERED 
(
	[LocationCode] ASC,
	[UnitCode] ASC,
	[BrandCode] ASC,
	[ProductionDate] ASC,
	[ProcessGroup] ASC,
	[StatusEmp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours]  WITH CHECK ADD  CONSTRAINT [FK_ExeTPOActualWorkHours_MstGenBrand] FOREIGN KEY([BrandCode])
REFERENCES [dbo].[MstGenBrand] ([BrandCode])
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours] CHECK CONSTRAINT [FK_ExeTPOActualWorkHours_MstGenBrand]
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours]  WITH CHECK ADD  CONSTRAINT [FK_ExeTPOActualWorkHours_MstGenEmpStatus] FOREIGN KEY([StatusEmp])
REFERENCES [dbo].[MstGenEmpStatus] ([StatusEmp])
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours] CHECK CONSTRAINT [FK_ExeTPOActualWorkHours_MstGenEmpStatus]
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours]  WITH CHECK ADD  CONSTRAINT [FK_ExeTPOActualWorkHours_MstGenProcess] FOREIGN KEY([ProcessGroup])
REFERENCES [dbo].[MstGenProcess] ([ProcessGroup])
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours] CHECK CONSTRAINT [FK_ExeTPOActualWorkHours_MstGenProcess]
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours]  WITH CHECK ADD  CONSTRAINT [FK_ExeTPOActualWorkHours_MstPlantUnit] FOREIGN KEY([UnitCode], [LocationCode])
REFERENCES [dbo].[MstPlantUnit] ([UnitCode], [LocationCode])
GO

ALTER TABLE [dbo].[ExeTPOActualWorkHours] CHECK CONSTRAINT [FK_ExeTPOActualWorkHours_MstPlantUnit]
GO


