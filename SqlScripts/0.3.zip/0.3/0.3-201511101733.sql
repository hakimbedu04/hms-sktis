-- Description: Alter table ExePlantActualWorkHours
-- Ticket: task/33129-54570-save
-- Author: Yudha

TRUNCATE TABLE [dbo].[ExeActualWorkHours]

ALTER TABLE dbo.ExeActualWorkHours
	DROP CONSTRAINT FK_ExeActualWorkHours_MstGenProcess
GO
ALTER TABLE dbo.MstGenProcess SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.ExeActualWorkHours
	DROP CONSTRAINT FK_ExeActualWorkHours_MstGenBrand
GO
ALTER TABLE dbo.MstGenBrand SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.ExeActualWorkHours
	DROP CONSTRAINT FK_ExeActualWorkHours_MstPlantUnit
GO
ALTER TABLE dbo.MstPlantUnit SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.ExeActualWorkHours
	DROP CONSTRAINT FK_EXEACTUALWORKHOURS_REFERENCE_131_MSTGENEMPSTATUS
GO
ALTER TABLE dbo.MstGenEmpStatus SET (LOCK_ESCALATION = TABLE)
GO
CREATE TABLE dbo.Tmp_ExeActualWorkHours
	(
	LocationCode varchar(8) NOT NULL,
	UnitCode varchar(4) NOT NULL,
	Shift int NOT NULL,
	BrandCode varchar(11) NOT NULL,
	ProductionDate date NOT NULL,
	ProcessGroup varchar(16) NOT NULL,
	TimeIn time(7) NULL,
	TimeOut time(7) NULL,
	BreakTime time(7) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_ExeActualWorkHours SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.ExeActualWorkHours)
	 EXEC('INSERT INTO dbo.Tmp_ExeActualWorkHours (LocationCode, UnitCode, Shift, BrandCode, ProductionDate, ProcessGroup, TimeIn, TimeOut, BreakTime, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT LocationCode, UnitCode, Shift, BrandCode, ProductionDate, ProcessGroup, TimeIn, TimeOut, BreakTime, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.ExeActualWorkHours WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.ExeActualWorkHours
GO
EXECUTE sp_rename N'dbo.Tmp_ExeActualWorkHours', N'ExeActualWorkHours', 'OBJECT' 
GO
ALTER TABLE dbo.ExeActualWorkHours ADD CONSTRAINT
	PK_ExeActualWorkHours_1 PRIMARY KEY CLUSTERED 
	(
	LocationCode,
	UnitCode,
	Shift,
	BrandCode,
	ProductionDate,
	ProcessGroup
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.ExeActualWorkHours ADD CONSTRAINT
	FK_ExeActualWorkHours_MstPlantUnit FOREIGN KEY
	(
	UnitCode,
	LocationCode
	) REFERENCES dbo.MstPlantUnit
	(
	UnitCode,
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeActualWorkHours ADD CONSTRAINT
	FK_ExeActualWorkHours_MstGenBrand FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeActualWorkHours ADD CONSTRAINT
	FK_ExeActualWorkHours_MstGenProcess FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	