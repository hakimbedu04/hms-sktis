
ALTER TABLE dbo.TPOFeeHdr SET (LOCK_ESCALATION = TABLE)
GO

CREATE TABLE dbo.Tmp_TPOFeeProductionDaily
	(
	TPOFeeCode varchar(64) NOT NULL,
	FeeDate date NOT NULL,
	KPSYear int NULL,
	KPSWeek int NULL,
	OuputSticks float(53) NULL,
	OutputBox float(53) NULL,
	JKN numeric(10, 0) NULL,
	JL1 numeric(10, 0) NULL,
	Jl2 numeric(10, 0) NULL,
	Jl3 numeric(10, 0) NULL,
	Jl4 numeric(10, 0) NULL,
	CreatedDate datetime NULL,
	CreatedBy varchar(64) NULL,
	UpdatedDate datetime NULL,
	UpdatedBy varchar(64) NULL,
	JKNJam int NULL,
	JL1Jam int NULL,
	JL2Jam int NULL,
	JL3Jam int NULL,
	JL4Jam int NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TPOFeeProductionDaily SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.TPOFeeProductionDaily)
	 EXEC('INSERT INTO dbo.Tmp_TPOFeeProductionDaily (FeeDate, KPSYear, KPSWeek, OuputSticks, OutputBox, JKN, JL1, Jl2, Jl3, Jl4, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, JKNJam, JL1Jam, JL2Jam, JL3Jam, JL4Jam)
		SELECT CONVERT(date, FeeDate), KPSYear, KPSWeek, OuputSticks, OutputBox, JKN, JL1, Jl2, Jl3, Jl4, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, JKNJam, JL1Jam, JL2Jam, JL3Jam, JL4Jam FROM dbo.TPOFeeProductionDaily WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.TPOFeeProductionDaily
GO
EXECUTE sp_rename N'dbo.Tmp_TPOFeeProductionDaily', N'TPOFeeProductionDaily', 'OBJECT' 
GO
ALTER TABLE dbo.TPOFeeProductionDaily ADD CONSTRAINT
	PK_TPOFeeProductionDaily_1 PRIMARY KEY CLUSTERED 
	(
	TPOFeeCode,
	FeeDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.TPOFeeProductionDaily ADD CONSTRAINT
	FK_TPOFeeProductionDaily_TPOFeeHdr FOREIGN KEY
	(
	TPOFeeCode
	) REFERENCES dbo.TPOFeeHdr
	(
	TPOFeeCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
