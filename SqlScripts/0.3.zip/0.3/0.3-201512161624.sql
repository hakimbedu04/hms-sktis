-- Description: Create new View MstProcessBrandView
-- Ticket: http://tp.voxteneo.com/entity/61247
-- Author: Yudha


CREATE VIEW [dbo].[MstProcessBrandView]
AS
    SELECT DISTINCT 
							 psl.LocationCode, p.ProcessGroup, p.ProcessOrder, b.BrandCode, b.BrandGroupCode
	FROM            dbo.MstGenProcessSettingsLocation AS psl INNER JOIN
							 dbo.MstGenProcessSettingsMapping AS psm ON psm.ProcessSettingsLocationID = psl.ID INNER JOIN
							 dbo.MstGenProcessSettings AS ps ON ps.ID = psm.ProcessSettingsID INNER JOIN
							 dbo.MstGenProcess AS p ON p.ProcessGroup = ps.ProcessGroup INNER JOIN
							 dbo.MstGenBrand AS b ON b.BrandGroupCode = ps.BrandGroupCode
	WHERE        (p.StatusActive = 1)
GO
