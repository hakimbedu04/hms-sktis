-- Description: Create View TPO Fee GL Accrued
-- Ticket: http://tp.voxteneo.co.id/entity/1431
-- Author: azka

create view TPOFeeExeGLAccruedListView
as
SELECT        box.KPSYear, box.KPSWeek, brand.BrandGroupCode, box.BrandCode, box.LocationCode, loc.LocationName, loc.ParentLocationCode, box.TargetManual1, box.TargetManual2, box.TargetManual3, 
                         box.TargetManual4, box.TargetManual5, box.TargetManual6, box.TargetManual7
FROM            dbo.PlanTPOTargetProductionKelompokBox AS box INNER JOIN
                         dbo.MstGenLocation AS loc ON loc.LocationCode = box.LocationCode INNER JOIN
                         dbo.MstGenBrand AS brand ON brand.BrandCode = box.BrandCode
go