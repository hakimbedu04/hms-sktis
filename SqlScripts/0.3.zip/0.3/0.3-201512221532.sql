-- Description: Get Production Card Approval List
-- Ticket: http://tp.voxteneo.com/entity/59031
-- Author: Whisnu Sucitanuary

-- Description: Change INNER JOIN to LEFT JOIN
-- Author: Harizal

ALTER VIEW [dbo].[WagesProductionCardApprovalView]
AS
SELECT ROW_NUMBER() OVER(ORDER BY card.ProductionCardCode DESC) AS Row,
	  card.ProductionCardCode,
       card.LocationCode,
       card.UnitCode,
       card.BrandCode,
       card.ProductionDate,
       trans.IDFlow,
             CASE
                 WHEN [trans].IDFlow = 21
                 THEN 'DRAFT'
                 WHEN [trans].IDFlow = 22
                 THEN 'SUBMITTED'
                 WHEN [trans].IDFlow = 25
                 THEN 'APPROVED'
                 WHEN [trans].IDFlow = 26
                 THEN 'COMPLETED'
             END AS Status,
       AD.UserAD,
       role.RolesName
FROM dbo.ProductionCard AS card
     INNER JOIN dbo.UtilTransactionLogs AS trans ON trans.TransactionCode = card.ProductionCardCode
     LEFT JOIN dbo.MstADTemp AS AD ON AD.UserAD = trans.CreatedBy
     LEFT JOIN dbo.UtilUsersResponsibility AS userresponse ON userresponse.UserAD = AD.UserAD
     LEFT JOIN dbo.UtilResponsibility AS response ON response.IDResponsibility = userresponse.IDResponsibility
     LEFT JOIN dbo.UtilRoles AS role ON role.IDRole = response.IDRole
WHERE( trans.IDFlow IN( 21, 22, 25, 26 ) )
GROUP BY card.ProductionCardCode, card.LocationCode, card.UnitCode, card.BrandCode, card.ProductionDate, AD.UserAD, role.RolesName, trans.IDFlow

GO
