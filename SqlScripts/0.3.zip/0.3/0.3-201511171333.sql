-- Description: Update to MntcAllView
-- Ticket: bug/8417 Point all the views related to Inventory to MtncinventoryViewAll
-- Author: Bagus
ALTER VIEW [dbo].[InventoryByStatusView]
AS
SELECT ISNULL(ROW_NUMBER() OVER(ORDER BY ItemCode DESC), -1) AS RowID,
       ItemCode,
       LocationCode,
       [Ready to Use] AS ReadyToUse,
       [On Use] AS OnUse,
       [On Repair] AS OnRepair
FROM( 
      SELECT s1.ItemCode,
             s1.LocationCode,
             s1.ItemStatus,
             s1.EndingStock
      FROM MntcInventoryAll s1
           INNER JOIN(
               SELECT MAX(InventoryDate) LAST_UPDATE_DATE_TIME,
                      ItemCode,
                      LocationCode,
                      ItemStatus
               FROM MntcInventoryAll
               GROUP BY ItemCode,
                        LocationCode,
                        ItemStatus ) s2 ON s1.ItemCode = s2.ItemCode
                                       AND s1.LocationCode = s2.LocationCode
                                       AND s1.InventoryDate = s2.LAST_UPDATE_DATE_TIME
                                       AND s1.ItemStatus = s2.ItemStatus ) AS A PIVOT( MAX(EndingStock) FOR ItemStatus IN( [Ready to Use],
                                                                                                                           [On Use],
                                                                                                                           [On Repair] )) AS InventoryByStatusView;

GO


