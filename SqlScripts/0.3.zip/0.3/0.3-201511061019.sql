-- Description: Create TargetProductionUnitViewPerBox View
-- Ticket: http://tp.voxteneo.com/entity/56697
-- Author: Harizal

/****** Object:  View [dbo].[TargetProductionUnitViewPerBox]    Script Date: 06/11/2015 10:18:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[TargetProductionUnitStickPerBoxView]
AS
    SELECT tpu.ProductionStartDate,
		 tpu.KPSYear,
		 tpu.KPSWeek,
		 tpu.BrandCode,
		 tpu.LocationCode,
		 tpu.UnitCode,
		 tpu.Shift,
		 tpu.TPUCode,
		 tpu.WorkerRegister,
		 tpu.WorkerAvailable,
		 tpu.WorkerAlocation,
		 tpu.PercentAttendance1,
		 tpu.PercentAttendance2,
		 tpu.PercentAttendance3,
		 tpu.PercentAttendance4,
		 tpu.PercentAttendance5,
		 tpu.PercentAttendance6,
		 tpu.PercentAttendance7,
		 tpu.HistoricalCapacityWorker1,
		 tpu.HistoricalCapacityWorker2,
		 tpu.HistoricalCapacityWorker3,
		 tpu.HistoricalCapacityWorker4,
		 tpu.HistoricalCapacityWorker5,
		 tpu.HistoricalCapacityWorker6,
		 tpu.HistoricalCapacityWorker7,
		 tpu.HistoricalCapacityGroup1,
		 tpu.HistoricalCapacityGroup2,
		 tpu.HistoricalCapacityGroup3,
		 tpu.HistoricalCapacityGroup4,
		 tpu.HistoricalCapacityGroup5,
		 tpu.HistoricalCapacityGroup6,
		 tpu.HistoricalCapacityGroup7,
		 tpu.TargetSystem1 * mgbg.StickPerBox TargetSystem1,
		 tpu.TargetSystem2 * mgbg.StickPerBox TargetSystem2,
		 tpu.TargetSystem3 * mgbg.StickPerBox TargetSystem3,
		 tpu.TargetSystem4 * mgbg.StickPerBox TargetSystem4,
		 tpu.TargetSystem5 * mgbg.StickPerBox TargetSystem5,
		 tpu.TargetSystem6 * mgbg.StickPerBox TargetSystem6,
		 tpu.TargetSystem7 * mgbg.StickPerBox TargetSystem7,
		 tpu.TargetManual1 * mgbg.StickPerBox TargetManual1,
		 tpu.TargetManual2 * mgbg.StickPerBox TargetManual2,
		 tpu.TargetManual3 * mgbg.StickPerBox TargetManual3,
		 tpu.TargetManual4 * mgbg.StickPerBox TargetManual4,
		 tpu.TargetManual5 * mgbg.StickPerBox TargetManual5,
		 tpu.TargetManual6 * mgbg.StickPerBox TargetManual6,
		 tpu.TargetManual7 * mgbg.StickPerBox TargetManual7,
		 tpu.ProcessWorkHours1,
		 tpu.ProcessWorkHours2,
		 tpu.ProcessWorkHours3,
		 tpu.ProcessWorkHours4,
		 tpu.ProcessWorkHours5,
		 tpu.ProcessWorkHours6,
		 tpu.ProcessWorkHours7,
		 tpu.TotalWorkhours,
		 tpu.TotalTargetSystem * mgbg.StickPerBox TotalTargetSystem,
		 tpu.TotalTargetManual * mgbg.StickPerBox TotalTargetManual,
		 tpu.CreatedDate,
		 tpu.CreatedBy,
		 tpu.UpdatedDate,
		 tpu.UpdatedBy,
		 wpp.Value1
    FROM dbo.PlanTargetProductionUnit AS tpu
	    INNER JOIN dbo.PlanWeeklyProductionPlanning AS wpp ON tpu.KPSYear = wpp.KPSYear
											    AND tpu.KPSWeek = wpp.KPSWeek
											    AND tpu.BrandCode = wpp.BrandCode
											    AND tpu.LocationCode = wpp.LocationCode
	    INNER JOIN dbo.MstGenBrand mgb ON mgb.BrandCode = tpu.BrandCode
	    INNER JOIN dbo.MstGenBrandGroup mgbg ON mgbg.BrandGroupCode = mgb.BrandGroupCode
    WHERE( tpu.UnitCode NOT IN( 'MTNC', 'PROD', 'WHSE' ));
GO


