-- Description: Update TPO Fee Header Total
-- Ticket: http://tp.voxteneo.com/entity/57887
-- Author: Whisnu Sucitanuary

/****** Object:  Trigger [dbo].[TPOFeeProductionDailyAfterInsert]    Script Date: 23/11/2015 6:58:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TPOFeeProductionDailyAfterInsert] ON [dbo].[TPOFeeProductionDaily]
	FOR INSERT
AS 
DECLARE @parentid VARCHAR(64)
DECLARE @TotalProdStick FLOAT
DECLARE @TotalProdBox FLOAT
DECLARE @TotalProdJKN FLOAT
DECLARE @TotalProdJl1 FLOAT
DECLARE @TotalProdJl2 FLOAT
DECLARE @TotalProdJl3 FLOAT
DECLARE @TotalProdJl4 FLOAT

SELECT @parentid=i.TPOFeeCode FROM inserted i;	
SELECT @TotalProdStick = SUM(OuputSticks) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
SELECT @TotalProdBox = SUM(OutputBox) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
SELECT @TotalProdJKN = SUM(JKN) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
SELECT @TotalProdJl1 = SUM(JL1) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
SELECT @TotalProdJl2 = SUM(JL2) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
SELECT @TotalProdJl3 = SUM(JL3) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
SELECT @TotalProdJl4 = SUM(JL4) FROM TPOFeeProductionDaily WHERE TPOFeeCode = @parentid
UPDATE TPOFeeHdr SET 
	TotalProdStick = @TotalProdStick,
	TotalProdBox = @TotalProdBox,
	TotalProdJKN = @TotalProdJKN,
	TotalProdJl1= @TotalProdJl1,
	TotalProdJl2= @TotalProdJl2,
	TotalProdJl3= @TotalProdJl3,
	TotalProdJl4= @TotalProdJl4
WHERE TPOFeeCode = @parentid


GO


