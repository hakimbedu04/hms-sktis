-- Description: Remove Location Code in MstGenMaterial
-- Ticket: http://tp.voxteneo.com/entity/57142
-- Author: Harizal

ALTER TABLE dbo.MstGenMaterial DROP CONSTRAINT FK_MSTGENMATERIAL_REFERENCE_130_MSTGENLOCATION;
GO
ALTER TABLE dbo.MstGenLocation SET( LOCK_ESCALATION = TABLE );
GO

ALTER TABLE dbo.MstGenMaterial DROP COLUMN LocationCode;
GO
ALTER TABLE dbo.MstGenMaterial SET( LOCK_ESCALATION = TABLE );
GO