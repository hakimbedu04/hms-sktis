-- Description: Change table ExePlantProductionEntry schema
-- Ticket: http://tp.voxteneo.com/entity/57299
-- Author: Oka

-- Drop table ExePlantProductionEntry
DROP TABLE ExePlantProductionEntry

-- Create table ExePlantProductionEntryVerification
CREATE TABLE ExePlantProductionEntry
(
ProductionEntryCode VARCHAR(64) NOT NULL ,
EmployeeID VARCHAR(64) NOT NULL,
EmployeeNumber VARCHAR(11),
StatusEmp VARCHAR(64) NOT NULL,
StatusIdentifier INTEGER NOT NULL,
StartDateAbsent DATETIME,
AbsentType VARCHAR(128),
ProdCapacity INTEGER,
ProdTarget INTEGER,
ProdActual INTEGER,
AbsentRemark VARCHAR(8),
AbsentCodeEblek VARCHAR(128),
AbsentCodePayroll VARCHAR(128),
CreatedDate DATETIME NOT NULL,
CreatedBy VARCHAR(64) NOT NULL,
UpdatedDate DATETIME NOT NULL,
UpdatedBy VARCHAR(64) NOT NULL,
CONSTRAINT PK_ExePlantProductionEntry PRIMARY KEY (ProductionEntryCode, EmployeeID),
CONSTRAINT FK_ExePlantProductionEntry_MstPlantAbsentType FOREIGN KEY(AbsentType) REFERENCES MstPlantAbsentType(AbsentType),
CONSTRAINT FK_ExePlantProductionEntry_MstPlantEmpJobsDataAll FOREIGN KEY(EmployeeID) REFERENCES MstPlantEmpJobsDataAll(EmployeeID),
CONSTRAINT FK_ExePlantProductionEntry_ExePlantProductionEntryVerification FOREIGN KEY(ProductionEntryCode) REFERENCES ExePlantProductionEntryVerification(ProductionEntryCode)
);



