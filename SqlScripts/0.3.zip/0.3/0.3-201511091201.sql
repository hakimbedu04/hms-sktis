-- Description: Create View For ExeMaterialUsage
-- Ticket: http://tp.voxteneo.com/entity/57767
-- Author: Harizal

/****** Object:  View [dbo].[ExeMaterialUsageView]    Script Date: 09/11/2015 11:59:27 ******/

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE VIEW [dbo].[ExeMaterialUsageView]
AS
     SELECT mppg.LocationCode,
            mppg.UnitCode,
            mgl.Shift,
            mgps.BrandGroupCode,
            emu.MaterialCode,
            mppg.GroupCode,
            mppg.ProcessGroup,
            emu.ProductionDate,
            emu.Sisa,
            emu.Ambil1,
            emu.Ambil2,
            emu.Ambil3,
            emu.TobFM,
            emu.TobStem,
            emu.TobSapon,
            emu.UncountableWaste,
            emu.CountableWaste,
            emu.CreatedDate,
            emu.CreatedBy,
            emu.UpdatedDate,
            emu.UpdatedBy
     FROM dbo.ExeMaterialUsage AS emu
          RIGHT OUTER JOIN dbo.MstPlantProductionGroup AS mppg ON mppg.GroupCode = emu.GroupCode
                                                              AND mppg.UnitCode = emu.UnitCode
                                                              AND mppg.LocationCode = emu.LocationCode
                                                              AND mppg.ProcessGroup = emu.ProcessGroup
          INNER JOIN dbo.MstGenLocation AS mgl ON mgl.LocationCode = mppg.LocationCode
          INNER JOIN dbo.MstGenProcessSettingsLocation AS mgpsl ON mppg.LocationCode = mgpsl.LocationCode
          INNER JOIN dbo.MstGenProcessSettingsMapping AS mgpsm ON mgpsm.ProcessSettingsLocationID = mgpsl.ID
          INNER JOIN dbo.MstGenProcessSettings AS mgps ON mgps.IDProcess = mgpsm.ProcessSettingsID;
GO