ALTER TABLE ExeReportByGroups ADD EmpIn int
ALTER TABLE ExeReportByGroupsMonthly ADD EmpIn int
ALTER TABLE ExeReportByGroupsWeekly ADD EmpIn int