
ALTER TABLE dbo.TPOFeeHdr
	DROP CONSTRAINT FK_TPOFEEHDR_RELATIONSHIP_87_MSTGENBRAND
GO
ALTER TABLE dbo.MstGenBrand SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.TPOFeeHdr
	DROP CONSTRAINT FK_TPOFEEHDR_RELATIONSHIP_86_MSTTPOINFO
GO
ALTER TABLE dbo.MstTPOInfo SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.TPOFeeHdr
	DROP CONSTRAINT FK_TPOFEEHDR_RELATIONSHIP_137_MSTGENBRANDGROUP
GO
ALTER TABLE dbo.MstGenBrandGroup SET (LOCK_ESCALATION = TABLE)
GO
CREATE TABLE dbo.Tmp_TPOFeeHdr
	(
	TPOFeeCode varchar(64) NOT NULL,
	LocationCode varchar(8) NULL,
	BrandGroupCode varchar(20) NULL,
	KPSYear int NOT NULL,
	KPSWeek int NOT NULL,
	BrandCode varchar(11) NULL,
	TPOFeeTempID int NULL,
	TaxtNoProd varchar(32) NULL,
	TaxtNoMgmt varchar(32) NULL,
	CurrentApproval varchar(32) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL,
	Status varchar(64) NULL,
	PengirimanL1 varchar(64) NULL,
	PengirimanL2 varchar(64) NULL,
	PengirimanL3 varchar(64) NULL,
	PengirimanL4 varchar(64) NULL,
	StickPerBox int NULL,
	TPOPackageValue float(53) NULL,
	StickPerPackage float(53) NULL,
	TotalProdStick float(53) NULL,
	TotalProdBox float(53) NULL,
	TotalProdJKN float(53) NULL,
	TotalProdJl1 float(53) NULL,
	TotalProdJl2 float(53) NULL,
	TotalProdJl3 float(53) NULL,
	TotalProdJl4 float(53) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TPOFeeHdr SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.TPOFeeHdr)
	 EXEC('INSERT INTO dbo.Tmp_TPOFeeHdr (TPOFeeCode, LocationCode, BrandGroupCode, KPSYear, KPSWeek, BrandCode, TPOFeeTempID, TaxtNoProd, TaxtNoMgmt, CurrentApproval, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, Status, PengirimanL1, PengirimanL2, PengirimanL3, PengirimanL4, StickPerBox, TPOPackageValue, StickPerPackage, TotalProdStick, TotalProdBox, TotalProdJKN, TotalProdJl1, TotalProdJl2, TotalProdJl3, TotalProdJl4)
		SELECT TPOFeeCode, LocationCode, BrandGroupCode, KPSYear, KPSWeek, BrandCode, TPOFeeTempID, TaxtNoProd, TaxtNoMgmt, CurrentApproval, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, Status, PengirimanL1, PengirimanL2, PengirimanL3, PengirimanL4, StickPerBox, TPOPackageValue, StickPerPackage, TotalProdStick, TotalProdBox, TotalProdJKN, TotalProdJl1, TotalProdJl2, TotalProdJl3, TotalProdJl4 FROM dbo.TPOFeeHdr WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE dbo.TPOFeeCalculation
	DROP CONSTRAINT FK_TPOFEECALCULATION_RELATIONSHIP_139_TPOFEEHDR
GO
ALTER TABLE dbo.TPOFeeProductionDaily
	DROP CONSTRAINT FK_TPOFEEPRODUCTIONDAILY_RELATIONSHIP_138_TPOFEEHDR
GO
DROP TABLE dbo.TPOFeeHdr
GO
EXECUTE sp_rename N'dbo.Tmp_TPOFeeHdr', N'TPOFeeHdr', 'OBJECT' 
GO
ALTER TABLE dbo.TPOFeeHdr ADD CONSTRAINT
	PK_TPOFeeHdr_1 PRIMARY KEY CLUSTERED 
	(
	TPOFeeCode
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO

ALTER TABLE dbo.TPOFeeHdr ADD CONSTRAINT [UQ_TPOHDR] UNIQUE NONCLUSTERED 
(
	[LocationCode] ASC,
    [BrandGroupCode] ASC,
	[KPSYear] ASC,
	[KPSWeek] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

ALTER TABLE dbo.TPOFeeHdr ADD CONSTRAINT
	FK_TPOFEEHDR_RELATIONSHIP_137_MSTGENBRANDGROUP FOREIGN KEY
	(
	BrandGroupCode
	) REFERENCES dbo.MstGenBrandGroup
	(
	BrandGroupCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.TPOFeeHdr ADD CONSTRAINT
	FK_TPOFEEHDR_RELATIONSHIP_86_MSTTPOINFO FOREIGN KEY
	(
	LocationCode
	) REFERENCES dbo.MstTPOInfo
	(
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.TPOFeeHdr ADD CONSTRAINT
	FK_TPOFEEHDR_RELATIONSHIP_87_MSTGENBRAND FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.TPOFeeProductionDaily SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.TPOFeeCalculation SET (LOCK_ESCALATION = TABLE)
GO
