-- Description: Create table report for Production Execution
-- Ticket: task/56660-Report Production Execution - Production Report by Groups
-- Author: Bagus
CREATE TABLE dbo.ExeReportByGroups
	(
	LocationCode varchar(8) NOT NULL,
	UnitCode varchar(4) NOT NULL,
	ProcessGroup varchar(16) NOT NULL,
	GroupCode varchar(4) NOT NULL,
	BrandGroupCode varchar(20) NOT NULL,
	BrandCode varchar(11) NOT NULL,
	StatusEmp varchar(16) NOT NULL,
	ProductionDate datetime NOT NULL,
	Shift int NOT NULL,
	Production int NULL,
	TPKValue real NULL,
	WorkHour int NULL,
	WeekDay int NOT NULL,
	Absennce_A float(53) NULL,
	Absence_I float(53) NULL,
	Absence_C float(53) NULL,
	Absence_CH float(53) NULL,
	Absence_CT float(53) NULL,
	Absence_SLS float(53) NULL,
	Absence_SLP float(53) NULL,
	Absence_ETC float(53) NULL,
	Multi_TPO int NULL,
	Multi_ROLL int NULL,
	Multi_CUTT int NULL,
	Multi_PACK int NULL,
	Multi_STAMP int NULL,
	Multi_FWRP int NULL,
	Multi_SWRP int NULL,
	Multi_GEN int NULL,
	Multi_WRP int NULL,
	Out int NULL,
	Attend int NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.ExeReportByGroups ADD CONSTRAINT
	FK_ExeReportByGroups_MstPlantUnit FOREIGN KEY
	(
	UnitCode,
	LocationCode
	) REFERENCES dbo.MstPlantUnit
	(
	UnitCode,
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeReportByGroups ADD CONSTRAINT
	FK_ExeReportByGroups_MstGenProcess FOREIGN KEY
	(
	ProcessGroup
	) REFERENCES dbo.MstGenProcess
	(
	ProcessGroup
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeReportByGroups ADD CONSTRAINT
	FK_ExeReportByGroups_MstGenBrand FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
GO
GO
ALTER TABLE dbo.ExeReportByGroups ADD CONSTRAINT
	PK_ExeReportByGroups PRIMARY KEY CLUSTERED 
	(
	LocationCode,
	GroupCode,
	BrandCode,
	ProductionDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO

