-- Description: Create View TPO Fee Plan
-- Author: OKA

CREATE VIEW [dbo].[TpoFeePlanView]
AS

SELECT 
tb1.LocationCode as LocationCode,
tb2.LocationName as LocationName,
tb3.SKTBrandCode as SKTBrandCode,
tb4.*
FROM TPOFeeHdrPlan AS tb1 
INNER JOIN MstGenLocation AS tb2 ON tb2.LocationCode = tb1.LocationCode
INNER JOIN MstGenBrandGroup as tb3 ON tb3.BrandGroupCode = tb1.BrandGroupCode
INNER JOIN TPOFeeCalculationPlan as tb4 ON tb4.TPOFeeCode = tb1.TPOFeeCode
GO