
/****** Object:  View [dbo].[ExeTPOProductionEntryVerificationView]    Script Date: 05/01/2016 23:03:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Description: Update combine view between Production Entry and Production Entry Verification
--Ticket: http://tp.voxteneo.com/entity/57886
--Author: Whisnu Updated : Bagus
ALTER VIEW [dbo].[ExeTPOProductionEntryVerificationView]
AS

SELECT        et.ProductionEntryCode, etv.LocationCode, etv.BrandCode, etv.KPSYear, etv.KPSWeek, etv.ProductionDate, etv.ProcessGroup, SUM(et.Absent) AS Absent, etv.TotalTPKValue, SUM(etv.TotalActualValue)AS TotalActualValue, 
                         etv.VerifySystem, etv.VerifyManual
FROM            dbo.ExeTPOProduction AS et INNER JOIN
                         dbo.ExeTPOProductionEntryVerification AS etv ON etv.ProductionEntryCode = et.ProductionEntryCode
GROUP BY etv.LocationCode, etv.BrandCode, etv.KPSYear, etv.KPSWeek, etv.ProductionDate, etv.ProcessGroup, etv.TotalTPKValue, etv.VerifySystem, etv.VerifyManual, et.ProductionEntryCode


GO


