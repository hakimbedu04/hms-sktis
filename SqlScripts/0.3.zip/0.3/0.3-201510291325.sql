-- Description: Add ItemCode AS PRIMARY KEY on table MntcEquipmentFulfillment & Add column ItemCode on table MntcRequestToLocation
-- Ticket: http://tp.voxteneo.com/entity/54266
-- Author: Oka

-- MntcEquipmentFulfillment
ALTER TABLE dbo.MntcEquipmentFulfillment
	DROP CONSTRAINT FK_MNTCEQUIPMENTFULFILLMENT_RELATIONSHIP_81_MNTCEQUIPMENTREQUEST
GO
CREATE TABLE dbo.Tmp_MntcEquipmentFulfillment
	(
	FulFillmentDate date NOT NULL,
	RequestDate date NULL,
	ItemCode varchar(20) NOT NULL,
	LocationCode varchar(8) NULL,
	RequestNumber varchar(11) NOT NULL,
	RequestToQty numeric(16, 0) NULL,
	PurchaseQty numeric(16, 0) NULL,
	PurchaseNumber varchar(64) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL,
	MntcReqFullFillment varchar(256) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_MntcEquipmentFulfillment SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.MntcEquipmentFulfillment)
	 EXEC('INSERT INTO dbo.Tmp_MntcEquipmentFulfillment (FulFillmentDate, RequestDate, ItemCode, LocationCode, RequestNumber, RequestToQty, PurchaseQty, PurchaseNumber, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, MntcReqFullFillment)
		SELECT FulFillmentDate, RequestDate, ItemCode, LocationCode, RequestNumber, RequestToQty, PurchaseQty, PurchaseNumber, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, MntcReqFullFillment FROM dbo.MntcEquipmentFulfillment WITH (HOLDLOCK TABLOCKX)')
GO
ALTER TABLE dbo.MntcRequestToLocation
	DROP CONSTRAINT FK_MNTCREQUESTTOLOCATION_RELATIONSHIP_80_MNTCEQUIPMENTFULFILLMENT
GO
DROP TABLE dbo.MntcEquipmentFulfillment
GO
EXECUTE sp_rename N'dbo.Tmp_MntcEquipmentFulfillment', N'MntcEquipmentFulfillment', 'OBJECT' 
GO
ALTER TABLE dbo.MntcEquipmentFulfillment ADD CONSTRAINT
	PK_MNTCEQUIPMENTFULFILLMENT PRIMARY KEY NONCLUSTERED 
	(
	FulFillmentDate,
	ItemCode,
	RequestNumber
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MntcEquipmentFulfillment ADD CONSTRAINT
	FK_MNTCEQUIPMENTFULFILLMENT_RELATIONSHIP_81_MNTCEQUIPMENTREQUEST FOREIGN KEY
	(
	RequestDate,
	ItemCode,
	LocationCode,
	RequestNumber
	) REFERENCES dbo.MntcEquipmentRequest
	(
	RequestDate,
	ItemCode,
	LocationCode,
	RequestNumber
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO

-- MntcRequestToLocation
ALTER TABLE dbo.MntcRequestToLocation
	DROP CONSTRAINT FK_MNTCREQUESTTOLOCATION_RELATIONSHIP_92_MSTGENLOCATION
GO

CREATE TABLE dbo.Tmp_MntcRequestToLocation
	(
	FulFillmentDate date NOT NULL,
	RequestNumber varchar(11) NOT NULL,
	LocationCode varchar(8) NOT NULL,
	ItemCode varchar(20) NOT NULL,
	QtyFromLocation int NOT NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_MntcRequestToLocation SET (LOCK_ESCALATION = TABLE)
GO
IF EXISTS(SELECT * FROM dbo.MntcRequestToLocation)
	 EXEC('INSERT INTO dbo.Tmp_MntcRequestToLocation (FulFillmentDate, RequestNumber, LocationCode, QtyFromLocation, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
		SELECT FulFillmentDate, RequestNumber, LocationCode, QtyFromLocation, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy FROM dbo.MntcRequestToLocation WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.MntcRequestToLocation
GO
EXECUTE sp_rename N'dbo.Tmp_MntcRequestToLocation', N'MntcRequestToLocation', 'OBJECT' 
GO
ALTER TABLE dbo.MntcRequestToLocation ADD CONSTRAINT
	PK_MntcRequestToLocation PRIMARY KEY CLUSTERED 
	(
	FulFillmentDate,
	RequestNumber,
	LocationCode
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.MntcRequestToLocation WITH NOCHECK ADD CONSTRAINT
	FK_MNTCREQUESTTOLOCATION_RELATIONSHIP_92_MSTGENLOCATION FOREIGN KEY
	(
	LocationCode
	) REFERENCES dbo.MstGenLocation
	(
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.MntcRequestToLocation ADD CONSTRAINT
	FK_MntcRequestToLocation_MntcEquipmentFulfillment FOREIGN KEY
	(
	FulFillmentDate,
	ItemCode,
	RequestNumber
	) REFERENCES dbo.MntcEquipmentFulfillment
	(
	FulFillmentDate,
	ItemCode,
	RequestNumber
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
GO
