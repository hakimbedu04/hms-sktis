-- Description: Update ProductionCard in PlantWages
-- Ticket: story/56761-Report Production Execution - ExeReportEMSSubmitted
-- Author: Bagus
CREATE TABLE dbo.ExeReportEMSSubmitted
	(
	LocationCode varchar(8) NULL,
	BrandCode varchar(11) NULL,
	ProductionDate datetime NULL,
	UploadDate datetime NULL,
	UplProduceQty float(53) NULL,
	UplPackedQty float(53) NULL,
	CreatedDate datetime NOT NULL,
	CreatedBy varchar(64) NOT NULL,
	UpdatedDate datetime NOT NULL,
	UpdatedBy varchar(64) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.ExeReportEMSSubmitted ADD CONSTRAINT
	FK_ExeReportEMSSubmitted_MstGenLocation FOREIGN KEY
	(
	LocationCode
	) REFERENCES dbo.MstGenLocation
	(
	LocationCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.ExeReportEMSSubmitted ADD CONSTRAINT
	FK_ExeReportEMSSubmitted_MstGenBrand FOREIGN KEY
	(
	BrandCode
	) REFERENCES dbo.MstGenBrand
	(
	BrandCode
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO