DECLARE @utilfunc INT;
SELECT @utilfunc = count(*) FROM dbo.UtilFunctions where ParentIDFunction = 374 AND FunctionName = 'Submit' and FunctionType = 'Button';
IF (@utilfunc = 0)
BEGIN
	Insert into UtilFunctions values ('374','Submit','Button',NULL,'2015-10-09 12:00:00.000','PMI\bkristom','2015-10-09 12:00:00.000','PMI\bkristom');
END;

DECLARE @idflow INT;
SELECT @idflow = count(*) FROM dbo.UtilFlows where IDFlow = 55;
IF (@idflow = 0)
BEGIN
	Insert into UtilFlows values ('55','374','387','374',NULL,Null,'2015-10-09 12:00:00.000','PMI\bkristom','2015-10-09 12:00:00.000','PMI\bkristom');
END;
