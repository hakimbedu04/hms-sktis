DROP VIEW [dbo].[TPOTargetProductionKelompokView];
GO

CREATE VIEW [dbo].[TPOTargetProductionKelompokView]
AS
SELECT TPK.*,
       TotalWorkHours.*,
       TotalActualProduction.*,
       tpoProdGroup.ProcessOrder
FROM PlanTPOTargetProductionKelompok AS TPK
     INNER JOIN( 
                 SELECT prodGroup.ProdGroup,
                        prodGroup.ProcessGroup,
                        prodGroup.LocationCode,
                        prodGroup.StatusEmp,
                        genProcess.ProcessOrder
                 FROM MstTPOProductionGroup prodGroup
                      INNER JOIN MstGenProcess genProcess ON prodGroup.ProcessGroup = genProcess.ProcessGroup ) tpoProdGroup ON TPK.ProdGroup = tpoProdGroup.ProdGroup
                                                                                                                            AND TPK.ProcessGroup = tpoProdGroup.ProcessGroup
                                                                                                                            AND TPK.LocationCode = tpoProdGroup.LocationCode
                                                                                                                            AND TPK.StatusEmp = tpoProdGroup.StatusEmp
     OUTER APPLY dbo.GetTotalWorkHoursPrev3Weeks( TPK.KPSYear, TPK.KPSWeek, TPK.ProdGroup, TPK.ProcessGroup, TPK.LocationCode, TPK.StatusEmp, TPK.BrandCode ) AS TotalWorkHours
                 OUTER APPLY dbo.GetTotalActualProductionPrev3Weeks( TPK.KPSYear, TPK.KPSWeek, TPK.ProdGroup, TPK.ProcessGroup, TPK.LocationCode, TPK.StatusEmp, TPK.BrandCode ) AS TotalActualProduction;

GO