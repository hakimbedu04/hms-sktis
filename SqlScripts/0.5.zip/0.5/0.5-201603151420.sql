/*
   Friday, February 19, 20165:23:36 PM
   Owner : Robby
   Desc : Change field WorkHour from Int => Real
*/
ALTER TABLE dbo.ExeReportByGroups ALTER COLUMN WorkHour real NULL;
