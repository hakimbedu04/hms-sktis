USE [SKT_DEV]
GO

/****** Object:  View [dbo].[WagesProductionCardApprovalDetailViewGroup]    Script Date: 13/04/2016 11:11:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Description: Get Production Card Approval List Detail Group(PIVOT), add SL4
-- Ticket: http://tp.voxteneo.co.id/entity/3727
-- Author: Indra Permana
ALTER VIEW [dbo].[WagesProductionCardApprovalDetailViewGroup]
AS
SELECT        
	cast(null as varchar) as ProductionCardCode, 
	LocationCode, 
	UnitCode, 
	ProductionDate, 
	BrandGroupCode, 
	ProcessGroup, 
	GroupCode, 
	COUNT(*) AS Worker, 
	CAST(SUM(Production) AS REAL) AS Production, 
	CAST(SUM(UpahLain) AS REAL) AS UpahLain, 
    SUM(CASE EblekAbsentType WHEN 'A' THEN 1 ELSE 0 END) AS A, 
	SUM(CASE EblekAbsentType WHEN 'C' THEN 1 ELSE 0 END) AS C, 
	SUM(CASE EblekAbsentType WHEN 'CH' THEN 1 ELSE 0 END) AS CH, 
    SUM(CASE EblekAbsentType WHEN 'CT' THEN 1 ELSE 0 END) AS CT, 
	SUM(CASE EblekAbsentType WHEN 'I' THEN 1 ELSE 0 END) AS I, 
	SUM(CASE EblekAbsentType WHEN 'LL' THEN 1 ELSE 0 END) AS LL, 
    SUM(CASE EblekAbsentType WHEN 'LO' THEN 1 ELSE 0 END) AS LO, 
	SUM(CASE EblekAbsentType WHEN 'LP' THEN 1 ELSE 0 END) AS LP, 
	SUM(CASE EblekAbsentType WHEN 'MO' THEN 1 ELSE 0 END) AS MO, 
    SUM(CASE EblekAbsentType WHEN 'PG' THEN 1 ELSE 0 END) AS PG, 
	SUM(CASE EblekAbsentType WHEN 'S' THEN 1 ELSE 0 END) AS S, 
	SUM(CASE EblekAbsentType WHEN 'SB' THEN 1 ELSE 0 END) AS SB, 
    SUM(CASE EblekAbsentType WHEN 'SKR' THEN 1 ELSE 0 END) AS SKR,
    SUM(CASE EblekAbsentType WHEN 'SL4' THEN 1 ELSE 0 END) AS SL4, 
	SUM(CASE EblekAbsentType WHEN 'SLP' THEN 1 ELSE 0 END) AS SLP, 
	SUM(CASE EblekAbsentType WHEN 'SLS' THEN 1 ELSE 0 END) AS SLS, 
	SUM(CASE EblekAbsentType WHEN 'T' THEN 1 ELSE 0 END) AS T, 
	SUM(CASE EblekAbsentType WHEN 'TL' THEN 1 ELSE 0 END) AS TL
FROM            
	dbo.ProductionCard
GROUP BY 
	LocationCode, 
	UnitCode, 
	ProductionDate, 
	BrandGroupCode, 
	ProcessGroup, 
	GroupCode

GO


