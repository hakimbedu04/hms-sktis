-- =============================================
-- Description: Insert TPO Nullable dummy group
-- Ticket: http://tp.voxteneo.co.id/entity/3702
-- Author: Azka
-- Update: 15/03/2016
-- =============================================

ALTER TABLE dbo.ExePlantWorkerAssignment 
ALTER COLUMN DestinationGroupCodeDummy VARCHAR(6) NULL