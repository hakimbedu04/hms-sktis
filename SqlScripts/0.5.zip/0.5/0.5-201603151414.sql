﻿/*
   Friday, February 19, 201610:30:06 AM
   Owner : Robby
*/

ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours1 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours2 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours3 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours4 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours5 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours6 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN ProcessWorkHours7 real NULL;
ALTER TABLE dbo.PlanTPOTargetProductionKelompok ALTER COLUMN TotalWorkhours real NULL;
