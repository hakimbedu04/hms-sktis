-- =============================================
-- Description: Create View for absent report ini buat yang tahun bulanan
-- Ticket: 
-- Author: Abud - 2016/04/01
-- =============================================

CREATE VIEW [dbo].[GetWagesReportAbsentsYearMonthlyView]
AS
SELECT ROW_NUMBER() OVER (
                          ORDER BY BrandCode) AS id,
						  Year,
						  Month,
       BrandCode,
       LocationCode,
       ProdUnit,
       ProcessGroup,
       ProdGroup,
       ProductionDate,
       Terdaftar,
       Alpa,
       Ijin,
       Sakit,
       Cuti,
       CutiHamil,
       CutiTahunan,
       Skorsing,
       Keluar,
       Terdaftar - Keluar - Alpa - Cuti - CutiHamil - CutiTahunan - Skorsing AS Masuk,
       0 AS Turnover,
       (CAST(Terdaftar AS FLOAT) - Alpa) / CAST(Terdaftar AS FLOAT) * 100 AS Kehadiran,
       (CAST(Terdaftar AS FLOAT) - Cuti) / CAST(Terdaftar AS FLOAT) * 100 AS Absensi
FROM
  (SELECT MAX(pc.BrandCode) AS BrandCode,
          MAX(pc.LocationCode) AS LocationCode,
          MAX(pc.UnitCode) AS ProdUnit,
          MAX(pc.ProcessGroup) AS ProcessGroup,
          MAX(pc.GroupCode) AS ProdGroup,
          MAX(pc.ProductionDate) AS ProductionDate,
          COUNT(pc.EmployeeID) AS Terdaftar,
		  DATEPART(YYYY,pc.ProductionDate) AS Year,
		  DATEPART(MM,pc.ProductionDate) AS Month,
          SUM(CASE WHEN pc.EblekAbsentType = 'A' THEN 1 ELSE 0 END) AS Alpa,
          SUM(CASE WHEN pc.EblekAbsentType = 'I' THEN 1 ELSE 0 END) AS Ijin,
          SUM(CASE WHEN pc.EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS Sakit,
          SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS Cuti,
          SUM(CASE WHEN pc.EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS CutiHamil,
          SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS CutiTahunan,
          SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS Skorsing,
          SUM(CASE WHEN pc.EblekAbsentType = 'T' THEN 1 ELSE 0 END) AS Keluar
   FROM dbo.ProductionCard as pc
   JOIN dbo.MstPlantEmpJobsDataAcv as emp ON pc.EmployeeID = emp.EmployeeID
   GROUP BY pc.LocationCode,
            pc.UnitCode,
			pc.GroupCode,
			pc.BrandCode,
			pc.ProcessGroup,
			DATEPART(YYYY,pc.ProductionDate),
			DATEPART(MM,pc.ProductionDate)
			) AS SOURCE

GO


