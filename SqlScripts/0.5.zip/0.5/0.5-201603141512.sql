/****** Object:  UserDefinedFunction [dbo].[GetExeReportByGroupAnnualy]    Script Date: 3/14/2016 10:29:15 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Get ExeReportByGroupAnnualy
-- Ticket: http://tp.voxteneo.co.id/entity/3029
-- Author: Azka
-- Update: 14/03/2016
-- =============================================

CREATE FUNCTION [dbo].[GetExeReportByGroupAnnualy]
(	
	@LocationCode VARCHAR(10),
	@UnitCode VARCHAR(10),
	@Shift INT,
	@Process VARCHAR(10),
	@Brand VARCHAR(20),
	@Year INT
)
RETURNS TABLE 
AS
RETURN 
(
	WITH ReportByGroup AS(
		SELECT rg.*, br.SKTBrandCode 
		FROM ExeReportByGroups rg
		INNER JOIN MstGenBrandGroup br on br.BrandGroupCode = rg.BrandGroupCode
		WHERE LocationCode = @LocationCode 
			AND UnitCode = @UnitCode 
			AND Shift = @Shift 
			AND ProcessGroup = @Process
			AND SKTBrandCode = @Brand
			AND KPSYear = @Year
	)

	SELECT  
		BrandGroupCode,
		LocationCode,
		UnitCode,
		GroupCode, 
		CONVERT(INT, ROUND(AVG(Register), 0)) AS Register, 
		CONVERT(INT, ROUND(AVG(Absennce_A), 0)) AS A, 
		CONVERT(INT, ROUND(AVG(Absence_I), 0)) AS I, 
		CONVERT(INT, ROUND(AVG(Absence_S), 0)) AS S, 
		CONVERT(INT, ROUND(AVG(Absence_C), 0)) AS C, 
		CONVERT(INT, ROUND(AVG(Absence_CH), 0)) AS CH, 
		CONVERT(INT, ROUND(AVG(Absence_CT), 0)) AS CT,
		CONVERT(INT, ROUND(AVG(Absence_SLS + Absence_SLP), 0)) AS SLSSLP,
		CONVERT(INT, ROUND(AVG(Absence_ETC), 0)) AS ETC,
		CONVERT(INT, ROUND(AVG(Multi_TPO), 0)) AS Multi_TPO,
		CONVERT(INT, ROUND(AVG(Multi_ROLL), 0)) AS Multi_ROLL,
		CONVERT(INT, ROUND(AVG(Multi_CUTT), 0)) AS Multi_CUTT,
		CONVERT(INT, ROUND(AVG(Multi_PACK), 0)) AS Multi_PACK,
		CONVERT(INT, ROUND(AVG(Multi_STAMP), 0)) AS Multi_STAMP,
		CONVERT(INT, ROUND(AVG(Multi_FWRP), 0)) AS Multi_FWRP,
		CONVERT(INT, ROUND(AVG(Multi_SWRP), 0)) AS Multi_SWRP,
		CONVERT(INT, ROUND(AVG(Multi_GEN), 0)) AS Multi_GEN,
		CONVERT(INT, ROUND(AVG(Multi_WRP), 0)) AS Multi_WRP,
		CONVERT(INT, ROUND(AVG(EmpIn), 0)) AS [In],
		CONVERT(INT, ROUND(AVG([Out]), 0)) AS [Out],
		CONVERT(INT, ROUND(AVG(ActualWorker), 0)) AS ActualWorker,
		CONVERT(INT, ROUND(AVG(WorkHour), 0)) AS WorkHour,
		cast(AVG(Production) as decimal(10,2)) AS Production, 	
		cast(AVG(ValuePeople) as decimal(10,2)) AS ValuePeople,
		cast(AVG(ValueHour) as decimal(10,2)) AS ValueHour,
		cast(AVG(ValuePeopleHour) as decimal(10,2)) AS ValuePeopleHour
	FROM ReportByGroup
	GROUP BY
		BrandGroupCode,
		LocationCode,
		UnitCode,
		GroupCode
)
