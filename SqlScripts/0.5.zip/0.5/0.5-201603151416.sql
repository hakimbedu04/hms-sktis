﻿-- Change workhour column to real
-- Robby

ALTER TABLE dbo.ExeTPOProductionEntryVerification ALTER COLUMN WorkHour real NOT NULL;
