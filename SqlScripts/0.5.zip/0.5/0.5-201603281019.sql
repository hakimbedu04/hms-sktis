USE [SKT_DEV]
GO

ALTER TABLE [dbo].[ExeMaterialUsage] ADD pakai real
GO