-- =============================================
-- Description: add column QtyLeftOver numeric
-- Ticket: http://tp.voxteneo.co.id/entity/3865
-- Author: Hakim
-- Update: 31/03/2016
-- =============================================

ALTER TABLE dbo.MntcEquipmentRequest ADD
	QtyLeftOver numeric(16, 0) NULL