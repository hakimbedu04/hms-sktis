USE [SKT_DEV]
GO
/****** Object:  UserDefinedFunction [dbo].[GetExeReportByGroupDaily]    Script Date: 4/6/2016 2:20:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Get ExeReportByGroupDaily
-- Ticket: http://tp.voxteneo.co.id/entity/3029
-- Author: Azka
-- Update: 14/03/2016
-- =============================================

-- =============================================
-- Description: change workhour average 2 decimal places
-- Ticket: http://tp.voxteneo.co.id/entity/3815
-- Author: Azka
-- Update: 28/03/2016
-- =============================================

ALTER FUNCTION [dbo].[GetExeReportByGroupDaily]
(	
	@LocationCode VARCHAR(10),
	@UnitCode VARCHAR(10),
	@Shift INT,
	@Process VARCHAR(10),
	@Brand VARCHAR(20),
	@DateFrom DATETIME,
	@DateTo DATETIME
)
RETURNS TABLE 
AS
RETURN 
(
	WITH ReportByGroup AS(
		SELECT rg.*, br.SKTBrandCode 
		FROM ExeReportByGroups rg
		INNER JOIN MstGenBrandGroup br on br.BrandGroupCode = rg.BrandGroupCode
		WHERE LocationCode = @LocationCode 
			AND UnitCode = @UnitCode 
			AND Shift = @Shift 
			AND ProcessGroup = @Process
			AND SKTBrandCode = @Brand
			AND ProductionDate >= @DateFrom
			AND ProductionDate <= @DateTo
	)

	SELECT  
		BrandGroupCode,
		LocationCode,
		UnitCode,
		GroupCode, 
		ProductionDate,		
		ROUND(AVG(ISNULL(Register,0)), 2) AS Register, 
		ROUND(AVG(ISNULL(Absennce_A,0)), 2) AS A, 
		ROUND(AVG(ISNULL(Absence_I, 0)),2) AS I, 
		ROUND(AVG(ISNULL(Absence_S,0)), 2) AS S, 
		ROUND(AVG(ISNULL(Absence_C,0)), 2) AS C, 
		ROUND(AVG(ISNULL(Absence_CH,0)), 2) AS CH, 
		ROUND(AVG(ISNULL(Absence_CT,0)), 2) AS CT,
		ROUND(AVG(ISNULL((Absence_SLS + Absence_SLP),0)), 2) AS SLSSLP,
		ROUND(AVG(ISNULL(Absence_ETC,0)), 2) AS ETC,
		ROUND(AVG(ISNULL(Multi_TPO,0)), 2) AS Multi_TPO,
		ROUND(AVG(ISNULL(Multi_ROLL,0)), 2) AS Multi_ROLL,
		ROUND(AVG(ISNULL(Multi_CUTT,0)), 2) AS Multi_CUTT,
		ROUND(AVG(ISNULL(Multi_PACK,0)), 2) AS Multi_PACK,
		ROUND(AVG(ISNULL(Multi_STAMP,0)), 2) AS Multi_STAMP,
		ROUND(AVG(ISNULL(Multi_FWRP,0)), 2) AS Multi_FWRP,
		ROUND(AVG(ISNULL(Multi_SWRP,0)), 2) AS Multi_SWRP,
		ROUND(AVG(ISNULL(Multi_GEN,0)), 2) AS Multi_GEN,
		ROUND(AVG(ISNULL(Multi_WRP,0)), 2) AS Multi_WRP,
		ROUND(AVG(ISNULL(EmpIn,0)), 2) AS [In],
		ROUND(AVG(ISNULL([Out],0)), 2) AS [Out],
		ROUND(AVG(ISNULL(ActualWorker,0)), 2) AS ActualWorker,
		cast(AVG(WorkHour) as decimal(10,2))AS WorkHour,
		cast(AVG(Production) as decimal(10,2)) AS Production, 	
		cast(AVG(ValuePeople) as decimal(10,2)) AS ValuePeople,
		cast(AVG(ValueHour) as decimal(10,2)) AS ValueHour,
		cast(AVG(ValuePeopleHour) as decimal(10,2)) AS ValuePeopleHour
	FROM ReportByGroup
	GROUP BY
		BrandGroupCode,
		LocationCode,
		UnitCode,
		GroupCode,
		ProductionDate
)


