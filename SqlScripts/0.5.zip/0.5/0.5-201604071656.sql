-- =============================================
-- Description: Create View for absent report ini buat yang tahun bulanan
-- Ticket: 
-- Author: Abud - 2016/04/01
-- =============================================

ALTER VIEW [dbo].[GetWagesReportAbsentsYearMonthlyView]
AS
	SELECT 
ROW_NUMBER() OVER (
                          ORDER BY MAX(pc.LocationCode)) AS id,
       MAX(pc.LocationCode) AS LocationCode,
       MAX(pc.BrandGroupCode) AS BrandCode,
       MAX(pc.UnitCode) AS ProdUnit,
       MAX(pc.ProcessGroup) AS ProcessGroup,
       MAX(pc.GroupCode) AS ProdGroup,
	   DATEPART(YYYY,pc.ProductionDate) AS Year,
	   DATEPART(MM,pc.ProductionDate) AS Month,
       MAX(pc.ProductionDate) AS ProductionDate,
       COUNT(pc.EmployeeID) AS Terdaftar,
       SUM(CASE WHEN pc.EblekAbsentType = 'A' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS Alpa,
       SUM(CASE WHEN pc.EblekAbsentType = 'I' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS Ijin,
       SUM(CASE WHEN pc.EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS Sakit,
       SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS Cuti,
       SUM(CASE WHEN pc.EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS CutiHamil,
       SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS CutiTahunan,
       SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS Skorsing,
       SUM(CASE WHEN pc.EblekAbsentType = 'T' THEN 1 ELSE 0 END) AS Keluar,
       ( COUNT(pc.EmployeeID) - SUM(CASE WHEN pc.EblekAbsentType = 'T' THEN 1 ELSE 0 END) - SUM(CASE WHEN pc.EblekAbsentType = 'A' THEN 1 ELSE 0 END) - SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) - SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) - SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) ) AS Masuk,
       (COUNT(pc.EmployeeID) - COUNT(pc.EmployeeID)) AS Turnover,
       (CAST(COUNT(pc.EmployeeID) AS FLOAT) - SUM(CASE WHEN pc.EblekAbsentType = 'A' THEN 1 ELSE 0 END)) / CAST(COUNT(pc.EmployeeID) AS FLOAT) * 100 AS Kehadiran,
       (CAST(COUNT(pc.EmployeeID) AS FLOAT) - SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END)) / CAST(COUNT(pc.EmployeeID) AS FLOAT) * 100 AS Absensi
FROM dbo.ProductionCard AS pc
GROUP BY pc.LocationCode,
            pc.UnitCode,
			pc.GroupCode,
			--pc.ProcessGroup,
			--pc.BrandGroupCode,
			DATEPART(YYYY,pc.ProductionDate),
			DATEPART(MM,pc.ProductionDate)
GO


