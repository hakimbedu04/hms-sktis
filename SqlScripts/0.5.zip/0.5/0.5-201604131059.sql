-- =============================================
-- Author:		OpunBuds
-- Create date: 2016-04-13
-- Description:	Wages Report Absent Detail Dialy
-- =============================================
CREATE FUNCTION [dbo].[GetWagesReportAbsentDetailDialy]
(	
	@ProductionDate DATE = NULL,
	@LocationCode varchar(10) = NULL,
	@UnitCode varchar(10) =  NULL,
	@BrandGroupCode varchar(50) = NULL,
	@GroupCode varchar(50) = NULL
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT ROW_NUMBER() OVER (
                          ORDER BY LocationCode) AS id,
       LocationCode,
       ProdUnit,
	   EmployeeID,
	   EmployeeName,
       Alpa,
       Ijin,
       Sakit,
       Cuti,
       CutiHamil,
       CutiTahunan,
       Skorsing,
	   HKNTotal,
	   (Alpa + Ijin + Sakit + Cuti + CutiHamil + CutiTahunan + Skorsing) AS AbsentTotal,
	   (ProductionTotal * UOMEblek) AS ProductionTotal,
	   JKTotal,
	   ((CASE WHEN JKTotal != 0 THEN (ProductionTotal / JKTotal )ELSE 0 END) * UOMEblek) AS Productivity
FROM
  (SELECT MAX(pc.BrandGroupCode) AS BrandGroupCode,
          MAX(pc.LocationCode) AS LocationCode,
          MAX(pc.UnitCode) AS ProdUnit,
		  MAX(pc.EmployeeID) as EmployeeID,
		  MAX(emp.EmployeeName) as EmployeeName,
          SUM(CASE WHEN pc.EblekAbsentType = 'A' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS Alpa,
          SUM(CASE WHEN pc.EblekAbsentType = 'I' AND pc.Remark IS NULL THEN 1 ELSE 0 END) AS Ijin,
          SUM(CASE WHEN pc.EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS Sakit,
          SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS Cuti,
          SUM(CASE WHEN pc.EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS CutiHamil,
          SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS CutiTahunan,
          SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS Skorsing,
		  SUM(CASE WHEN (pc.Production + pc.UpahLain > 0)  THEN 1 ELSE 0 END) AS HKNTotal,
		  SUM(pc.WorkHours) AS JKTotal,
		  SUM(pc.Production) AS ProductionTotal,
		  MAX(psalv.UOMEblek) AS UOMEblek
   FROM dbo.ProductionCard AS pc
   JOIN dbo.MstPlantEmpJobsDataAll AS emp ON emp.EmployeeID = pc.EmployeeID
   JOIN dbo.ProcessSettingsAndLocationView AS psalv ON psalv.LocationCode = pc.LocationCode AND psalv.BrandGroupCode = pc.BrandGroupCode AND psalv.ProcessGroup = pc.ProcessGroup
   WHERE 
		pc.ProductionDate = ISNULL(@ProductionDate,pc.ProductionDate)
		AND pc.LocationCode = ISNULL(@LocationCode, pc.LocationCode)
		AND pc.UnitCode = ISNULL(@UnitCode, pc.UnitCode)
		and pc.BrandGroupCode = ISNULL(@BrandGroupCode, pc.BrandGroupCode)
		and pc.GroupCode = ISNULL(@GroupCode, pc.GroupCode)
   GROUP BY pc.LocationCode,
            pc.UnitCode,
			pc.GroupCode,
			pc.EmployeeID
			--pc.ProcessGroup,
			--pc.BrandGroupCode,
			--pc.ProductionDate
) AS SOURCE
)


GO


