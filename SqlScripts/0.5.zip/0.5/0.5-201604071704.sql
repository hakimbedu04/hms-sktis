-- =============================================
-- Description: add jam
-- Ticket: http://tp.voxteneo.co.id/entity/4021
-- Author: Dwi Yudha
-- =============================================

ALTER TABLE dbo.TPOFeeProductionDailyPlan ADD
	JKNJam float(53) NULL,
	JL1Jam float(53) NULL,
	JL2Jam float(53) NULL,
	JL3Jam float(53) NULL,
	JL4Jam float(53) NULL