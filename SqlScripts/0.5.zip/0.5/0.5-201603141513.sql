/****** Object:  UserDefinedFunction [dbo].[GetEmployeeEblekCount]    Script Date: 3/14/2016 9:53:23 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: Get Employee Count From Plant Eblek
-- Ticket: http://tp.voxteneo.co.id/entity/3029
-- Author: Azka
-- Update: 14/03/2016
-- =============================================

CREATE FUNCTION [dbo].[GetEmployeeEblekCount](
                @ProductionEntryCode VARCHAR(50)
				)
RETURNS INT
AS
     BEGIN
     DECLARE @column VARCHAR(50),
             @result INT = 0;
		  SELECT @result = COUNT(eppe.EmployeeID) FROM dbo.ExePlantProductionEntry eppe 
			 WHERE eppe.ProductionEntryCode = @ProductionEntryCode

     RETURN @result;
     END;


