-- =============================================
-- Description: Add new field
-- Ticket: http://tp.voxteneo.co.id/entity/3791
-- Author: Dwi Yudha
-- =============================================

ALTER TABLE dbo.TPOFeeProductionDaily ADD
	JKNBoxFinal float(53) NULL,
	JL1BoxFinal float(53) NULL,
	JL2BoxFinal float(53) NULL,
	JL3BoxFinal float(53) NULL,
	JL4BoxFinal float(53) NULL