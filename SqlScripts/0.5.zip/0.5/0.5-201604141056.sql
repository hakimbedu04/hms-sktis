-- =============================================
-- Author:		OpunBuds
-- Create date: 2016-04-14
-- Description:	Get diff day from prodcard only have datas
-- =============================================
CREATE FUNCTION [dbo].[GetDiffDayProdCard]
(
	@stardate DATE,
	@enddate DATE,
	@locationCode VARCHAR(20),
	@brandGroupCode VARCHAR(20),
	@unitCode VARCHAR(15),
	@GroupCode VARCHAR(15),
	@processGroup VARCHAR(15)
)
RETURNS INT
AS
BEGIN
	DECLARE @diff int

	SELECT @diff = DATEDIFF(DAY,MIN(pc.ProductionDate),MAX(pc.ProductionDate)) + 1

	FROM dbo.ProductionCard as pc
	WHERE
	pc.ProductionDate >= @stardate and pc.ProductionDate <= @enddate
			and pc.LocationCode = @locationCode
			and pc.BrandGroupCode = @brandGroupCode
			and pc.UnitCode = @unitCode
			and pc.GroupCode = @GroupCode
			and pc.ProcessGroup = @processGroup
	GROUP BY 
			pc.LocationCode,
			pc.BrandGroupCode,
			pc.UnitCode,
			pc.GroupCode,
			pc.ProcessGroup

	-- Return the result of the function
	RETURN @diff

END
GO

