USE [SKT_DEV]
GO

/****** Object:  View [dbo].[GetWagesReportAbsentsView]    Script Date: 04/04/2016 19:03:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description: Create View for absent report
-- Ticket: 
-- Author: Abud - 2016/04/01
-- =============================================

ALTER VIEW [dbo].[GetWagesReportAbsentsView]
AS
SELECT ROW_NUMBER() OVER (
                          ORDER BY BrandCode) AS id,
       BrandCode,
       LocationCode,
       ProdUnit,
       ProcessGroup,
       ProdGroup,
       ProductionDate,
       Terdaftar,
       Alpa,
       Ijin,
       Sakit,
       Cuti,
       CutiHamil,
       CutiTahunan,
       Skorsing,
       Keluar,
       Terdaftar - Keluar - Alpa - Cuti - CutiHamil - CutiTahunan - Skorsing AS Masuk,
       0 AS Turnover,
       (CAST(Terdaftar AS FLOAT) - Alpa) / CAST(Terdaftar AS FLOAT) * 100 AS kehadiran,
       (CAST(Terdaftar AS FLOAT) - Cuti) / CAST(Terdaftar AS FLOAT) * 100 AS absensi
FROM
  (SELECT MAX(BrandCode) AS BrandCode,
          MAX(LocationCode) AS LocationCode,
          MAX(UnitCode) AS ProdUnit,
          MAX(ProcessGroup) AS ProcessGroup,
          MAX(GroupCode) AS ProdGroup,
          MAX(ProductionDate) AS ProductionDate,
          COUNT(EmployeeID) AS Terdaftar,
          SUM(CASE WHEN EblekAbsentType = 'A' THEN 1 ELSE 0 END) AS Alpa,
          SUM(CASE WHEN EblekAbsentType = 'I' THEN 1 ELSE 0 END) AS Ijin,
          SUM(CASE WHEN EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS Sakit,
          SUM(CASE WHEN EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS Cuti,
          SUM(CASE WHEN EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS CutiHamil,
          SUM(CASE WHEN EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS CutiTahunan,
          SUM(CASE WHEN EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS Skorsing,
          SUM(CASE WHEN EblekAbsentType = 'T' THEN 1 ELSE 0 END) AS Keluar
   FROM dbo.ProductionCard
   GROUP BY LocationCode,
            GroupCode,
            ProcessGroup) AS SOURCE

GO


