-- =============================================
-- Description: add column Absence_S
-- Ticket: http://tp.voxteneo.co.id/entity/3029
-- Author: Azka
-- Update: 14/03/2016
-- =============================================

ALTER TABLE dbo.ExeReportByGroupsWeekly ADD
	ActualWorker int NULL,
	Absence_S float(53) NULL
GO

ALTER TABLE dbo.ExeReportByGroupsMonthly ADD
	ActualWorker int NULL,
	Absence_S float(53) NULL
GO

ALTER TABLE dbo.ExeReportByGroups ADD
	Absence_S float(53) NULL
GO
