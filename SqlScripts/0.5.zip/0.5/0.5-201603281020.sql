USE [SKT_DEV]
GO

/****** Object:  View [dbo].[ExeMaterialUsageView]    Script Date: 28/03/2016 10:19:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- Description: Alter [dbo].[ExeMaterialUsageView]
-- Ticket: http://tp.voxteneo.com/entity/61248
-- Author: Yudha

ALTER VIEW [dbo].[ExeMaterialUsageView]
AS
	SELECT  distinct mppg.LocationCode, mppg.UnitCode, mgl.Shift, mgps.BrandGroupCode, gm.MaterialCode, mppg.GroupCode, mppg.ProcessGroup, 
		NULL AS ProductionDate, NULL AS Sisa, NULL AS Ambil1, NULL AS Ambil2, NULL AS Ambil3, 
		NULL AS TobFM, NULL AS TobStem, NULL AS TobSapon, NULL AS UncountableWaste, NULL AS CountableWaste, NULL AS CreatedDate, NULL AS CreatedBy, NULL AS UpdatedDate, NULL AS UpdatedBy,Null AS pakai
	FROM    dbo.MstPlantProductionGroup AS mppg INNER JOIN
		dbo.MstGenLocation AS mgl ON mgl.LocationCode = mppg.LocationCode INNER JOIN
		dbo.MstGenProcessSettingsLocation AS mgpsl ON mppg.LocationCode = mgpsl.LocationCode INNER JOIN
		dbo.MstGenProcessSettingsMapping AS mgpsm ON mgpsm.ProcessSettingsLocationID = mgpsl.ID INNER JOIN
		dbo.MstGenProcessSettings AS mgps ON mgps.IDProcess = mgpsm.ProcessSettingsID INNER JOIN
		dbo.MstGenMaterial AS gm ON gm.BrandGroupCode = mgps.BrandGroupCode
	GROUP BY mppg.LocationCode, mppg.UnitCode, mgl.Shift, mgps.BrandGroupCode, gm.MaterialCode, mppg.GroupCode, mppg.ProcessGroup




GO


