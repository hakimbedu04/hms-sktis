-- =============================================
-- Description: insert idflow cancel submit prodcard, approve
-- Ticket: http://tp.voxteneo.co.id/entity/5097
-- Author: Azka
-- Update: 12/04/20163
-- =============================================

INSERT INTO 
	[dbo].[UtilFlows](IDFlow, FormSource, ActionButton, DestinationForm, DestinationRole, MessageText, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
VALUES
	(56, 143, 146, 143, 6, NULL, '2016/04/12', 'PMI\bkristom', '2016/04/12', 'PMI\bkristom')

INSERT INTO 
	[dbo].[UtilFlows](IDFlow, FormSource, ActionButton, DestinationForm, DestinationRole, MessageText, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy)
VALUES
	(57, 126, 130, 126, 7, NULL, '2016/04/12', 'PMI\bkristom', '2016/04/12', 'PMI\bkristom')