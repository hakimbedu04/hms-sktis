-- =============================================
-- Description: Change destination roles eblek approval to SPGS ID flow = 30, PGSC ID flow =29
-- Ticket: http://tp.voxteneo.co.id/entity/3945
-- Author: Azka
-- Update: 05/04/2016
-- =============================================

delete from UtilTransactionLogs where IDFlow = 29
delete from UtilTransactionLogs where IDFlow = 30
delete from UtilTransactionLogs where IDFlow = 27

delete from UtilFlows where IDFlow = 29
insert into UtilFlows (IDFlow, FormSource, ActionButton, DestinationForm, DestinationRole, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy) 
values
(29, 156, 157, 156, 5, '2016/04/05', 'PMI\bkristom', '2016/04/05', 'PMI\bkristom')

delete from UtilFlows where IDFlow = 30
insert into UtilFlows (IDFlow, FormSource, ActionButton, DestinationForm, DestinationRole, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy) 
values
(30, 156, 157, 75, 7, '2016/04/05', 'PMI\bkristom', '2016/04/05', 'PMI\bkristom')

delete from UtilFlows where IDFlow = 27
insert into UtilFlows (IDFlow, FormSource, ActionButton, DestinationForm, DestinationRole, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy) 
values
(27, 150, 153, 156, 6, '2016/04/05', 'PMI\bkristom', '2016/04/05', 'PMI\bkristom')