/****** Object:  UserDefinedFunction [dbo].[[GetWorkHours]]    Script Date: 3/28/2016 3:35:00 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: calculate workhour
-- Ticket: http://tp.voxteneo.co.id/entity/3815
-- Author: Azka
-- Update: 28/03/2016
-- =============================================

CREATE FUNCTION [dbo].[GetWorkHours]
(
	@TimeIn		TIME,
	@TimeOut	TIME,
	@BreakTime	TIME
)
RETURNS DECIMAL(10,2)
AS
     BEGIN
     DECLARE	@result DECIMAL(10,2) = 0.00;
     
	 -- Formula : In - Out - Break
	 -- (Different time In and Out) - Break

	 IF @TimeOut =  CONVERT(TIME, '00:00:00.0000000')
		 BEGIN
			SET @result = (CAST(ABS(DATEDIFF(MINUTE, @TimeIn, '23:00:00.0000000')) / 60.0 AS DECIMAL(10,2)) + 1) - CAST(ABS(DATEDIFF(MINUTE, '00:00:00.0000000', @BreakTime)) / 60.0 AS DECIMAL(10,2));
		 END;
	 ELSE IF @TimeIn =  CONVERT(TIME, '00:00:00.0000000') AND @TimeOut =  CONVERT(TIME, '00:00:00.0000000')
		 BEGIN
			SET @result = 24.00;
		 END;
     ELSE
		 BEGIN
			SET @result = CAST(ABS(DATEDIFF(MINUTE, @TimeOut, @TimeIn)) / 60.0 AS DECIMAL(10,2)) - CAST(ABS(DATEDIFF(MINUTE, '00:00:00.0000000', @BreakTime)) / 60.0 AS DECIMAL(10,2))
		 END;

     RETURN @result;
     END;
