/****** Object:  UserDefinedFunction [dbo].[GetAbsent]    Script Date: 3/14/2016 1:50:21 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description: get absent modify
-- Ticket: http://tp.voxteneo.co.id/entity/3029
-- Author: Azka
-- Update: 14/03/2016
-- =============================================

ALTER FUNCTION [dbo].[GetAbsent](
                @ProductionEntryCode VARCHAR(50),
                @AbsentCode          VARCHAR(50))
RETURNS INT
AS
     BEGIN
     DECLARE @column VARCHAR(50),
             @result INT = 0;
     IF @AbsentCode IS NOT NULL
	    BEGIN
		  SELECT @result = COUNT(*) FROM dbo.ExePlantProductionEntry eppe WHERE eppe.AbsentCodeEblek = @AbsentCode AND eppe.ProductionEntryCode = @ProductionEntryCode;
	    END
     ELSE
	    BEGIN
		  SELECT @result = COUNT(*) FROM dbo.ExePlantProductionEntry eppe 
			 WHERE eppe.AbsentCodeEblek IS NOT NULL AND eppe.ProductionEntryCode = @ProductionEntryCode
			 AND eppe.AbsentCodeEblek IN ('LL', 'SKR');
			 --AND eppe.AbsentCodeEblek NOT IN ('A', 'I', 'C', 'CH', 'CT', 'SLS', 'SLP', 'MO', 'S');
	    END

     

     RETURN @result;
     END;


