USE [SKT_DEV]
GO

/****** Object:  View [dbo].[GetWagesReportAbsentsView]    Script Date: 04/04/2016 19:08:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description: Create View for absent report
-- Ticket: 
-- Author: Abud - 2016/04/01
-- =============================================

ALTER VIEW [dbo].[GetWagesReportAbsentsView]
AS
SELECT ROW_NUMBER() OVER (
                          ORDER BY BrandCode) AS id,
	   EmployeeName,
	   EmployeeID,
	   EmployeeNumber
       BrandCode,
       LocationCode,
       ProdUnit,
       ProcessGroup,
       ProdGroup,
       ProductionDate,
       Terdaftar,
       Alpa,
       Ijin,
       Sakit,
       Cuti,
       CutiHamil,
       CutiTahunan,
       Skorsing,
       Keluar,
       Terdaftar - Keluar - Alpa - Cuti - CutiHamil - CutiTahunan - Skorsing AS Masuk,
       0 AS Turnover,
       (CAST(Terdaftar AS FLOAT) - Alpa) / CAST(Terdaftar AS FLOAT) * 100 AS kehadiran,
       (CAST(Terdaftar AS FLOAT) - Cuti) / CAST(Terdaftar AS FLOAT) * 100 AS absensi,
	   TotalProduction,
	   TotalWorkHours,
	   (CAST(TotalProduction AS FLOAT) / CAST(TotalWorkHours AS FLOAT)) as Productivity
FROM
  (SELECT MAX(pc.BrandCode) AS BrandCode,
          MAX(pc.LocationCode) AS LocationCode,
          MAX(pc.UnitCode) AS ProdUnit,
          MAX(pc.ProcessGroup) AS ProcessGroup,
          MAX(pc.GroupCode) AS ProdGroup,
          MAX(pc.ProductionDate) AS ProductionDate,
          COUNT(pc.EmployeeID) AS Terdaftar,
          SUM(CASE WHEN pc.EblekAbsentType = 'A' THEN 1 ELSE 0 END) AS Alpa,
          SUM(CASE WHEN pc.EblekAbsentType = 'I' THEN 1 ELSE 0 END) AS Ijin,
          SUM(CASE WHEN pc.EblekAbsentType = 'S' THEN 1 ELSE 0 END) AS Sakit,
          SUM(CASE WHEN pc.EblekAbsentType = 'C' THEN 1 ELSE 0 END) AS Cuti,
          SUM(CASE WHEN pc.EblekAbsentType = 'CH' THEN 1 ELSE 0 END) AS CutiHamil,
          SUM(CASE WHEN pc.EblekAbsentType = 'CT' THEN 1 ELSE 0 END) AS CutiTahunan,
          SUM(CASE WHEN pc.EblekAbsentType = 'SKR' THEN 1 ELSE 0 END) AS Skorsing,
          SUM(CASE WHEN pc.EblekAbsentType = 'T' THEN 1 ELSE 0 END) AS Keluar,
		  SUM(pc.Production) as TotalProduction,
		  SUM(pc.WorkHours) as TotalWorkHours,
		  MAX(pc.EmployeeID) as EmployeeID,
		  MAX(pc.EmployeeNumber) as EmployeeNumber,
		  MAX(emp.EmployeeName) as EmployeeName
   FROM dbo.ProductionCard as pc
   JOIN dbo.MstPlantEmpJobsDataAcv as emp ON pc.EmployeeID = emp.EmployeeID
   GROUP BY pc.LocationCode,
            pc.GroupCode,
            pc.ProcessGroup) AS SOURCE


GO


